#pragma once

#include <mikmod.h>
#include <mikmod_drv_nds.h>

#ifdef __cplusplus
extern "C" {
#endif

void MikMod7_ProcessCommand(u32 command);

#ifdef __cplusplus
}
#endif
