#ifdef __cplusplus
extern "C" {
#endif

MIKMODAPI extern MODULE* Player_LoadMemory(const void* buffer, size_t size, int maxchan, BOOL curious);

#ifdef __cplusplus
}
#endif
