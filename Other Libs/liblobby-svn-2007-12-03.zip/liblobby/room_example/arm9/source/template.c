
#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>

#include "MessageQueue.h"
#include "802.11.h"
#include "lobby.h"
#include <fat.h>
#include <malloc.h>
#include <string.h>

#define MAX_ROOMS 8
#define ROOM_NAMES 6
#define MENU_MAIN 0 
#define MENU_CREATE_ROOM 1
#define MENU_LOBBY 2

LPLOBBY_USER roomOwners[MAX_ROOMS];
LPLOBBY_ROOM myRoom;
char* roomNames[ROOM_NAMES] = {
	"ROOM1",
	"ROOM2",
	"ROOM3",
	"YOU",
	"NAME",
	"IT"
};
int roomNameIndex = 0;
int roomMaxUsers = 2;
unsigned short roomGameCode = 1;
unsigned short roomGameVersion = 1;
int roomVisible = 1;
int roomCount = 0;
int logCount = 0;
int menuState = MENU_MAIN;
int selected = 0 ;

void VBlankIRQ(void)
{
	REG_IF = IRQ_VBLANK;
	IPC_RcvCompleteCheck();
	LOBBY_Update();
}

void receiveUserData(unsigned char *data, int length, LPLOBBY_USER from)
{
	printf("\x1b[%d;0H", logCount+11); if(++logCount>10) logCount=0;
	printf("- user msg %s: %s      \n", LOBBY_GetUserName(from), data);
}

void receiveRoomData(unsigned char *data, int length, LPLOBBY_USER from)
{
	printf("\x1b[%d;0H", logCount+11); if(++logCount>10) logCount=0;
	printf("- room msg %s: %s      \n", LOBBY_GetUserName(from), data);
}

void userCallback(LPLOBBY_USER user, unsigned long reason)
{
	printf("\x1b[%d;0H", logCount+11); if(++logCount>10) logCount=0;
	switch(reason)
	{
		case USERINFO_REASON_REGOGNIZE:
			printf("- user %s recognized    \n", LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_TIMEOUT:
			printf("- user %s timeout       \n", LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_RETURN:
			printf("- user %s returned      \n", LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_ROOMCREATED:
			printf("- user %s created a room\n", LOBBY_GetUserName(user));
			int i;
			for(i=0;i<roomCount;i++)
			{
				if(roomOwners[i]==user)
					return;
			}
			roomOwners[roomCount] = user;
			roomCount++;
		break;
		case USERINFO_REASON_ROOMCHANGE:
			printf("- user %s changed room  \n", LOBBY_GetUserName(user));
			if(user==LOBBY_GetUserByID(USERID_MYSELF)) // join/create room succeeded
			{
				menuState=MENU_LOBBY;
				selected=0;
			}
		break;
	}
}

int main(void) 
{
	int i,j;
	REG_EXMEMCNT=0xe800;

	powerON(POWER_ALL);
	REG_IME = 0 ;
	REG_IE = 0 ;
	REG_IF = 0xFFFF ;

	videoSetMode(0);	//not using the main screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
	vramSetBankC(VRAM_C_SUB_BG);

	SUB_BG0_CR = BG_MAP_BASE(31);

	BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

	//consoleInit() is a lot more flexible but this gets you up and running quick
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
	
	defaultExceptionHandler() ;

	irqInit() ;
	
	// Startup IPC engine
	IPC_Init() ;
	IPC_SetChannelCallback(0,&LWIFI_IPC_Callback) ;
//	IPC_SetMsgCompleteCallback(&IPC_RcvCompleteCheck) ;

	// usual VBlank
	irqSet(IRQ_VBLANK,&VBlankIRQ) ;
	irqEnable(IRQ_VBLANK) ;

	consoleClear();
	printf("\x1b[10;0H--------------------------------");
	
	LOBBY_Init() ;
	LOBBY_SetStreamHandler(0x0001,&receiveUserData);
	LOBBY_SetStreamHandler(0x0002,&receiveRoomData);
	LOBBY_SetUserInfoCallback(&userCallback);

	int max=1;

	while (1) 
	{
		// handle input
		scanKeys();
		switch(menuState)
		{
			case MENU_MAIN:
			{
				max = 1+roomCount;
				if(keysDown() & KEY_A)
				{
					if(selected==0) // go to create room menu
					{
						menuState=MENU_CREATE_ROOM;
						selected=0;
					}
					else // join existing room
					{
						LOBBY_JoinRoom(LOBBY_GetRoomByUser(roomOwners[selected-1]));
					}
				}
			}
			break;
	
			case MENU_CREATE_ROOM:
			{
				max = 5;
				if(keysDown() & KEY_RIGHT)
				{
					switch(selected)
					{
						case 0:
							if(++roomNameIndex>=ROOM_NAMES) roomNameIndex=0;
						break;

						case 1:
							if(++roomMaxUsers>8) roomMaxUsers=2;
						break;

						case 2:
							if(++roomGameCode>=65535) roomGameCode=1;
						break;

						case 3:
							if(++roomGameVersion>=65535) roomGameVersion=1;
						break;
					}
				}
				if(keysDown() & KEY_LEFT)
				{
					switch(selected)
					{
						case 0:
							if(--roomNameIndex<0) roomNameIndex = ROOM_NAMES-1;
						break;

						case 1:
							if(--roomMaxUsers<2) roomMaxUsers=8;
						break;

						case 2:
							if(--roomGameCode<1) roomGameCode=65535;
						break;

						case 3:
							if(--roomGameVersion<1) roomGameVersion=65535;
						break;
					}
				}
				if(keysDown() & KEY_B)
				{
					menuState = MENU_MAIN;
					selected=0;
				}
				if(keysDown() & KEY_A)
				{
					if(selected==4) // create a new room
					{
						LOBBY_CreateRoom(roomNames[roomNameIndex], roomMaxUsers, roomGameCode, roomGameVersion);
					}
				}
			}
			break;

			case MENU_LOBBY:
			{
				myRoom = LOBBY_GetRoomByUser(LOBBY_GetUserByID(USERID_MYSELF));
				int inc = (LOBBY_GetRoomUserBySlot(myRoom, 0)==LOBBY_GetUserByID(USERID_MYSELF)?1:0);
				max = 1 + LOBBY_GetUsercountInRoom(myRoom) + inc;
				if(keysDown() & KEY_A)
				{
					if(inc&&selected==0) // toggle room visibility
					{
						roomVisible = 1-roomVisible;
						LOBBY_SetRoomVisibility(roomVisible);
					}
					if(selected==inc) // leave room
					{
						LOBBY_LeaveRoom();
						menuState = MENU_MAIN;
						selected=0;
					}
					else if(selected==inc+1) // send message to all room members
						LOBBY_SendToRoom(myRoom, 0x0002, (unsigned char *)"hi all!", 8);
					else // send message to a specific room member
					{
						j=selected-inc-2;
						if(LOBBY_GetRoomUserBySlot(myRoom, j)==LOBBY_GetUserByID(USERID_MYSELF)) // skip sending messages to yourself
							j++;
						LOBBY_SendToUser(LOBBY_GetRoomUserBySlot(myRoom, j), 0x0001, (unsigned char *)"hi you!", 8);
					}
				}
			}
			break;
		}
		
		if (keysDown() & KEY_DOWN)
		{
			if(++selected>=max) selected = 0;
		}
		if (keysDown() & KEY_UP)
		{
			if(--selected<0) selected = max-1;
		}

		// handle output
		printf("\x1b[0;0H");
		for(i=0;i<10;i++) printf("                                "); // clear first 10 lines manually
		printf("\x1b[0;0H");
		j=0;
		switch(menuState)
		{
			case MENU_MAIN:
			{
				printf("=== room main ==================");
				printf("%s create room\n", (selected==j?"->":"  ")); j++;
				for(i=0;i<roomCount;i++)
				{
					LPLOBBY_ROOM roomInfo = LOBBY_GetRoomByUser(roomOwners[i]);
					if(roomInfo!=NULL)
					{
						printf("%s join room %s: %s [%d/%d]\n", 
							(selected==j?"->":"  "),
							LOBBY_GetUserName(LOBBY_GetRoomUserBySlot(roomInfo, 0)), // room owner is always in user slot 0
							LOBBY_GetRoomName(roomInfo),
							LOBBY_GetUsercountInRoom(roomInfo),
							LOBBY_GetMaxUsercountInRoom(roomInfo)
						);
						j++;
					}
				}
			}
			break;
	
			case MENU_CREATE_ROOM:
			{
				printf("=== create room ================");
				printf("%s room name: %s\n", (selected==j?"->":"  "), roomNames[roomNameIndex]); j++;
				printf("%s max usercount: %d\n", (selected==j?"->":"  "), roomMaxUsers); j++;
				printf("%s gamecode: %d\n", (selected==j?"->":"  "), roomGameCode); j++;
				printf("%s version: %d\n", (selected==j?"->":"  "), roomGameVersion); j++;
				printf("%s create room\n", (selected==j?"->":"  ")); j++;
			}
			break;

			case MENU_LOBBY:
			{
				printf("================================");
				printf("\x1b[0;3H");
				printf(" %s [%d/%d] v%d/gc:%d \n", 
					LOBBY_GetRoomName(myRoom), 
					LOBBY_GetUsercountInRoom(myRoom), 
					LOBBY_GetMaxUsercountInRoom(myRoom),
					LOBBY_GetRoomGameVersion(myRoom),
					LOBBY_GetRoomGameCode(myRoom)
				);
				if(LOBBY_GetRoomUserBySlot(myRoom, 0)==LOBBY_GetUserByID(USERID_MYSELF)) // we're leading this room
				{
					printf("%s is the room visible: %s\n", (selected==j?"->":"  "), (roomVisible?"yes":"no"));
					j++;
				}
				printf("%s leave room\n", (selected==j?"->":"  ")); j++;
				printf("%s send msg to all room users\n", (selected==j?"->":"  ")); j++;
				for(i=0;i<LOBBY_GetUsercountInRoom(myRoom);i++)
				{
					if(LOBBY_GetRoomUserBySlot(myRoom, i)!=LOBBY_GetUserByID(USERID_MYSELF)) // don't display yourself in the list
					{
						printf("%s send msg to user %s\n", (selected==j?"->":"  "), LOBBY_GetUserName(LOBBY_GetRoomUserBySlot(myRoom, i)));
						j++;
					}
				}
			}
			break;
		}
		swiWaitForVBlank() ;
	}

	return 0;
}
