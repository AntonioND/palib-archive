#include <nds.h>
#include <stdio.h>
#include "profiler.h"

#ifdef PROFILING

	FILE *				profiler_file			= 0 ;
	unsigned long		profiler_timer			= 0 ;
	unsigned long long	profiler_droppedTime	= 0 ;
	char *				profiler_filename		= 0 ;


	void PROFILER_timerIRQ(void)
	{
		REG_IF |= IRQ_TIMER3 ;
		profiler_timer++ ;
	}

	void PROFILER_NullTime(void)
	{
		PROFILER_GenerateState("Tara",999999) ;
		PROFILER_EnterState(999999) ;
		PROFILER_LeaveState(999999) ;
	}

	void PROFILER_Init(char *filename) 
	{
		int savedIME = REG_IME ;
		REG_IME = 0 ;
		profiler_file = fopen(filename,"wb+") ;
		profiler_filename = strdup(filename) ;
		fprintf(profiler_file,"Profiler started\n") ;
		profiler_timer = 0 ;
		irqSet(IRQ_TIMER3,&PROFILER_timerIRQ) ;
		irqEnable(IRQ_TIMER3) ;
		TIMER_DATA(3) = 0 ;
		TIMER_DATA(2) = 0 ;
		TIMER_DATA(1) = 0 ;
		TIMER_CR(3) = BIT(2) | TIMER_ENABLE | TIMER_IRQ_REQ ;
		TIMER_CR(2) = BIT(2) | TIMER_ENABLE ;
		TIMER_CR(1) = TIMER_ENABLE ;

		PROFILER_NullTime() ; // Get a reference on how long does it take to measure

		REG_IME = savedIME ;
	}

	unsigned long PROFILER_GetTimerTicksL(void)
	{
		return (((unsigned long long)TIMER_DATA(1)) | (((unsigned long long)TIMER_DATA(2)) << 16)) + profiler_droppedTime;
	}

	unsigned long PROFILER_GetTimerTicksH(void)
	{
		return (((((unsigned long long)TIMER_DATA(3)) << 32) | (((unsigned long long)profiler_timer) << 48)) + profiler_droppedTime) >> 32 ;
	}

	void PROFILER_Shutdown(void) 
	{
		if (profiler_file)
			fclose(profiler_file) ;
	}

	void PROFILER_GenerateState(char *stateName, unsigned long id) 
	{
		int savedIME = REG_IME ;
		REG_IME = 0 ;
		if (profiler_file)
		{
			fprintf(profiler_file,"STATEINFO: %s = %d\n",stateName,id) ;
		}
		REG_IME = savedIME ;
	}

	void PROFILER_EnterState(unsigned long id) 
	{
		int savedIME = REG_IME ;
		REG_IME = 0 ;
		TIMER_CR(1) &= ~TIMER_ENABLE ;	// we don't want to measure our own time
		unsigned short savedTS1 = TIMER_DATA(1) ;

		if (profiler_file)
		{
			fprintf(profiler_file,"ENTER: %08d at %08x%08x\r\n",id,PROFILER_GetTimerTicksH(),PROFILER_GetTimerTicksL()) ;
		}

		profiler_droppedTime += TIMER_DATA(1) ;
		TIMER_DATA(1) = 0 ;
		TIMER_CR(1) |= TIMER_ENABLE ;
		REG_IME = savedIME ;
	}

	void PROFILER_LeaveState(unsigned long id) 
	{
		int savedIME = REG_IME ;
		REG_IME = 0 ;
		TIMER_CR(1) &= ~TIMER_ENABLE ;	// we don't want to measure our own time
		unsigned short savedTS1 = TIMER_DATA(1) ;

		if (profiler_file)
		{
			fprintf(profiler_file,"LEAVE: %08d at %08x%08x\r\n",id,PROFILER_GetTimerTicksH(),PROFILER_GetTimerTicksL()) ;
			//fclose(profiler_file) ;
			//profiler_file = fopen(profiler_filename,"wb") ;
			//fseek(profiler_file,0,SEEK_END) ;
		}

		profiler_droppedTime += TIMER_DATA(1) ;
		TIMER_DATA(1) = 0 ;
		TIMER_CR(1) |= TIMER_ENABLE ;

		REG_IME = savedIME ;
	}

#endif
