/* 

	DS to DS Lobby

*/

#include "802.3snap.h"
#include "802.11.h"
#include "lobby.h"
#include <string.h>
#include "profiler.h"

#ifdef WIN32
	#define safe_malloc	malloc
	#define safe_free free 
	#define BIT(n) (1 << (n))
#else
	#include "safe_malloc.h"
#endif

#ifdef ARM9
	#include <nds.h>
#endif

#define PROTOCOL_ID_LOBBY		0x08FE
#define STREAM_ACK				0xFFFF
#define STREAM_ROOM				0x7FFF
#define STREAM_HANDSHAKE		0x7FFE

#define BROADCAST_INTERVAL		30

#define STATISTIC_RECVIEVED_BYTES		0
#define STATISTIC_RECEIVED_CHUNKS		1
#define STATISTIC_SENT_BYTES			2
#define STATISTIC_SENT_CHUNKS			3
#define MAX_STATISTIC					3

// receive filter size has to be 2^n for speed optimizing
#define RECEIVEFILTER_SIZE				128		

#ifdef WIN32

	#include <windows.h>

	typedef int bool ;
	#define false 0 ;
	#define true !false ;
#endif

enum LOBBY_STATE
{
	LOBBY_STATE_STARTUP,
	LOBBY_STATE_SCANNING,
	LOBBY_STATE_ACTIVE
} ;

enum LOBBY_CHUNK
{
	LOBBY_CHUNK_REQID,
	LOBBY_CHUNK_SHOWID,
	LOBBY_CHUNK_TRANSFER
} ;

typedef struct LOBBY_ACKDATA
{
	unsigned char *				data ;
	int							length ;
	unsigned short				ID ;

	struct LOBBY_ACKDATA *		next ;
} LOBBY_ACKDATA, *LPLOBBY_ACKDATA ;

struct LOBBY_ROOM
{
	int						maxUsers ;
	int						numOfUsers ;
	unsigned short			gameCode ;
	unsigned short			gameVersion ;
	char 					name[32] ;
	struct LOBBY_USER **	users ;
	struct LOBBY_ROOM *		next ;
	unsigned long			flags ;
	unsigned short			roomOwnerCreatedCRC ;
} ;

typedef struct LOBBY_OOOCACHE
{
	unsigned short				streamID ;
	unsigned short				ID ;
	unsigned char *				data ;
	int							length ;
	struct LOBBY_OOOCACHE *		next ;
	struct LOBBY_OOOCACHE *		last ;
} LOBBY_OOOCACHE, *LPLOBBY_OOOCACHE ;

struct LOBBY_USER
{
	unsigned char		mac[6] ;
	unsigned char		name[32] ;

	unsigned long		synchState ;

	unsigned long		timeout ;
	unsigned short		needToDeliverID ;
	unsigned short		needToDeliverACK ;
	unsigned short		nextInOrderID ;
	unsigned short		remoteDeliverID ;

	LPLOBBY_OOOCACHE	OOOCache ;
	unsigned short *	ackCache ;

	unsigned short		multiReceiveFilterData[RECEIVEFILTER_SIZE] ; 
	unsigned short		multiReceiveFilterHead ;
	unsigned short		multiReceiveFilterNum ;

	LPLOBBY_ROOM		room ;
	LPLOBBY_ACKDATA		acks ;

	struct LOBBY_USER *	next ;
} ;

typedef struct LOBBY_STREAMHANDLER
{
	unsigned short				streamID ;
	LOBBY_STREAMHANDLER_PROC	callback ;
	struct LOBBY_STREAMHANDLER *next ;
} LOBBY_STREAMHANDLER, *LPLOBBY_STREAMHANDLER ;

typedef struct LOBBY_DATASTRUCT
{
	unsigned long					state ;
	unsigned char					channel ;

	unsigned long					updateTimeout ;
	unsigned long					updateCounter ;
	LPLOBBY_USER					users ;

	LOBBY_USER						myself ;
	LOBBY_ROOM						room ;
	LPLOBBY_ROOM					rooms ;

	LPLOBBY_STREAMHANDLER			streams ;
	LOBBY_USERINFOHANDLER_PROC		userInfoCallback ;

	unsigned char *					msgCollectorData ;
	unsigned short					msgCollectorSize ;
	unsigned short					msgCollectorPos ;
	LPLOBBY_USER					msgCollectorUser ;
	
	unsigned long					statistics[MAX_STATISTIC+1] ;
} LOBBY_DATASTRUCT, *LPLOBBY_DATASTRUCT ;

typedef struct LOBBY_CHUNKHEADER
{
	unsigned short		chunkTypeID ;
	unsigned short		lastNeedToDeliverID ;
} LOBBY_CHUNKHEADER, *LPLOBBY_CHUNKHEADER ;

typedef struct LOBBY_REQID_BROADCAST_CHUNK
{
	LOBBY_CHUNKHEADER			header ;
	unsigned char				answerToMAC[6] ;
} LOBBY_REQID_BROADCAST_CHUNK, *LPLOBBY_REQID_BROADCAST_CHUNK ;

typedef struct LOBBY_SHOWID_CHUNK
{
	LOBBY_CHUNKHEADER			header ;
	unsigned char				answerMAC[6] ;
	unsigned char				answerName[32] ;
	unsigned char				roomLeader[6] ;
	unsigned short				roomCRC ;
} LOBBY_SHOWID_CHUNK, *LPLOBBY_SHOWID_CHUNK ;

typedef struct LOBBY_HANDSHAKE_CHUNK
{
	LOBBY_CHUNKHEADER			header ;
	unsigned short				sequence ;
	unsigned short				lowestMissingAck ;
} LOBBY_HANDSHAKE_CHUNK, *LPLOBBY_HANDSHAKE_CHUNK ;

typedef struct LOBBY_DATATRANSFER_CHUNK
{
	LOBBY_CHUNKHEADER			header ;
	unsigned short				stream ;
	unsigned short				length ;
} LOBBY_DATATRANSFER_CHUNK, *LPLOBBY_DATATRANSFER_CHUNK ;

typedef struct LOBBY_ROOMINFO_CHUNK
{
	unsigned short				sequence ;
	unsigned short				gameCode ;
	unsigned short				gameVersion ;
	unsigned short				maxUsers ;
	unsigned short				curUsers ;
	char						name[32] ;
	unsigned char				userMACs[8 * 6] ;
	unsigned short				roomOwnerCreatedCRC ;
} LOBBY_ROOMINFO_CHUNK, *LPLOBBY_ROOMINFO_CHUNK ;

LPLOBBY_DATASTRUCT currentLobby = 0 ;


int LOBBY_LockSystem(int newLock)
{
	#ifdef WIN32
	#else
		int old = REG_IME ;
		REG_IME = newLock ;
		return old ;
	#endif
}

#define PSTATE_ACKSTREAMHANDLER			0
#define PSTATE_ADDDATATOACK				1
#define PSTATE_ADDTOACKCACHE			2
#define PSTATE_ALREADYRECEIVED			3
#define PSTATE_BROADCAST				4
#define PSTATE_BROADCASTID				5
#define PSTATE_CLEARACKCACHE			6
#define PSTATE_CLEARACKS				7
#define PSTATE_CLEARRECEIVES			8
#define PSTATE_CREATEROOM				9
#define PSTATE_FLUSHACKCACHE			10
#define PSTATE_FLUSHCOLLECTOR			11
#define PSTATE_GETMAXUSERCOUNTINROOM	12
#define PSTATE_GETNUMBEROFKNOWNROOMS	13
#define PSTATE_GETNUMBEROFKNOWNUSERS	14
#define PSTATE_GETROOMBYGAME			15
#define PSTATE_GETROOMBYID				16
#define PSTATE_GETROOMBYMAC				17
#define PSTATE_GETROOMBYUSER			18
#define PSTATE_GETROOMGAMECODE			19
#define PSTATE_GETROOMGAMEVERSION		20
#define PSTATE_GETUSERBYID				21
#define PSTATE_GETUSERBYMAC				22
#define PSTATE_GETUSERCOUNTINROOM		23
#define PSTATE_GETUSERNAME				24
#define PSTATE_HANDLEACK				25
#define PSTATE_INIT						26
#define PSTATE_ISTIMEDOUT				27
#define PSTATE_JOINROOM					28
#define PSTATE_LEAVEROOM				29
#define PSTATE_OOOENQUERECEIVED			30
#define PSTATE_PREPARECOLLECTOR			31
#define PSTATE_RECVCALLBACK				32
#define PSTATE_RECVCHUNK				33
#define PSTATE_REMEMBERRECEIVED			34
#define PSTATE_RESENDUNACKED			35
#define PSTATE_ROOMSTREAMCALLBACK		36
#define PSTATE_SENDTOALL				37
#define PSTATE_SENDTOROOM				38
#define PSTATE_SENDTOUSER				39
#define PSTATE_SENDVIACOLLECTOR			40
#define PSTATE_SETSTREAMHANDLER			41
#define PSTATE_SETUSERINFOCALLBACK		42
#define PSTATE_SHUTDOWN					43
#define PSTATE_UPDATE					44
#define PSTATE_UPDATEROOM				45
#define PSTATE_UPDATEUSER				46
#define PSTATE_USERISALLSENT			47
#define PSTATE_USERISSTREAMSENT			48
#define PSTATE_USERRESETTIMEOUT			49
#define PSTATE_GETROOMUSERBYSLOT		50
#define PSTATE_SETROOMVISIBILITY		51
#define PSTATE_GETROOMNAME				52
#define PSTATE_SENDROOMINFO				53
#define PSTATE_SETOWNNAME				54


void LOBBY_SetOwnName(char *name)
{
	int lock ;
	PROFILER_EnterState(PSTATE_SETOWNNAME) ;
	lock = LOBBY_LockSystem(0) ;
	if ((!currentLobby) || (!name))
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_SETOWNNAME) ;
		return ;
	}
	strncpy((char *)currentLobby->myself.name,name,32) ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_SETOWNNAME) ;
}

void LOBBY_CalculateRoomCRC(void)
{
	int lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		return ;
	}
	char *fullbuffer = (char *)safe_malloc(sizeof(LOBBY_ROOM)+currentLobby->room.maxUsers * sizeof(LPLOBBY_USER)) ;
	currentLobby->room.roomOwnerCreatedCRC = 0 ;
	memcpy(fullbuffer,&currentLobby->room,sizeof(LOBBY_ROOM)) ;
	memcpy(fullbuffer+sizeof(LOBBY_ROOM),currentLobby->room.users,currentLobby->room.maxUsers * sizeof(LPLOBBY_USER)) ;
	#ifndef WIN32
		currentLobby->room.roomOwnerCreatedCRC = swiCRC16(0,fullbuffer,(sizeof(LOBBY_ROOM)+currentLobby->room.maxUsers * sizeof(LPLOBBY_USER)) / 2) ;
	#endif
	safe_free(fullbuffer) ;
	LOBBY_LockSystem(lock) ;
}

void LOBBY_UpdateRoom(unsigned char *mac, unsigned short maxUsers, unsigned short curUsers, unsigned char *MACs, char *name, unsigned short gameCode, unsigned short gameVersion, unsigned short crc)
{
	LPLOBBY_ROOM tmp ;
	int lock ;
	PROFILER_EnterState(PSTATE_UPDATEROOM) ;
	tmp = LOBBY_GetRoomByMAC(mac) ;
	lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_UPDATEROOM) ;
		return ;
	}
	if (tmp)
	{
		// max users is not allowed to change on-the-fly yet
		int i ;
		if (maxUsers!=tmp->maxUsers) 
		{
			LOBBY_LockSystem(lock) ;
			PROFILER_LeaveState(PSTATE_UPDATEROOM) ;
			return ;
		}
		tmp->gameCode = gameCode ;
		tmp->gameVersion = gameVersion ;
		tmp->roomOwnerCreatedCRC = crc ;
		for (i=0;i<maxUsers;i++)
		{
			LPLOBBY_USER user = LOBBY_GetUserByMAC(&MACs[i*6]) ;
			if (user)
			{
				tmp->users[i] = user ;
				if (tmp->users[i]->room != tmp)
				{
					// join succeeded!
					if (currentLobby->userInfoCallback)
						currentLobby->userInfoCallback(tmp->users[i],USERINFO_REASON_ROOMCHANGE) ;
				} ;
				tmp->users[i]->room = tmp ;
			} else
			{
				tmp->users[i] = user ;
				//if (tmp->users[i]->room == tmp)
				//{
				//	// left room
				//	if (currentLobby->userInfoCallback)
				//		currentLobby->userInfoCallback(tmp->users[i],USERINFO_REASON_ROOMCHANGE) ;
				//} ;
				//tmp->users[i]->room = 0 ;
			}
		}
		tmp->numOfUsers = curUsers ;
		strncpy(&tmp->name[0],name,32) ;
	} else
	{
		int i ;
		if (currentLobby->userInfoCallback)
			currentLobby->userInfoCallback(LOBBY_GetUserByMAC(MACs),USERINFO_REASON_ROOMCREATED) ;
		tmp = (LPLOBBY_ROOM)safe_malloc(sizeof(LOBBY_ROOM)) ;
		tmp->maxUsers = maxUsers ;
		tmp->numOfUsers = curUsers ;
		tmp->gameCode = gameCode ;
		tmp->gameVersion = gameVersion ;
		tmp->flags = 0 ;
		tmp->roomOwnerCreatedCRC = crc ;
		tmp->users = (LPLOBBY_USER *)safe_malloc(sizeof(LPLOBBY_USER)*maxUsers) ;
		// rebuild INVISIBLE flag
		if (MACs[0] & BIT(1))
		{
			tmp->flags |= ROOMFLAG_INVISIBLE ;
			MACs[0] &= ~ BIT(1) ;
		}
		for (i=0;i<maxUsers;i++)
		{
			tmp->users[i] = LOBBY_GetUserByMAC(&MACs[i*6]) ;
		}
		strncpy(&tmp->name[0],name,32) ;
		tmp->next = currentLobby->rooms ;
		currentLobby->rooms = tmp ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_UPDATEROOM) ;
}


void LOBBY_JoinRoom(LPLOBBY_ROOM room)
{
	LPLOBBY_ROOMINFO_CHUNK req ;
	PROFILER_EnterState(PSTATE_JOINROOM) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_JOINROOM) ;
		return ;
	}
	req = (LPLOBBY_ROOMINFO_CHUNK)safe_malloc(sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	req->sequence = 2 ;
	LOBBY_SendToRoom(room,STREAM_ROOM,(unsigned char *)req,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	safe_free(req) ;
	PROFILER_LeaveState(PSTATE_JOINROOM) ;
}

void LOBBY_LeaveRoom(void)
{
	LPLOBBY_ROOMINFO_CHUNK req ;
	LPLOBBY_ROOM room ;
	PROFILER_EnterState(PSTATE_LEAVEROOM) ;
	room = currentLobby->myself.room ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_LEAVEROOM) ;
		return ;
	}
	if (room==&currentLobby->room) 
	{
		PROFILER_LeaveState(PSTATE_LEAVEROOM) ;
		return ; // can't leave the owned room. Need to destroy it
	}
	req = (LPLOBBY_ROOMINFO_CHUNK)safe_malloc(sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	req->sequence = 4 ;
	LOBBY_SendToUser(room->users[0],STREAM_ROOM,(unsigned char *)req,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	safe_free(req) ;
	PROFILER_LeaveState(PSTATE_LEAVEROOM) ;
}

void LOBBY_SetRoomVisibility(int visible)
{
	LPLOBBY_ROOM room ;
	PROFILER_EnterState(PSTATE_SETROOMVISIBILITY) ;
	room = currentLobby->myself.room ;
	if (!room&&room!=&currentLobby->room)
	{
		PROFILER_LeaveState(PSTATE_SETROOMVISIBILITY) ;
		return;
	}
	// we're the room owner, set the owner mac address locally administrated bit accordingly
	// manipulatig the user's mac is also changing the user's broadcasts, not only the room info
	// instead we flag the room as invisible instead and modify the local administered bit in the roominfo
	if(!visible)
		room->flags |= ROOMFLAG_INVISIBLE ;
	else
		room->flags &= ~ROOMFLAG_INVISIBLE ;
	PROFILER_LeaveState(PSTATE_SETROOMVISIBILITY) ;
}


LPLOBBY_ROOM LOBBY_GetRoomByID(unsigned long id)
{
	LPLOBBY_ROOM tmp ;
	int i = 0 ;
	PROFILER_EnterState(PSTATE_GETROOMBYID) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYID) ;
		return 0 ;
	}
	if (id == ROOMID_MYROOM)
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYID) ;
		return currentLobby->myself.room ;
	}
	tmp = currentLobby->rooms ;
	while (tmp)
	{
		if (i==id) 
		{
			PROFILER_LeaveState(PSTATE_GETROOMBYID) ;
			return tmp ;
		}
		i++ ;
		tmp = tmp->next ;
	}
	PROFILER_LeaveState(PSTATE_GETROOMBYID) ;
	return 0 ;
}

void LOBBY_SendRoomInfo(LPLOBBY_ROOM room,LPLOBBY_USER user)
{
	LPLOBBY_ROOMINFO_CHUNK roomInfo = 0 ;
	int lock,i ;
	PROFILER_EnterState(PSTATE_SENDROOMINFO) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_SENDROOMINFO) ;
		return ;
	}
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_SENDROOMINFO) ;
		return ;
	}
	roomInfo = (LPLOBBY_ROOMINFO_CHUNK)safe_malloc(sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	if (!roomInfo)
	{
		PROFILER_LeaveState(PSTATE_SENDROOMINFO) ;
		return ;
	}
	lock = LOBBY_LockSystem(0) ;
	memset(roomInfo,0,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	roomInfo->sequence = 1 ;
	roomInfo->maxUsers = room->maxUsers ;
	roomInfo->curUsers = room->numOfUsers ;
	roomInfo->gameCode = room->gameCode ;
	roomInfo->gameVersion = room->gameVersion ;
	roomInfo->roomOwnerCreatedCRC = room->roomOwnerCreatedCRC ;
	strncpy(&roomInfo->name[0],&room->name[0],32) ;
	for (i=0;i<roomInfo->maxUsers;i++)
	{
		if (currentLobby->room.users[i])
			memcpy(&roomInfo->userMACs[i*6],room->users[i]->mac,6) ;
		else
			memset(&roomInfo->userMACs[i*6],0,6) ;
	}
	if (room->flags & ROOMFLAG_INVISIBLE) 
	{
		// set the roomowner mac as locally administered
		roomInfo->userMACs[0] |= BIT(1) ;
	}
	LOBBY_LockSystem(lock) ;
	if (!user)
		LOBBY_SendToRoom(room,STREAM_ROOM,(unsigned char *)roomInfo,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	else
		LOBBY_SendToUser(user,STREAM_ROOM,(unsigned char *)roomInfo,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
	safe_free(roomInfo) ;
	PROFILER_LeaveState(PSTATE_SENDROOMINFO) ;
}

void LOBBY_HandshakeStreamCallback(unsigned char *data, int length, LPLOBBY_USER from) 
{
	// do nothing, just a dummy to have the stream received
	// the content of this stream is not important, the receive is
}

void LOBBY_RoomStreamCallback(unsigned char *data, int length, LPLOBBY_USER from) 
{
	LPLOBBY_ROOMINFO_CHUNK roomInfo ;
	PROFILER_EnterState(PSTATE_ROOMSTREAMCALLBACK) ;
	roomInfo = (LPLOBBY_ROOMINFO_CHUNK)&data[0] ;
	if(!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_ROOMSTREAMCALLBACK) ;
		return ;
	}
	switch (roomInfo->sequence)
	{
		case 0:
			// room info request
			// reply a room info if we own one, we even reply 
			if (currentLobby->room.users) // && ((currentLobby->room.users[0]->mac[0]!=0x02) || (LOBBY_GetRoomByUser(from)==&currentLobby->room))) // mac visibility check, keep in mind that we are not invis for our members
			{
				LOBBY_SendRoomInfo(&currentLobby->room,from) ;
			}
			break ;
		case 1:
			// room info
			LOBBY_UpdateRoom(&roomInfo->userMACs[0],roomInfo->maxUsers,roomInfo->curUsers,roomInfo->userMACs,roomInfo->name,roomInfo->gameCode,roomInfo->gameVersion,roomInfo->roomOwnerCreatedCRC) ;
			break ;
		case 2:
			// room join request
			if (currentLobby->room.users && currentLobby->room.users[0]->mac[0]!=0x02) // mac visibility check
			{
				int i ;
				for (i=0;i<currentLobby->room.maxUsers;i++)
				{
					if (!currentLobby->room.users[i])
					{
						currentLobby->room.users[i] = from ;
						currentLobby->room.numOfUsers++ ;
						// the roominfo have changed, update the crc
						LOBBY_CalculateRoomCRC() ;
						// ok, we have placed the newcomer
						// he (and the others) will see himself as member of the group on the next info update we will now provide
						LOBBY_SendRoomInfo(&currentLobby->room,0) ;
						PROFILER_LeaveState(PSTATE_ROOMSTREAMCALLBACK) ;
						return ;
					}
				}
			}
			break  ;
		case 4:
			// leave room
			// only handle, if we are the room owner
			if (currentLobby->users)
			{
				int i ;
				for (i=0;i<currentLobby->room.maxUsers;i++)
				{
					if (currentLobby->room.users[i]==from)
					{
						currentLobby->room.users[i] = 0 ;
						currentLobby->room.numOfUsers -- ;
						// the roominfo have changed, update the crc
						LOBBY_CalculateRoomCRC() ;
					}
				}
			}
			break ;
		default:
			break ;
	}
	PROFILER_LeaveState(PSTATE_ROOMSTREAMCALLBACK) ;
}

void LOBBY_CreateRoom(char *name, int maxUsers, unsigned short gameCode, unsigned short gameVersion)
{
	LPLOBBY_USER *users ;
	int i ;
	int lock ;
	PROFILER_EnterState(PSTATE_CREATEROOM) ;
	lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_CREATEROOM) ;
		return ;
	}
	// limit maximum users to fit protocol space
	if (maxUsers > 8) maxUsers = 8 ;
	users = (LPLOBBY_USER *)safe_malloc(sizeof(LPLOBBY_USER)*maxUsers) ;
	for (i=1;i<maxUsers;i++)
	{
		users[i] = 0 ;
	}
	memcpy(&currentLobby->myself.mac[0],ownMAC,6) ;
	users[0] = &currentLobby->myself ;
	strncpy(&currentLobby->room.name[0],name,32) ;
//	memset(&currentLobby->room.name[0],0,32) ;
	currentLobby->room.users = users ;
	currentLobby->room.numOfUsers = 1 ;		// only ourself
	currentLobby->room.maxUsers = maxUsers ;
	currentLobby->room.gameCode = gameCode ;
	currentLobby->room.gameVersion = gameVersion ;
	currentLobby->room.flags = 0 ;
	currentLobby->myself.room = &currentLobby->room ;
	// the roominfo have changed, update the crc
	LOBBY_CalculateRoomCRC() ;
	if (currentLobby->userInfoCallback)
		currentLobby->userInfoCallback(&currentLobby->myself,USERINFO_REASON_ROOMCHANGE) ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_CREATEROOM) ;
}

void LOBBY_PrepareCollector(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_PREPARECOLLECTOR) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_PREPARECOLLECTOR) ;
		return ;
	}
	currentLobby->msgCollectorSize = 500 ;
	currentLobby->msgCollectorPos = 0 ;
	if (!currentLobby->msgCollectorData)
		currentLobby->msgCollectorData = (unsigned char *)safe_malloc( currentLobby->msgCollectorSize ) ;
	currentLobby->msgCollectorUser = user ;
	PROFILER_LeaveState(PSTATE_PREPARECOLLECTOR) ;
}

void LOBBY_FlushCollector(void)
{
	PROFILER_EnterState(PSTATE_FLUSHCOLLECTOR) ;
	if (!currentLobby)
	{
		PROFILER_LeaveState(PSTATE_FLUSHCOLLECTOR) ;
		return ;
	}
	if (!currentLobby->msgCollectorPos) 
	{
		PROFILER_LeaveState(PSTATE_FLUSHCOLLECTOR) ;
		return ;
	}
	if (!currentLobby->msgCollectorData) 
	{
		PROFILER_LeaveState(PSTATE_FLUSHCOLLECTOR) ;
		return ;
	}
	Send802_3snapTo(PROTOCOL_ID_LOBBY,currentLobby->msgCollectorData,currentLobby->msgCollectorPos,currentLobby->msgCollectorUser->mac) ;
	currentLobby->msgCollectorPos = 0 ;
	PROFILER_LeaveState(PSTATE_FLUSHCOLLECTOR) ;
}

void LOBBY_SendViaCollector(unsigned char *data, int length)
{
	PROFILER_EnterState(PSTATE_SENDVIACOLLECTOR) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_SENDVIACOLLECTOR) ;
		return ;
	}
	if (length > currentLobby->msgCollectorSize) 
	{
		// does not match into any collector, send directly
		Send802_3snapTo(PROTOCOL_ID_LOBBY,data,length,currentLobby->msgCollectorUser->mac) ;
		PROFILER_LeaveState(PSTATE_SENDVIACOLLECTOR) ;
		return ;
	}

	if (length > currentLobby->msgCollectorSize - currentLobby->msgCollectorPos)
	{
		// this does not match anymore into this collector, so send what is within
		// and start over with a new empty collector
//		printf("Collector size exceeded\n") ;
		// we will drop those packets. This will limit the transfer rate for now
		// this shall be for debug only
		PROFILER_LeaveState(PSTATE_SENDVIACOLLECTOR) ;
		return ;
		LOBBY_FlushCollector() ;
	}

	memcpy(currentLobby->msgCollectorData+currentLobby->msgCollectorPos,data,length) ;
	currentLobby->msgCollectorPos += (length + 3) & ~3 ;
	PROFILER_LeaveState(PSTATE_SENDVIACOLLECTOR) ;
}

void LOBBY_ResendUnacked(LPLOBBY_USER user)
{
	LPLOBBY_ACKDATA acks ;
	int lock ;
	PROFILER_EnterState(PSTATE_RESENDUNACKED) ;
	lock = LOBBY_LockSystem(0) ;
	acks = user->acks ;
	LOBBY_PrepareCollector(user) ;
	while (acks)
	{
		if (acks->data)
		{
			// only resend the data, if we are synced
			// if we are not synced we will still send on tha handshake stream
			if ((user->synchState != 0) || (((LPLOBBY_DATATRANSFER_CHUNK)acks->data)->stream == STREAM_HANDSHAKE))
			{
				LOBBY_SendViaCollector(acks->data,acks->length) ;
			} else if (user->synchState == 0)
			{
				// check if the handshake was received
				if (LOBBY_UserIsStreamSent(user,STREAM_HANDSHAKE))
				{
					user->synchState = 1 ;
				}
			}

		}
		acks = acks->next ;
	}
	LOBBY_FlushCollector() ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_RESENDUNACKED) ;
}

void LOBBY_ClearAcks(LPLOBBY_USER user)
{
	int lock ;
	PROFILER_EnterState(PSTATE_CLEARACKS) ;
	lock = LOBBY_LockSystem(0) ;
	if (user)
	{
		LPLOBBY_ACKDATA tmp = user->acks ;
		user->acks = 0 ;
		while (tmp)
		{
			LPLOBBY_ACKDATA nxt = tmp->next ;
			safe_free(tmp->data) ;
			safe_free(tmp) ;
			tmp = nxt ;
		}
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_CLEARACKS) ;
}

void LOBBY_ClearReceives(LPLOBBY_USER user)
{
	int lock ;
	PROFILER_EnterState(PSTATE_CLEARRECEIVES) ;
	lock = LOBBY_LockSystem(0) ;
	if (user)
	{
		// clear OOO-Cache
		LPLOBBY_OOOCACHE tmp = user->OOOCache ;
		user->OOOCache = 0 ;
		while (tmp)
		{
			LPLOBBY_OOOCACHE nxt = tmp->next ;
			safe_free(tmp->data) ;
			safe_free(tmp) ;
			tmp = nxt ;
		}
		// clear receive filter
		user->multiReceiveFilterHead = 0 ;
		user->multiReceiveFilterNum = 0 ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_CLEARRECEIVES) ;
}

void LOBBY_AddDataToAck(LPLOBBY_USER user, unsigned char *data, int length)
{
	int lock ;
	PROFILER_EnterState(PSTATE_ADDDATATOACK) ;
	lock = LOBBY_LockSystem(0) ;
	if (!user) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_ADDDATATOACK) ;
		return ;
	}
	if (!user->timeout) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_ADDDATATOACK) ;
		return ; // can't send to station that is timed out
	}
	if (!user->acks)
	{
		// create the first entry
		LPLOBBY_ACKDATA na = (LPLOBBY_ACKDATA)safe_malloc(sizeof(LOBBY_ACKDATA)) ;
		na->data = (unsigned char *)safe_malloc(length) ;
		memcpy(na->data,data,length) ;
		// the needToDeliverID of the user might have changed since packet creation. retrieve it from the packet instead
		// user->acks->ID = user->needToDeliverID ;
		na->ID = ((LPLOBBY_CHUNKHEADER)data)->lastNeedToDeliverID ;
		na->length = length ;
		na->next = 0 ;
		na->next = user->acks ;
		user->acks = na ;
	} else
	{
		LPLOBBY_ACKDATA tmp = user->acks ;
		while (tmp->data)
		{
			if (!tmp->next)
			{
				// create a new entry
				LPLOBBY_ACKDATA na = (LPLOBBY_ACKDATA)safe_malloc(sizeof(LOBBY_ACKDATA)) ;
				na->data = (unsigned char *)safe_malloc(length) ;
				memcpy(na->data,data,length) ;
				na->ID = ((LPLOBBY_CHUNKHEADER)data)->lastNeedToDeliverID ;
				na->length = length ;
				na->next = 0 ;
				tmp->next = na ;
				LOBBY_LockSystem(lock) ;
				PROFILER_LeaveState(PSTATE_ADDDATATOACK) ;
				return ;
			}
			tmp = tmp->next ;
		}
		// a zero entry is an empty entry
		tmp->data = (unsigned char *)safe_malloc(length) ;
		tmp->length = length ;
		memcpy(tmp->data,data,length) ;
		tmp->ID = ((LPLOBBY_CHUNKHEADER)data)->lastNeedToDeliverID ;
//		printf("%d shall be acked (c)\n",tmp->ID) ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_ADDDATATOACK) ;
}

void LOBBY_HandleACK(LPLOBBY_USER user, unsigned short ID)
{
	LPLOBBY_ACKDATA tmp, last = 0 ;
	int lock ;
	PROFILER_EnterState(PSTATE_HANDLEACK) ;
	lock = LOBBY_LockSystem(0) ;
	if (!user) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_HANDLEACK) ;
		return ;
	}
	tmp = user->acks ;
	while (tmp)
	{
		if (tmp->ID == ID)
		{
			tmp->ID = 0 ;
			safe_free(tmp->data) ;
			tmp->length = 0 ;
			tmp->data = 0 ;
			if (last)
			{
				last->next = tmp->next ;
			} else
			{
				user->acks = tmp->next ;
			}
			safe_free(tmp) ;
			LOBBY_LockSystem(lock) ;
			PROFILER_LeaveState(PSTATE_HANDLEACK) ;
			return ;
		}
		last = tmp ;
		tmp = tmp->next ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_HANDLEACK) ;
}

void LOBBY_AckStreamHandler(unsigned char *data, int length, LPLOBBY_USER from)
{
	unsigned short *num = (unsigned short *)data ;
	int i ;
	PROFILER_EnterState(PSTATE_ACKSTREAMHANDLER) ;
	for (i=0;i<*num;i++)
	{
		unsigned short *ackedID = (unsigned short *)(data+2+i*2) ;
		LOBBY_HandleACK(from,*ackedID) ;
	}
	PROFILER_LeaveState(PSTATE_ACKSTREAMHANDLER) ;
}

void LOBBY_SetStreamHandler(unsigned short streamID, LOBBY_STREAMHANDLER_PROC callback)
{
	int lock ;
	PROFILER_EnterState(PSTATE_SETSTREAMHANDLER) ;
	lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_SETSTREAMHANDLER) ;
		return ;
	}
	if (!currentLobby->streams)
	{
		// this is the first stream to register
		LPLOBBY_STREAMHANDLER n ;
		n = (LPLOBBY_STREAMHANDLER)safe_malloc(sizeof(LOBBY_STREAMHANDLER)) ;
		n->streamID = streamID ;
		n->callback = callback ;
		n->next = 0 ;
		currentLobby->streams = n ;
	} else
	{
		LPLOBBY_STREAMHANDLER tmp = currentLobby->streams ;
		while (tmp->streamID != streamID)
		{
			if (!tmp->next)
			{
				LPLOBBY_STREAMHANDLER n ;
				n = (LPLOBBY_STREAMHANDLER)safe_malloc(sizeof(LOBBY_STREAMHANDLER)) ;
				n->streamID = streamID ;
				n->callback = callback ;
				n->next = 0 ;
				tmp->next = n ;
				LOBBY_LockSystem(lock) ;
				PROFILER_LeaveState(PSTATE_SETSTREAMHANDLER) ;
				return ;
			}
			tmp=tmp->next ;
		} 
		tmp->callback = callback ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_SETSTREAMHANDLER) ;
}

void LOBBY_BroadcastID(void)
{
	LOBBY_SHOWID_CHUNK showid ;
	PROFILER_EnterState(PSTATE_BROADCASTID) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_BROADCASTID) ;
		return ;
	}
	memset(&showid,0,sizeof(showid)) ;
	showid.header.chunkTypeID = LOBBY_CHUNK_SHOWID ;
	memcpy(showid.answerName,&currentLobby->myself.name[0],32) ;
	memcpy(showid.answerMAC,ownMAC,6) ;
	showid.header.lastNeedToDeliverID = 0 ;		// this is a broadcast, thus every target has a different ntdID
	if (currentLobby->myself.room)
	{
		memcpy(showid.roomLeader,currentLobby->myself.room->users[0]->mac,6) ;
		if (currentLobby->myself.room->flags & ROOMFLAG_INVISIBLE)
		{
			showid.roomLeader[0] |= BIT(1) ;
		}
		showid.roomCRC = currentLobby->room.roomOwnerCreatedCRC ;
	} else
	{
		memset(showid.roomLeader,0x00,6) ;
		showid.roomCRC = 0 ;
	}
	Send802_3snap(PROTOCOL_ID_LOBBY,(unsigned char *)&showid,sizeof(showid)) ;
	PROFILER_LeaveState(PSTATE_BROADCASTID) ;
}

void LOBBY_SendToUser(LPLOBBY_USER user,unsigned short stream, unsigned char *data, int length)
{
	int lock ;
	LPLOBBY_DATATRANSFER_CHUNK transfer ;
	unsigned char *dataStream ;
	PROFILER_EnterState(PSTATE_SENDTOUSER) ;
	transfer = (LPLOBBY_DATATRANSFER_CHUNK)safe_malloc(((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)+length) ;
	lock = LOBBY_LockSystem(0) ;
	if (!user) 
	{
		safe_free(transfer) ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_SENDTOUSER) ;
		return ;
	}
	if (user == &currentLobby->myself) 
	{
		safe_free(transfer) ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_SENDTOUSER) ;
		return ;
	}
	transfer->header.chunkTypeID = LOBBY_CHUNK_TRANSFER ;
	if (stream != STREAM_ACK)
		transfer->header.lastNeedToDeliverID = ++user->needToDeliverID ;
	else
		transfer->header.lastNeedToDeliverID = user->needToDeliverID ;
	transfer->length = length ;
	transfer->stream = stream ;
	dataStream = (unsigned char *)(((unsigned long)transfer) + ((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)) ;
	memcpy(dataStream,data,length) ;
	if (!(stream & 0x8000))
	{
		// add to buffer for resend if not acked
		LOBBY_AddDataToAck(user,(unsigned char *)transfer,((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)+length) ;
		if (currentLobby) currentLobby->updateCounter = 0 ;
		safe_free(transfer) ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_SENDTOUSER) ;
		return ;
	}
	Send802_3snapTo(PROTOCOL_ID_LOBBY,(unsigned char *)transfer,((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)+length,user->mac) ;
	safe_free(transfer) ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_SENDTOUSER) ;
}

/// Send a message to a room
/*!
		Will send to all members except for the sender, if the sender is member of the specified group\n
		Will send to the leading member of a group, if the sender is not member of the group\n
*/
void LOBBY_SendToRoom(LPLOBBY_ROOM room, unsigned short stream, unsigned char *data, int length)
{
	PROFILER_EnterState(PSTATE_SENDTOROOM) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_SENDTOROOM) ;
		return ;
	}
	if (!room->users) 
	{
		PROFILER_LeaveState(PSTATE_SENDTOROOM) ;
		return ;
	}
	// outside users can only send to room leader
	if (room != currentLobby->myself.room)
	{
		LOBBY_SendToUser(room->users[0],stream,data,length) ;
	} else
	{
		int i ;
		for (i=0;i<room->maxUsers;i++)
		{
			LOBBY_SendToUser(room->users[i],stream,data,length) ;
		}
	}
	PROFILER_LeaveState(PSTATE_SENDTOROOM) ;
}

void LOBBY_SendToAll(unsigned short stream, unsigned char *data, int length)
{
	LPLOBBY_USER tmp ;
	PROFILER_EnterState(PSTATE_SENDTOALL) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_SENDTOALL) ;
		return ;
	}
	tmp = currentLobby->users ;
	while (!tmp)
	{
		LOBBY_SendToUser(tmp,stream,data,length) ;
		tmp = tmp->next ;
	}
	PROFILER_LeaveState(PSTATE_SENDTOALL) ;
}

void LOBBY_Broadcast(unsigned short stream, unsigned char *data, int length)
{
	LPLOBBY_DATATRANSFER_CHUNK transfer  ;
	unsigned char *dataStream ;
	unsigned char anymac[6] = { 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF } ;
	PROFILER_EnterState(PSTATE_BROADCAST) ;
	transfer = (LPLOBBY_DATATRANSFER_CHUNK)safe_malloc(((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)+length) ;
	if (!(stream & 0x8000)) 
	{
		PROFILER_LeaveState(PSTATE_BROADCAST) ;
		return ; // we can't broadcast need to deliver streams. Use send to all instead
	}
	transfer->header.chunkTypeID = LOBBY_CHUNK_TRANSFER ;
	transfer->header.lastNeedToDeliverID = 0 ;
	transfer->length = length ;
	transfer->stream = stream ;
	dataStream = (unsigned char *)(((unsigned long)transfer) + ((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)) ;
	memcpy(dataStream,data,length) ;
	Send802_3snapTo(PROTOCOL_ID_LOBBY,(unsigned char *)transfer,((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)+length,&anymac[0]) ;
	PROFILER_LeaveState(PSTATE_BROADCAST) ;
}

/// Get the room lead by the specified MAC-Address
/*!
		Retrieve the room that is lead by the user with the specified MAC-Address
		\sa LOBBY_GetRoomByID, LOBBY_GetRoomByUser
		\param mac: pointer to a valid MAC Address (6 chars long)
		\return non zero if succeeded
*/
LPLOBBY_ROOM LOBBY_GetRoomByMAC(unsigned char *mac)
{
	LPLOBBY_ROOM tmp ;
	PROFILER_EnterState(PSTATE_GETROOMBYMAC) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
		return 0 ;
	}
	if (!currentLobby->rooms) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
		return 0 ;
	}
	if (memcmp(mac+1,currentLobby->myself.mac+1,5)==0) // don't compare the first byte (it's either 0 (universal) or 2 (locally administrated) anyways
	{
		// thats mine!
		PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
		return &currentLobby->room ;
	}
	tmp = currentLobby->rooms ;
	while (1)
	{
		if (tmp->users)
		{
			if (tmp->users[0])
			{
				if (memcmp(tmp->users[0]->mac,mac,6)==0)
				{
					PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
					return tmp ;
				}
			}
		}
		if (!tmp->next) 
		{
			PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
			return 0 ;
		}
		tmp = tmp->next ;
	}
	PROFILER_LeaveState(PSTATE_GETROOMBYMAC) ;
}


/// Get the user's room
/*!
		Retrieve the room by the given user.
		\sa LOBBY_GetRoomByID, LOBBY_GetRoomByMAC
		\param user: a valid user
		\return non zero if succeeded
*/
LPLOBBY_ROOM LOBBY_GetRoomByUser(LPLOBBY_USER user) 
{
	PROFILER_EnterState(PSTATE_GETROOMBYUSER) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYUSER) ;
		return NULL;
	}
	PROFILER_LeaveState(PSTATE_GETROOMBYUSER) ;
	return user->room ;
}

char* LOBBY_GetRoomName(LPLOBBY_ROOM room)
{
	PROFILER_EnterState(PSTATE_GETROOMNAME) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMNAME) ;
		return NULL;
	}
	PROFILER_LeaveState(PSTATE_GETROOMNAME) ;
	return room->name ;
}

unsigned short LOBBY_GetRoomGameCode(LPLOBBY_ROOM room)
{
	PROFILER_EnterState(PSTATE_GETROOMGAMECODE) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMGAMECODE) ;
		return -1;
	}
	PROFILER_LeaveState(PSTATE_GETROOMGAMECODE) ;
	return room->gameCode ;
}

unsigned short LOBBY_GetRoomGameVersion(LPLOBBY_ROOM room)
{
	PROFILER_EnterState(PSTATE_GETROOMGAMEVERSION) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMGAMEVERSION) ;
		return -1;
	}
	PROFILER_LeaveState(PSTATE_GETROOMGAMEVERSION) ;
	return room->gameVersion ;
}

LPLOBBY_USER LOBBY_GetRoomUserBySlot(LPLOBBY_ROOM room, unsigned char slot)
{
	PROFILER_EnterState(PSTATE_GETROOMUSERBYSLOT) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMUSERBYSLOT) ;
		return 0 ;
	}
	if (slot >= room->maxUsers) ;
	PROFILER_LeaveState(PSTATE_GETROOMUSERBYSLOT) ;
	return room->users[slot] ;
}

/* functions for managing users */
/// Get the n'th recognized user
/*!
		Retrieve the user by the chronological number it was recognized.\n
		The first recognized user got the id=0\n
		The own user can be retrieved using the constant USERID_MYSELF\n
		\sa LOBBY_GetUserByMAC
		\param id: number of recognizing
		\return non zero if succeeded
*/
LPLOBBY_USER LOBBY_GetUserByID(unsigned short id)
{
	int i = 0 ;
	LPLOBBY_USER tmp ;
	PROFILER_EnterState(PSTATE_GETUSERBYID) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYID) ;
		return 0 ;
	}
	if (id == USERID_MYSELF)
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYID) ;
		return &currentLobby->myself ;
	}
	if (!currentLobby->users) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYID) ;
		return 0 ;
	}
	tmp = currentLobby->users ;
	while (i!=id)
	{
		if (!tmp->next) 
		{
			PROFILER_LeaveState(PSTATE_GETUSERBYID) ;
			return 0 ;
		}
		tmp = tmp->next ;
		i++ ;
	}
	PROFILER_LeaveState(PSTATE_GETUSERBYID) ;
	return tmp ;
}

unsigned short LOBBY_GetUsercountInRoom(LPLOBBY_ROOM room) 
{
	PROFILER_EnterState(PSTATE_GETUSERCOUNTINROOM) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERCOUNTINROOM) ;
		return 0 ;
	}
	PROFILER_LeaveState(PSTATE_GETUSERCOUNTINROOM) ;
	return room->numOfUsers ;
}

unsigned short LOBBY_GetMaxUsercountInRoom(LPLOBBY_ROOM room) 
{
	PROFILER_EnterState(PSTATE_GETMAXUSERCOUNTINROOM) ;
	if (!room) 
	{
		PROFILER_LeaveState(PSTATE_GETMAXUSERCOUNTINROOM) ;
		return 0 ;
	}
	PROFILER_LeaveState(PSTATE_GETMAXUSERCOUNTINROOM) ;
	return room->maxUsers ;
}

/// Get the user using the specified MAC-Address
/*!
		Retrieve the user by the given MAC-Address.
		The own user can be retrieved this way\n
		\sa LOBBY_GetUserByID
		\param mac: pointer to a valid MAC Address (6 chars long)
		\return non zero if succeeded
*/
LPLOBBY_USER LOBBY_GetUserByMAC(unsigned char *mac)
{
	LPLOBBY_USER tmp ;
	PROFILER_EnterState(PSTATE_GETUSERBYMAC) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYMAC) ;
		return 0 ;
	}
	if (memcmp(mac,ownMAC,6)==0) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYMAC) ;
		return &currentLobby->myself ;
	}
	if (!currentLobby->users) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERBYMAC) ;
		return 0 ;
	}
	tmp = currentLobby->users ;
	while (memcmp(mac,tmp->mac,6))
	{
		if (!tmp->next) 
		{
			PROFILER_LeaveState(PSTATE_GETUSERBYMAC) ;
			return 0 ;
		}
		tmp = tmp->next ;
	}
	PROFILER_LeaveState(PSTATE_GETUSERBYMAC) ;
	return tmp ;
}

/// Get the number of users recognized
/*!
		\sa LOBBY_GetUserByID
*/
unsigned short LOBBY_GetNumberOfKnownUsers(void)
{
	int i = 0 ;
	LPLOBBY_USER tmp ;
	PROFILER_EnterState(PSTATE_GETNUMBEROFKNOWNUSERS) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNUSERS) ;
		return 0 ;
	}
	if (!currentLobby->users) 
	{
		PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNUSERS) ;
		return 0 ;
	}
	tmp = currentLobby->users ;
	while (tmp)
	{
		tmp = tmp->next ;
		i++ ;
	}
	PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNUSERS) ;
	return i ;
}

unsigned short LOBBY_GetNumberOfKnownRooms(void)
{
	int i = 0 ;
	LPLOBBY_ROOM tmp ;
	PROFILER_EnterState(PSTATE_GETNUMBEROFKNOWNROOMS) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNROOMS) ;
		return 0 ;
	}
	if (!currentLobby->rooms) 
	{
		PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNROOMS) ;
		return 0 ;
	}
	tmp = currentLobby->rooms ;
	while (tmp)
	{
		tmp = tmp->next ;
		i++ ;
	}
	PROFILER_LeaveState(PSTATE_GETNUMBEROFKNOWNROOMS) ;
	return i ;
}

LPLOBBY_ROOM LOBBY_GetRoomByGame(LPLOBBY_ROOM anchor, unsigned short gameCode)
{
	PROFILER_EnterState(PSTATE_GETROOMBYGAME) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_GETROOMBYGAME) ;
		return 0 ;
	}
	do
	{
		if (anchor==0) 
		{
			anchor = currentLobby->rooms ;
		} else
		{
			anchor = anchor->next ;
		}
		if (anchor)
		{
			if (anchor->gameCode==gameCode) 
			{
				PROFILER_LeaveState(PSTATE_GETROOMBYGAME) ;
				return anchor ;
			}
		}
	} while (anchor) ;
	PROFILER_LeaveState(PSTATE_GETROOMBYGAME) ;
	return 0 ;
}

/// Update all needed info for the LOBBY to run
/*!
		- checks for user/room timeouts \n
		- requests resending of unacknowledged data \n
		- broadcasts user info\n
		\n
		Need to be called regulary. Best to be put in VBLANK handler
*/
void LOBBY_Update(void)
{
	LPLOBBY_USER tmp ;
	PROFILER_EnterState(PSTATE_UPDATE) ;
	if (!currentLobby) {
		PROFILER_LeaveState(PSTATE_UPDATE) ;
		return ;
	}
	if (!currentLobby->updateTimeout--)
	{
		LOBBY_BroadcastID() ;
		currentLobby->updateTimeout = BROADCAST_INTERVAL ;
	}
	tmp = currentLobby->users ;
	while (tmp)
	{
		if ((currentLobby->updateCounter % 6)==0) // every 100msecs ... 
		{
			if (tmp->timeout)				 // only send to stations that are not timed out
				LOBBY_ResendUnacked(tmp) ;
		}
		if (tmp->timeout == 1)
		{
			//LOBBY_ClearAcks(tmp) ;
			//LOBBY_ClearReceives(tmp) ;
			if (currentLobby->userInfoCallback)
				currentLobby->userInfoCallback(tmp,USERINFO_REASON_TIMEOUT) ;
		}
		if (tmp->timeout > 0) tmp->timeout-- ;
		tmp = tmp->next ;
	}
	currentLobby->updateCounter++ ;
	PROFILER_LeaveState(PSTATE_UPDATE) ;
}

/// Check if the user has not responded within the timeout-timeframe
/*!
		\param user: valid, recognized user
		\return 1 if timed out user, 0 otherwise
*/

int LOBBY_IsTimedOut(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_ISTIMEDOUT) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_ISTIMEDOUT) ;
		return 1 ; // the non-user is allways timed out
	}
	PROFILER_LeaveState(PSTATE_ISTIMEDOUT) ;
	return (!user->timeout) ;
}

/// Get the user's name
/*!
		\param user: valid, recognized user
		\return a pointer to the user name, which is maximum 32 chars long (inclusive \\0)
*/
const char *LOBBY_GetUserName(LPLOBBY_USER user) 
{
	PROFILER_EnterState(PSTATE_GETUSERNAME) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_GETUSERNAME) ;
		return 0 ;
	}
	PROFILER_LeaveState(PSTATE_GETUSERNAME) ;
	return (const char *)user->name ;
}

/// Internal use
/*!
		Check if the user is already known\n
		Check if the user's room changed\n
		Check if the user is back from a timeout\n
		\param mac: MAC-Address (6 chars) which identifies the user
		\param name: name of the user. Initially the name stored in the personal data in the DS's flash
		\param room: the room the user claims to be within. The actual membership is retrieved on roominfo updates
*/
void LOBBY_UpdateUser(unsigned char *mac, char *name, LPLOBBY_ROOM room)
{
	LPLOBBY_USER tmp ;
	int lock ;
	PROFILER_EnterState(PSTATE_UPDATEUSER) ;
	lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_UPDATEUSER) ;
		return ;
	}
	if (!currentLobby->users)
	{
		// there is no known user, so this is the first to enter
		currentLobby->users = (LPLOBBY_USER)safe_malloc(sizeof(LOBBY_USER)) ;
		currentLobby->users->ackCache = (unsigned short *)safe_malloc(64*sizeof(unsigned short)) ;
		currentLobby->users->ackCache[0] = 0 ;
		memcpy(currentLobby->users->mac, mac,6) ;
		memcpy(currentLobby->users->name, name, 32) ;
		LOBBY_UserResetTimeout(currentLobby->users) ;
		currentLobby->users->next = 0 ;
		currentLobby->users->acks = 0 ;
		currentLobby->users->needToDeliverID = 0 ;
		currentLobby->users->needToDeliverACK = 0 ;
		currentLobby->users->remoteDeliverID = 0 ;
		currentLobby->users->nextInOrderID = 1 ;
		currentLobby->users->OOOCache = 0 ;
		currentLobby->users->room = room ;
		currentLobby->users->synchState = 0 ;
		memset(&currentLobby->users->multiReceiveFilterData[0],0xFF,sizeof(currentLobby->users->multiReceiveFilterData)) ;
		currentLobby->users->multiReceiveFilterHead = 0 ;
		currentLobby->users->multiReceiveFilterNum = 0 ;
		// handshake, the stream ID is containing the data, so an dummy byte will be sent
		LOBBY_SendToUser(currentLobby->users,STREAM_HANDSHAKE,(unsigned char *)"",1) ;
		if (currentLobby->userInfoCallback)
			currentLobby->userInfoCallback(currentLobby->users,USERINFO_REASON_REGOGNIZE) ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_UPDATEUSER) ;
		return ;
	}
	tmp = currentLobby->users ;
	while (memcmp(mac,tmp->mac,6))
	{
		if (!tmp->next)
		{
			tmp->next = (LPLOBBY_USER)safe_malloc(sizeof(LOBBY_USER)) ;
			tmp->next->ackCache = (unsigned short *)safe_malloc(64*sizeof(unsigned short)) ;
			tmp->next->ackCache[0] = 0 ;			
			memcpy(tmp->next->mac, mac,6) ;
			memcpy(tmp->next->name, name, 32) ;
			LOBBY_UserResetTimeout(tmp->next) ;
			tmp->next->next = 0 ;
			tmp->next->acks = 0 ;
			tmp->next->needToDeliverID = 0 ;
			tmp->next->needToDeliverACK = 0 ;
			tmp->next->remoteDeliverID = 0 ;
			tmp->next->nextInOrderID = 1 ;
			tmp->next->OOOCache = 0 ;
			tmp->next->room = room ;
			memset(&tmp->next->multiReceiveFilterData[0],0xFF,sizeof(tmp->next->multiReceiveFilterData)) ;
			tmp->next->multiReceiveFilterHead = 0 ;
			tmp->next->multiReceiveFilterNum = 0 ;
			tmp->next->synchState = 0 ;
			// handshake, the stream ID is containing the data, so an dummy byte will be sent
			LOBBY_SendToUser(tmp->next,STREAM_HANDSHAKE,(unsigned char *)"",1) ;
			if (currentLobby->userInfoCallback)
				currentLobby->userInfoCallback(tmp->next,USERINFO_REASON_REGOGNIZE) ;
			LOBBY_LockSystem(lock) ;
			PROFILER_LeaveState(PSTATE_UPDATEUSER) ;
			return ;
		}
		tmp = tmp->next ;
	}
	if (!tmp->timeout)
	{
		// ToDo: Instead of resetting all connections on timeout
		//		 we'll request info on the lowest non-acked packet
		//		 This way we should be able to resume from timeouts or reset when needed
		tmp->acks = 0 ;
		tmp->needToDeliverID = 0 ;
		tmp->needToDeliverACK = 0 ;
		tmp->remoteDeliverID = 0 ;
		tmp->nextInOrderID = 1 ;
		tmp->OOOCache = 0 ;
		memset(&tmp->multiReceiveFilterData[0],0xFF,sizeof(tmp->multiReceiveFilterData)) ;
		tmp->multiReceiveFilterHead = 0 ;
		tmp->multiReceiveFilterNum = 0 ;
		if (currentLobby->userInfoCallback)
			currentLobby->userInfoCallback(tmp,USERINFO_REASON_RETURN) ;
	}
	if (tmp->room != room)
	{
		if (currentLobby->userInfoCallback)
			currentLobby->userInfoCallback(tmp,USERINFO_REASON_ROOMCHANGE) ;
	}
	tmp->room = room ;
	memcpy(tmp->mac, mac,6) ;
	memcpy(tmp->name, name, 32) ;
	LOBBY_UserResetTimeout(tmp) ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_UPDATEUSER) ;
}

void LOBBY_UserResetTimeout(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_USERRESETTIMEOUT) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_USERRESETTIMEOUT) ;
		return ;
	}
	user->timeout = 240 ;
	PROFILER_LeaveState(PSTATE_USERRESETTIMEOUT) ;
}
/// Register a callback for user information updates
/*!
		When a user changes his properties, the specified callback will be called\n
		to let the application know
		\param user: valid, recognized user
		\return a pointer to the user name, which is maximum 32 chars long (inclusive \\0)
*/
void LOBBY_SetUserInfoCallback(LOBBY_USERINFOHANDLER_PROC callback)
{
	PROFILER_EnterState(PSTATE_SETUSERINFOCALLBACK) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_SETUSERINFOCALLBACK) ;
		return ;
	}
	currentLobby->userInfoCallback = callback ;
	PROFILER_LeaveState(PSTATE_SETUSERINFOCALLBACK) ;
}

int LOBBY_UserIsAllSent(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_USERISALLSENT) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_USERISALLSENT) ;
		return 1 ;			// for the NULL user: all data was always transfered
	}
	if (!user->acks) 
	{
		PROFILER_LeaveState(PSTATE_USERISALLSENT) ;
		return 1 ;		// for the usual: if there is nothing left in the ack buffer, all is done
	}
	PROFILER_LeaveState(PSTATE_USERISALLSENT) ;
	return 0 ;
}

int	LOBBY_UserIsStreamSent(LPLOBBY_USER user,unsigned short streamID)
{
	LPLOBBY_ACKDATA tmp ;
	PROFILER_EnterState(PSTATE_USERISSTREAMSENT) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_USERISSTREAMSENT) ;
		return 1 ;
	}
	tmp = user->acks ;
	while (!tmp)
	{
		if (tmp->ID == streamID)
		{
			PROFILER_LeaveState(PSTATE_USERISSTREAMSENT) ;
			return 0 ;
		}
		tmp = tmp->next ;
	}
	PROFILER_LeaveState(PSTATE_USERISSTREAMSENT) ;
	return 1 ;
}

int LOBBY_AlreadyReceived(LPLOBBY_USER user,unsigned short num)
{
	int i,q ;
	PROFILER_EnterState(PSTATE_ALREADYRECEIVED) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_ALREADYRECEIVED) ;
		return 1 ;
	}
	i = (user->multiReceiveFilterHead + 1 + RECEIVEFILTER_SIZE - user->multiReceiveFilterNum) & (RECEIVEFILTER_SIZE-1);
	for (q=0;q<user->multiReceiveFilterNum;q++)
	{
		if (user->multiReceiveFilterData[i] == num)
		{
			PROFILER_LeaveState(PSTATE_ALREADYRECEIVED) ;
			return 1 ;
		}
		i= (i+1) & (RECEIVEFILTER_SIZE - 1) ;
	}
	PROFILER_LeaveState(PSTATE_ALREADYRECEIVED) ;
	return 0 ;
}

void LOBBY_RememberReceived(LPLOBBY_USER user,unsigned short num)
{
	PROFILER_EnterState(PSTATE_REMEMBERRECEIVED) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_REMEMBERRECEIVED) ;
		return ;
	}
	user->multiReceiveFilterHead = (user->multiReceiveFilterHead+1) & (RECEIVEFILTER_SIZE - 1);
	user->multiReceiveFilterData[user->multiReceiveFilterHead] = num ;
	if (user->multiReceiveFilterNum < RECEIVEFILTER_SIZE) user->multiReceiveFilterNum++ ;
	PROFILER_LeaveState(PSTATE_REMEMBERRECEIVED) ;
}

void LOBBY_OOOEnqueReceived(LPLOBBY_USER user,unsigned short ID,unsigned short streamID,unsigned char *data, int length)
{
	LPLOBBY_OOOCACHE tmpCache ;
	int lock ;
	PROFILER_EnterState(PSTATE_OOOENQUERECEIVED) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_OOOENQUERECEIVED) ;
		return ;
	}
	lock = LOBBY_LockSystem(0) ;
	// handshake has an instant effect
	if (streamID == STREAM_HANDSHAKE)
	{
//		LOBBY_ClearAcks(user) ;
//		LOBBY_ClearReceives(user) ;
		currentLobby->users->multiReceiveFilterHead = 0 ;
		currentLobby->users->multiReceiveFilterNum = 0 ;
		user->nextInOrderID = 2 ;
		user->needToDeliverID = 1 ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_OOOENQUERECEIVED) ;
		return ;
	}
	if ( ID == user->nextInOrderID)
	{
		// this is a packet we can pass directly, as it is in order
		LPLOBBY_STREAMHANDLER tmp = currentLobby->streams ;
		while (tmp)
		{
			if (tmp->streamID == streamID)
			{
				tmp->callback(data,length,user) ;
			}
			tmp = tmp->next ;
		}
		user->nextInOrderID++ ;
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_OOOENQUERECEIVED) ;
		return ;
	} else
	{
		LPLOBBY_OOOCACHE tmpCache = user->OOOCache ;
		if (!user->OOOCache)
		{
			// first entry
			LPLOBBY_OOOCACHE nc = (LPLOBBY_OOOCACHE)safe_malloc(sizeof(LOBBY_OOOCACHE)) ;
			nc->data = (unsigned char *)safe_malloc(length) ;
			nc->length = length ;
			nc->ID = ID ;
			nc->streamID = streamID ;
			memcpy(nc->data,data,length) ;
			nc->last = 0 ;
			nc->next = 0 ;
			user->OOOCache = nc ;
		}
		while (tmpCache)
		{
			if (tmpCache->ID > ID)
			{
				// insert just before this cache entry
				LPLOBBY_OOOCACHE nc = (LPLOBBY_OOOCACHE)safe_malloc(sizeof(LOBBY_OOOCACHE)) ;
				nc->data = (unsigned char *)safe_malloc(length) ;
				nc->length = length ;
				nc->ID = ID ;
				nc->streamID = streamID ;
				memcpy(nc->data,data,length) ;
				nc->last = tmpCache->last ;
				nc->next = tmpCache ;
				if (nc->last)
				{
					nc->last->next = nc ;
				} else
				{
					user->OOOCache = nc ;
				}
				if (nc->next)
				{
					nc->next->last = nc ;
				}
				tmpCache = 0 ; // exit while
			} else if (tmpCache->next == 0)
			{
				// we need to append at the end of list
				LPLOBBY_OOOCACHE nc = (LPLOBBY_OOOCACHE)safe_malloc(sizeof(LOBBY_OOOCACHE)) ;
				nc->data = (unsigned char *)safe_malloc(length) ;
				nc->length = length ;
				nc->ID = ID ;
				nc->streamID = streamID ;
				memcpy(nc->data,data,length) ;
				nc->last = tmpCache ;
				nc->next = 0 ;
				if (nc->last)
				{
					nc->last->next = nc ;
				} else
				{
					user->OOOCache = nc ;
				}
				tmpCache = 0 ;
			} else
				tmpCache = tmpCache->next ;
		}
	}
	tmpCache = user->OOOCache ;
	while ((tmpCache) && (tmpCache->ID == user->nextInOrderID))
	{
		// this packet is the next to be passed to the stream callback
		LPLOBBY_STREAMHANDLER tmp = currentLobby->streams ;
		while (tmp)
		{
			if (tmp->streamID == tmpCache->streamID)
			{
				tmp->callback(tmpCache->data,tmpCache->length,user) ;
			}
			tmp = tmp->next ;
		}
		user->nextInOrderID++ ;
		// remove entry from list
		// we know that it is allways the first entry in that list:
		user->OOOCache = user->OOOCache->next ;
		if (tmpCache->next) tmpCache->next->last = 0 ;
		safe_free (tmpCache->data) ;
		safe_free (tmpCache) ;
		tmpCache = user->OOOCache ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_OOOENQUERECEIVED) ;
}

void LOBBY_AddToAckCache(LPLOBBY_USER user, unsigned short ackID)
{
	int lock ;
	PROFILER_EnterState(PSTATE_ADDTOACKCACHE) ;
	lock = LOBBY_LockSystem(0) ;
	if (!user) {
		LOBBY_LockSystem(lock) ;
		PROFILER_LeaveState(PSTATE_ADDTOACKCACHE) ;
		return ;
	}
	user->ackCache[0]++ ;
	user->ackCache[user->ackCache[0]] = ackID ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_ADDTOACKCACHE) ;
}

void LOBBY_ClearAckCache(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_CLEARACKCACHE) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_CLEARACKCACHE) ;
		return ;
	}
	if (!user->ackCache) 
	{
		PROFILER_LeaveState(PSTATE_CLEARACKCACHE) ;
		return ;
	}
	user->ackCache[0] = 0 ;
	PROFILER_LeaveState(PSTATE_CLEARACKCACHE) ;
}

void LOBBY_FlushAckCache(LPLOBBY_USER user)
{
	PROFILER_EnterState(PSTATE_FLUSHACKCACHE) ;
	if (!user) 
	{
		PROFILER_LeaveState(PSTATE_FLUSHACKCACHE) ;
		return ;
	}
	if (user->ackCache[0])
		LOBBY_SendToUser(user,STREAM_ACK,(unsigned char *)user->ackCache,user->ackCache[0]*2 + 2) ;
	LOBBY_ClearAckCache(user) ;
	PROFILER_LeaveState(PSTATE_FLUSHACKCACHE) ;
}

int LOBBY_RecvChunk(unsigned char *data, int length, unsigned char *from)
{
//	unsigned char *ack ;
	LPLOBBY_DATATRANSFER_CHUNK transfer = (LPLOBBY_DATATRANSFER_CHUNK)data ;
	LPLOBBY_USER user ;
	LPLOBBY_STREAMHANDLER tmp = currentLobby->streams ;
	unsigned char *dataStream ;
	PROFILER_EnterState(PSTATE_RECVCHUNK) ;
	dataStream = (unsigned char *)(((unsigned long)transfer) + ((sizeof(LOBBY_DATATRANSFER_CHUNK)+3) & ~3)) ;
	// if a chunk is not of transfer type we can't handle it here.
	// also assume that it is of a size bigger of all we know (as we don't know which it is)
	if (transfer->header.chunkTypeID != LOBBY_CHUNK_TRANSFER) return 9999 ;
	user = LOBBY_GetUserByMAC(from) ;
	LOBBY_UserResetTimeout(user) ;
	while (tmp)
	{
		if (tmp->streamID == transfer->stream)
		{
			if (!user)
			{
				// don't accept from unknown users (wait for info broadcast first)
				tmp->callback(dataStream,transfer->length,user) ;
			} else
			{
				if (transfer->stream & 0x8000)
				{
					// stream is not acked, we don't need to check for clones
					tmp->callback(dataStream,transfer->length,user) ;
				} else
				{
					// stream is acked, thus probably a send retry clone
					if (!LOBBY_AlreadyReceived(user, transfer->header.lastNeedToDeliverID))
					{
						LOBBY_OOOEnqueReceived(user,transfer->header.lastNeedToDeliverID,transfer->stream,dataStream,transfer->length) ;
					} 
				}
			}
			tmp = 0 ;
		} else
			tmp = tmp->next ;
	}
	if (user)
	{
		user->remoteDeliverID = transfer->header.lastNeedToDeliverID ;

		// only ack the streams from 0-0x7FFF, don't ack the others (including the ack stream)
		if (!(transfer->stream & 0x8000))
		{
			if (!LOBBY_AlreadyReceived(user, transfer->header.lastNeedToDeliverID))
				LOBBY_RememberReceived(user,transfer->header.lastNeedToDeliverID) ;
			LOBBY_AddToAckCache(user,transfer->header.lastNeedToDeliverID) ;
		} 
	}
	PROFILER_LeaveState(PSTATE_RECVCHUNK) ;
	return ((transfer->length + 3) & ~3) + ((sizeof(LOBBY_DATATRANSFER_CHUNK) + 3) & ~3) ;
}

/// Internal use
/*!
		Get's called with received 802.11snap protocol 0x08FE content
*/
void LOBBY_RecvCallback(unsigned char *data, int length, unsigned char *from) 
{
	int lock ;
	PROFILER_EnterState(PSTATE_RECVCALLBACK) ;
	lock = LOBBY_LockSystem(0) ;
	if (!currentLobby) 
	{
		PROFILER_LeaveState(PSTATE_RECVCALLBACK) ;
		return ;
	}
	switch (currentLobby->state)
	{
		case LOBBY_STATE_ACTIVE:
			{
				LPLOBBY_CHUNKHEADER header = (LPLOBBY_CHUNKHEADER)data ;
				switch (header->chunkTypeID)
				{
					case LOBBY_CHUNK_REQID:
						// requesting own ID, return it!
						LOBBY_BroadcastID() ;
						break ;
					case LOBBY_CHUNK_SHOWID:
						{
							LPLOBBY_SHOWID_CHUNK showid = (LPLOBBY_SHOWID_CHUNK)data ;
							LPLOBBY_ROOM room = LOBBY_GetRoomByMAC(showid->roomLeader) ;
							LPLOBBY_USER user = LOBBY_GetUserByMAC(showid->roomLeader) ;
							if ((!room) && (user) && ((showid->roomLeader[0] & BIT(1))==0)) // only request for visible rooms
							{
								// room isn't known, but it's leader is
								// request room info
								LPLOBBY_ROOMINFO_CHUNK ri = (LPLOBBY_ROOMINFO_CHUNK)safe_malloc(sizeof(LOBBY_ROOMINFO_CHUNK)) ;
								memset(ri,0,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
								LOBBY_SendToUser(user,STREAM_ROOM,(unsigned char *)ri,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
								safe_free(ri) ;
							}
							if (room)
							{
								if (showid->roomCRC != room->roomOwnerCreatedCRC)
								{
									// request update on room
									LPLOBBY_ROOMINFO_CHUNK ri = (LPLOBBY_ROOMINFO_CHUNK)safe_malloc(sizeof(LOBBY_ROOMINFO_CHUNK)) ;
									memset(ri,0,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
									LOBBY_SendToUser(user,STREAM_ROOM,(unsigned char *)ri,sizeof(LOBBY_ROOMINFO_CHUNK)) ;
									safe_free(ri) ;
								}
							}
							LOBBY_UpdateUser(&showid->answerMAC[0],(char *)&showid->answerName[0], room) ;
						}
						break ;
					case LOBBY_CHUNK_TRANSFER:
						{
							int pos = 0 ;
							if (!LOBBY_GetUserByMAC(from))
							{
								// the user is not known yet in detail, create a user with temp values
								LOBBY_UpdateUser(from,"",0) ;
							}
							LOBBY_ClearAckCache(LOBBY_GetUserByMAC(from)) ;
							while (pos < length)
							{
								int parsed = LOBBY_RecvChunk(data+pos,length-pos,from) ;
								pos = pos + parsed ;
							}
							LOBBY_FlushAckCache(LOBBY_GetUserByMAC(from)) ;
						}
						break ;
					default:
						break ;
				}
			}
			break ;
	}
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_RECVCALLBACK) ;
}

/// Initiate the lobby
/*!
		Will only succeed if the lobby is not initialized\n
		Put's the DS listening for the lobby on channel 7\n
*/
int LOBBY_Init(void) 
{
	// we don't start/join a lobby, when we are allready in one
	int lock ;
	if (currentLobby) return 0 ;
	lock = LOBBY_LockSystem(0) ;
	currentLobby = (LPLOBBY_DATASTRUCT)safe_malloc(sizeof(LOBBY_DATASTRUCT)) ;
	if (!currentLobby) 
	{
		LOBBY_LockSystem(lock) ;
		return 0 ;
	}

	PROFILER_Init("lobby_c.prf") ;
	PROFILER_EnterState(PSTATE_INIT) ;

	PROFILER_GenerateState("LOBBY_AckStreamHandler",PSTATE_ACKSTREAMHANDLER) ;
	PROFILER_GenerateState("LOBBY_AddDataToAck",PSTATE_ADDDATATOACK) ;
	PROFILER_GenerateState("LOBBY_AddToAckCache",PSTATE_ADDTOACKCACHE) ;
	PROFILER_GenerateState("LOBBY_AlreadyReceived",PSTATE_ALREADYRECEIVED) ;
	PROFILER_GenerateState("LOBBY_Broadcast",PSTATE_BROADCAST) ;
	PROFILER_GenerateState("LOBBY_BroadcastID",PSTATE_BROADCASTID) ;
	PROFILER_GenerateState("LOBBY_ClearAckCache",PSTATE_CLEARACKCACHE) ;
	PROFILER_GenerateState("LOBBY_ClearAcks",PSTATE_CLEARACKS) ;
	PROFILER_GenerateState("LOBBY_ClearReceives",PSTATE_CLEARRECEIVES) ;
	PROFILER_GenerateState("LOBBY_CreateRoom",PSTATE_CREATEROOM) ;
	PROFILER_GenerateState("LOBBY_FlushAckCache",PSTATE_FLUSHACKCACHE) ;
	PROFILER_GenerateState("LOBBY_FlushCollector",PSTATE_FLUSHCOLLECTOR) ;
	PROFILER_GenerateState("LOBBY_GetMaxUsercountInRoom",PSTATE_GETMAXUSERCOUNTINROOM) ;
	PROFILER_GenerateState("LOBBY_GetNumberOfKnownRooms",PSTATE_GETNUMBEROFKNOWNROOMS) ;
	PROFILER_GenerateState("LOBBY_GetNumberOfKnownUsers",PSTATE_GETNUMBEROFKNOWNUSERS) ;
	PROFILER_GenerateState("LOBBY_GetRoomByGame",PSTATE_GETROOMBYGAME) ;
	PROFILER_GenerateState("LOBBY_GetRoomByID",PSTATE_GETROOMBYID) ;
	PROFILER_GenerateState("LOBBY_GetRoomByMAC",PSTATE_GETROOMBYMAC) ;
	PROFILER_GenerateState("LOBBY_GetRoomByUser",PSTATE_GETROOMBYUSER) ;
	PROFILER_GenerateState("LOBBY_GetRoomGameCode",PSTATE_GETROOMGAMECODE) ;
	PROFILER_GenerateState("LOBBY_GetRoomGameVersion",PSTATE_GETROOMGAMEVERSION) ;
	PROFILER_GenerateState("LOBBY_GetUserByID",PSTATE_GETUSERBYID) ;
	PROFILER_GenerateState("LOBBY_GetUserByMAC",PSTATE_GETUSERBYMAC) ;
	PROFILER_GenerateState("LOBBY_GetUsercountInRoom",PSTATE_GETUSERCOUNTINROOM) ;
	PROFILER_GenerateState("LOBBY_GetUsername",PSTATE_GETUSERNAME) ;
	PROFILER_GenerateState("LOBBY_HandleAck",PSTATE_HANDLEACK) ;
	PROFILER_GenerateState("LOBBY_Init",PSTATE_INIT) ;
	PROFILER_GenerateState("LOBBY_IsTimedout",PSTATE_ISTIMEDOUT) ;
	PROFILER_GenerateState("LOBBY_JoinRoom",PSTATE_JOINROOM) ;
	PROFILER_GenerateState("LOBBY_LeaveRoom",PSTATE_LEAVEROOM) ;
	PROFILER_GenerateState("LOBBY_OOOEnqueReceived",PSTATE_OOOENQUERECEIVED) ;
	PROFILER_GenerateState("LOBBY_PrepareCollector",PSTATE_PREPARECOLLECTOR) ;
	PROFILER_GenerateState("LOBBY_RecvCallback",PSTATE_RECVCALLBACK) ;
	PROFILER_GenerateState("LOBBY_RecvChunk",PSTATE_RECVCHUNK) ;
	PROFILER_GenerateState("LOBBY_RememberReceived",PSTATE_REMEMBERRECEIVED) ;
	PROFILER_GenerateState("LOBBY_ResendUnacked",PSTATE_RESENDUNACKED) ;
	PROFILER_GenerateState("LOBBY_RoomStreamCallback",PSTATE_ROOMSTREAMCALLBACK) ;
	PROFILER_GenerateState("LOBBY_SendToAll",PSTATE_SENDTOALL) ;
	PROFILER_GenerateState("LOBBY_SendToRoom",PSTATE_SENDTOROOM) ;
	PROFILER_GenerateState("LOBBY_SendToUser",PSTATE_SENDTOUSER) ;
	PROFILER_GenerateState("LOBBY_SendViaCollector",PSTATE_SENDVIACOLLECTOR) ;
	PROFILER_GenerateState("LOBBY_SetStreamHandler",PSTATE_SETSTREAMHANDLER) ;
	PROFILER_GenerateState("LOBBY_SetUserInfoCallback",PSTATE_SETUSERINFOCALLBACK) ;
	PROFILER_GenerateState("LOBBY_Shutdown",PSTATE_SHUTDOWN) ;
	PROFILER_GenerateState("LOBBY_Update",PSTATE_UPDATE) ;
	PROFILER_GenerateState("LOBBY_UpdateRoom",PSTATE_UPDATEROOM) ;
	PROFILER_GenerateState("LOBBY_UpdateUser",PSTATE_UPDATEUSER) ;
	PROFILER_GenerateState("LOBBY_UserIsAllSent",PSTATE_USERISALLSENT) ;
	PROFILER_GenerateState("LOBBY_UserIsStreamSent",PSTATE_USERISSTREAMSENT) ;
	PROFILER_GenerateState("LOBBY_UserResetTimeout",PSTATE_USERRESETTIMEOUT) ;
	PROFILER_GenerateState("LOBBY_GetRoomUserBySlot",PSTATE_GETROOMUSERBYSLOT) ;
	PROFILER_GenerateState("LOBBY_SetRoomVisibility",PSTATE_SETROOMVISIBILITY) ;
	PROFILER_GenerateState("LOBBY_GetRoomName",PSTATE_GETROOMNAME) ;
	PROFILER_GenerateState("LOBBY_SendRoomInfo",PSTATE_SENDROOMINFO) ;

	// listen in lobby
	currentLobby->state = LOBBY_STATE_SCANNING ;
	Set802_3snapProtocolReceiver(PROTOCOL_ID_LOBBY,(RECEIVEPROTOCOL_PROC)&LOBBY_RecvCallback) ;

	// hardcode channel for now
	currentLobby->channel = 11 ;
	currentLobby->updateTimeout = BROADCAST_INTERVAL ;
	currentLobby->users = 0 ;
	currentLobby->streams = 0 ;
	currentLobby->userInfoCallback = 0 ;
	currentLobby->msgCollectorData = 0 ;
	#ifdef WIN32
		sprintf(&currentLobby->myself.name[0],"RALINK %08X",GetCurrentProcessId()) ;
	#else
	{	
		int i ;
		for (i=0;i<10;i++)
		{
			currentLobby->myself.name[i] = PersonalData->name[i] ;
		}
		for (;i<32;i++)
			currentLobby->myself.name[i] = 0 ;
	}
	#endif
	memcpy(&currentLobby->myself.mac[0],ownMAC,6) ;
	currentLobby->myself.room = 0 ;
	SetChannel(currentLobby->channel) ;
	currentLobby->rooms = 0 ;
	currentLobby->room.users = 0 ;
	currentLobby->room.maxUsers = 0 ;
	currentLobby->room.numOfUsers = 0 ;
	currentLobby->room.next = 0 ;
	LOBBY_SetStreamHandler(STREAM_ACK,&LOBBY_AckStreamHandler) ;
	LOBBY_SetStreamHandler(STREAM_ROOM,&LOBBY_RoomStreamCallback) ;
	LOBBY_SetStreamHandler(STREAM_HANDSHAKE,&LOBBY_HandshakeStreamCallback) ;
	currentLobby->state = LOBBY_STATE_ACTIVE ;
	LOBBY_LockSystem(lock) ;
	PROFILER_LeaveState(PSTATE_INIT) ;
	return 1 ;
}

void LOBBY_Shutdown() 
{
	PROFILER_EnterState(PSTATE_SHUTDOWN) ;
	safe_free(currentLobby) ;
	currentLobby = 0 ;
	PROFILER_LeaveState(PSTATE_SHUTDOWN) ;
	PROFILER_Shutdown() ;
}


