#include "802.3snap.h"
#include "802.11.h"
#include <string.h>
#ifdef WIN32
	#define safe_malloc	malloc
	#define safe_free free 
#else
	#include "safe_malloc.h"
#endif

#ifdef ARM9
	#include "MessageQueue.h"
	#include <fat.h>
#else
	typedef int bool ;
	#define false 0 ;

	extern void SendPaket(unsigned char *data,int length) ;
#endif
#include <stdio.h>

char ownMAC[6] = { 0,0,0,0,0,0 } ;
char macString[13] = "000000000000" ;

typedef struct MULTICAST_CALLBACKS
{
	MULTICAST_CALLBACK			callback ;
	unsigned char				address[6] ;
	struct MULTICAST_CALLBACKS *next ;
} MULTICAST_CALLBACKS, *LPMULTICAST_CALLBACKS ;

LPMULTICAST_CALLBACKS multicast_callbacks = 0 ;

void SetMulticastCallback(unsigned char *address, MULTICAST_CALLBACK cb)
{
	LPMULTICAST_CALLBACKS tmp = multicast_callbacks ;
	while (tmp)
	{
		if (memcmp(address,tmp->address,6)==0)
		{
			tmp->callback = cb ;
			return ;
		}
		tmp = tmp->next ;
	}
	LPMULTICAST_CALLBACKS n = (LPMULTICAST_CALLBACKS)safe_malloc(sizeof(MULTICAST_CALLBACKS)) ;
	n->callback = cb ;
	if (address)
		memcpy(n->address,address,6) ;
	else
		memset(n->address,0,6) ;
	n->next = multicast_callbacks ;
	multicast_callbacks = n ;
}

void UpdateMAC(unsigned char *mac) 
{
	memcpy(ownMAC,mac,6) ;
	sprintf(macString,"%02X%02X%02X%02X%02X%02X",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]) ;
}

char *GetMACString(void)
{
	return macString ;
}

typedef struct IPHEADER
{
	unsigned long 		version:4 ;
	unsigned long 		IHL:4 ;
	unsigned long		TOS:8 ;
	unsigned long		length:16 ;
	unsigned long		id:16 ;
	unsigned long		flags:3 ;
	unsigned long		fragmentOffset:13 ;
	unsigned long		TTL:8 ;
	unsigned long		protocol:8 ;
	unsigned long		crc:16 ;
	unsigned long		source ;
	unsigned long		destination ;
} IPHEADER, *LPIPHEADER ;

void Handle802_11(unsigned char *data, int length)
{
	LPFRAMECONTROL fc = (LPFRAMECONTROL)data ;
	switch (fc->type)
	{
		case 0:		// management
			switch (fc->subType)
			{
				case 0x00:
					// assoc request
					break ;
				case 0x01:
					// assoc response
					break ;
				case 0x02:
					// reassoc request
					break ;
				case 0x03:
					// reassoc response
					break ;
				case 0x04:
					// probe request ... we can ignore them if we are not an AP
					break ;
				case 0x05:
					// probe response
					break ;
				case 0x06:
				case 0x07:
					// reserved
					break ;
				case 0x08:
					return ;
				case 0x0A:
					// disassoc
					break ;
				case 0x0B:
					// auth
					break ;
				case 0x0C:
					// deauth
					break ;
			}
			break ;
		case 1:		// control
			switch (fc->subType)
			{
				case 0x0D:
					// ACK
					RegisterACK() ;
					break ;
			}
			break ;
		case 2:		// data
			{
				// skip WEP enabled frames
				if (fc->wep) return ;
				if ((data[4] == 0xFF) || (data[4]==0x00))
				{
					// broadcast, or directly addressed
					Handle802_3snap(data+24,length-24,data+10) ;
				} else
				{
					// multicast addresses
					LPMULTICAST_CALLBACKS tmp ;
					while (tmp)
					{
						if (memcmp(tmp->address,data+4,6)==0)
						{
							if (tmp->callback)
								tmp->callback(data+24,length-24,data+10) ;
						}
						tmp = tmp->next ;
					}
				}
				break ;
			}
			break ;
		case 3:		// reserved
			break ;
	}
}

void Send802_11(unsigned char *data, int length)
{
	unsigned char *tmp = (unsigned char *)safe_malloc(length+4) ;
#ifdef ARM9
	*(unsigned long *)tmp = IPCTAG_DATA ;
	memcpy(tmp+4,data,length) ;
//	if (!IPC_AllreadySending(tmp,length+4))		// only send if we don't have it in the send queue
		IPC_SendMessage((char *)tmp,length+4) ;
#else
	memcpy(tmp,data,length) ;
	SendPaket(tmp,length+4) ;
#endif
	safe_free(tmp) ;
}

unsigned char *needAckData = 0 ;
int				needAckLength = 0 ;

void Resend802_11withNoAck(void)
{
	if (needAckData)
	{
#ifdef ARM9
		if (!IPC_AllreadySending(needAckData,needAckLength+4))		// only send if we don't have it in the send queue
			IPC_SendMessage((char *)needAckData,needAckLength+4) ;
		IPC_WaitForAllSent() ;

#else
		SendPaket(needAckData,needAckLength) ;
#endif
	}
}

void RegisterACK(void)
{
	if (needAckData) safe_free(needAckData) ;
	needAckData = 0 ;
}

void Send802_11NeedACK(unsigned char *data, int length)
{
	if (needAckData) safe_free(needAckData) ;
	needAckData = (unsigned char *)safe_malloc(length+4) ;
#ifdef ARM9
	needAckLength = length ;
	*(unsigned long *)needAckLength = IPCTAG_DATA ;
	memcpy(needAckData+4,data,length) ;
	if (!IPC_AllreadySending(needAckData,length+4))		// only send if we don't have it in the send queue
		IPC_SendMessage((char *)needAckData,length+4) ;
	IPC_WaitForAllSent() ;

#else
	needAckLength = length+4 ;
	memcpy(needAckData,data,length) ;
	SendPaket(data,length+4) ;
#endif
}

unsigned short sequence = 0 ;

void Send802_11Data(unsigned char *toMAC,unsigned char *data, int length)
{
	unsigned char *frame = (unsigned char *)safe_malloc(24 + length) ;
	
	memset(frame,0,24+length) ;

	*(unsigned short *)frame = 0x0208 ; 
	memcpy(frame+4,toMAC,6) ;
	memcpy(frame+10,ownMAC,6) ;
	memset(frame+16,0xFF,6) ;

	memcpy(frame+24,data,length) ;

	sequence += (1 << 4) ;
	frame[22] = sequence & 0xF0 ;
	frame[23] = (sequence >> 8) & 0xFF ;


	Send802_11(frame,24+length) ;
	safe_free(frame) ;
}

void SetChannel(unsigned char channel)
{
	#ifdef ARM9
		char *sw = (char *)safe_malloc(5) ; 
		*(unsigned long *)&sw[0] = IPCTAG_CHANNEL ;
		sw[4] = channel ;
		IPC_SendMessage(sw,5) ;
		IPC_WaitForAllSent() ;
		safe_free(sw) ;
	#else
		extern void MySetChannel(unsigned char channel) ;
		MySetChannel(channel) ;
	#endif
}

typedef struct ACKFRAME
{
	FRAMECONTROL			fc ;
	unsigned short			duration ;
	unsigned char			address[6] ;
} ACKFRAME, *LPACKFRAME ;

void SendAckTo(unsigned char *mac)
{
	ACKFRAME ack ;
	memset(&ack,0,sizeof(ack)) ;
	ack.fc.type = 1 ;
	ack.fc.subType = 0x0D ;
	memcpy(&ack.address[0],mac,6) ;
	Send802_11((unsigned char *)&ack,sizeof(ack)) ;
}

#ifdef ARM9

void LWIFI_IPC_Callback(unsigned char *data, unsigned long length)
{
	if (*(unsigned long *)data == IPCTAG_DATA)
	{
		Handle802_11((unsigned char *)data+10+12,length-10-12) ;
	} else 
	if (*(unsigned long *)data == IPCTAG_MAC)
	{
		UpdateMAC((unsigned char *)data + 4) ;
	} else 
	if (*(unsigned long *)data == IPCTAG_HINT)
	{
		// hints (debug)
	} else
	{
		IPC_PassCustomMessage((unsigned char *)data,length) ;
	}
}

void IPC_RcvCompleteCheck(void)
{
	//char *WIFI_IPC_buffer = (char *)safe_malloc(2000) ;
	//unsigned long length = 2000 ;
	//while (IPC_GetMessage(WIFI_IPC_buffer,&length))
	//{
	//	if (*(unsigned long *)WIFI_IPC_buffer == IPCTAG_DATA)
	//	{
	//		Handle802_11((unsigned char *)WIFI_IPC_buffer+10+12,length-10-12) ;
	//	} else 
	//	if (*(unsigned long *)WIFI_IPC_buffer == IPCTAG_MAC)
	//	{
	//		UpdateMAC((unsigned char *)WIFI_IPC_buffer + 4) ;
	//	} else 
	//	if (*(unsigned long *)WIFI_IPC_buffer == IPCTAG_HINT)
	//	{
	//		// hints (debug)
	//	} else
	//	{
	//		IPC_PassCustomMessage((unsigned char *)WIFI_IPC_buffer,length) ;
	//	}
	//	length = 2000 ;
	//}
	//safe_free(WIFI_IPC_buffer) ;
}

#endif
