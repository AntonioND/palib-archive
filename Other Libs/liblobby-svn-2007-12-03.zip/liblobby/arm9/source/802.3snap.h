#ifndef _802_3_SNAP_INCLUDED
#define _802_3_SNAP_INCLUDED

#ifdef __cplusplus
  extern "C" {
#endif

typedef void (*RECEIVEPROTOCOL_PROC)(unsigned char *data, int length,unsigned char *from) ;

void Set802_3snapProtocolReceiver(unsigned short protocol, RECEIVEPROTOCOL_PROC callback) ;
void Handle802_3snap(unsigned char *data,int length, unsigned char *from) ;
void Send802_3snap(unsigned short protocol, unsigned char *data, int length) ;
void Send802_3snapTo(unsigned short protocol, unsigned char *data, int length, unsigned char *to) ;

#ifdef __cplusplus
  }
#endif

#endif
