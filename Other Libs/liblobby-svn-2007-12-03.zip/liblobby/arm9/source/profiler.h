#ifndef profiler_included
#define profiler_included

#ifdef __cplusplus
  extern "C" {
#endif

#ifndef PROFILING
	// define dummies (empty -> consuming no time)
	#define PROFILER_Init(filename)		
	#define PROFILER_Shutdown(nothing)
	#define	PROFILER_GenerateState(stateName,id)
	#define PROFILER_EnterState(id)
	#define PROFILER_LeaveState(id)
#else
	void PROFILER_Init(char *filename) ;
	void PROFILER_Shutdown(void) ;

	void PROFILER_GenerateState(char *stateName, unsigned long id) ;

	void PROFILER_EnterState(unsigned long id) ;
	void PROFILER_LeaveState(unsigned long id) ;
#endif

#ifdef __cplusplus
  }
#endif

#endif
