#include "802.3snap.h"
#ifdef WIN32
	#define safe_malloc	malloc
	#define safe_free free 
#else
	#include "safe_malloc.h"
#endif
#include <string.h>
#include "802.11.h"

typedef struct SNAP
{
	unsigned char			dsap,
							ssap,
							type ;
	unsigned char			reserved[3] ;
	unsigned char			protocolH,
							protocolL ;
} SNAP, *LPSNAP ;

typedef struct RECEIVERS
{
	unsigned short			protocol ;
	RECEIVEPROTOCOL_PROC	callback ;
	struct RECEIVERS *		next ;
} RECEIVERS, *LPRECEIVERS ;

LPRECEIVERS receivers = 0 ;

void Set802_3snapProtocolReceiver(unsigned short protocol, RECEIVEPROTOCOL_PROC callback)
{
	if (!receivers)
	{
		// first in list
		receivers = (LPRECEIVERS)safe_malloc(sizeof(RECEIVERS)) ;
		receivers->next = 0 ;
		receivers->callback = callback ;
		receivers->protocol = protocol ;
	} else
	{
		LPRECEIVERS tmp = receivers ;
		while (tmp->protocol != protocol)
		{
			if (!tmp->next)
			{
				// end of list, append handler
				tmp->next = (LPRECEIVERS)safe_malloc(sizeof(RECEIVERS)) ;
				tmp->next->next = 0 ;
				tmp->next->callback = callback ;
				tmp->next->protocol = protocol ;
				return ;
			}
			tmp = tmp->next ;
		}
		// incase we allready know this protocol, update the handler
		tmp->callback = callback ;
	}
}

void Handle802_3snap(unsigned char *data,int length, unsigned char *from)
{

	LPSNAP snap = (LPSNAP)data ;
	LPRECEIVERS tmp = receivers ;
	unsigned short protocol = (((unsigned short)(snap->protocolH)) << 8) | (snap->protocolL) ;
	// Get Protocol handler and handle it!	
	while (tmp!=0)
	{
		if (tmp->protocol==protocol)
		{
			tmp->callback(data + 8, length - 8,from) ;
			return ;
		} 
		tmp = tmp->next ;
	}
}

unsigned char anymac[6] = { 0xff,0xff,0xff,0xff,0xff,0xff } ;

void Send802_3snap(unsigned short protocol, unsigned char *data, int length) 
{
	Send802_3snapTo(protocol,data,length,&anymac[0]) ;
}

void Send802_3snapTo(unsigned short protocol, unsigned char *data, int length, unsigned char *to) 
{
	unsigned char *frame = (unsigned char *)safe_malloc(length + 8) ;
	memset(frame,0,length+8) ;
	frame[0] = 0xAA ;			// SNAP magic
	frame[1] = 0xAA ;
	frame[2] = 0x03 ;
	*(unsigned short *)(frame+6) = ((protocol >> 8) & 0xFF) | ((protocol << 8) & 0xFF00);
	memcpy(frame+8,data,length) ;
	Send802_11Data(to,frame,length+8) ;
	safe_free(frame) ;
}
