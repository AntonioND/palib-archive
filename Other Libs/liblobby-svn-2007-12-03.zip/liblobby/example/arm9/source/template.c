
#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>

#include "MessageQueue.h"
#include "802.11.h"
#include "lobby.h"
#include <fat.h>
#include <malloc.h>
#include <string.h>


int frame = 0 ;

void VBlankIRQ(void)
{
	REG_IF = IRQ_VBLANK ;
	IPC_RcvCompleteCheck() ;
	LOBBY_Update() ;
}

char *msg = 0 ;

int recved = 0, sent = 0 ;

void receiveText(unsigned char *data, int length, LPLOBBY_USER from)
{
	if (msg) free(msg) ;
	msg = (char *)safe_malloc(length) ; // strdup((char *)data) ;
	strcpy(msg,data) ;
	recved ++ ;
}

int main(void) 
{
	REG_EXMEMCNT=0xe800;

	powerON(POWER_ALL);
	REG_IME = 0 ;
	REG_IE = 0 ;
	REG_IF = 0xFFFF ;

	videoSetMode(0);	//not using the main screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
	vramSetBankC(VRAM_C_SUB_BG);

	SUB_BG0_CR = BG_MAP_BASE(31);

	BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

	//consoleInit() is a lot more flexible but this gets you up and running quick
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
	

	defaultExceptionHandler() ;

	irqInit() ;

	// Startup IPC engine
	IPC_Init() ;
	IPC_SetChannelCallback(0,&LWIFI_IPC_Callback) ;
//	IPC_SetMsgCompleteCallback(&IPC_RcvCompleteCheck) ;

	// usual VBlank
	irqSet(IRQ_VBLANK,&VBlankIRQ) ;
	irqEnable(IRQ_VBLANK) ;

	consoleClear() ;
	
	int selected = 0 ;

	LOBBY_Init() ;
	LOBBY_SetStreamHandler(0x0001,&receiveText) ;

	while (1) 
	{
		/* handle input */
		int max = LOBBY_GetNumberOfKnownUsers() ;
		scanKeys() ;
		if (keysDown() & KEY_DOWN)
		{
			selected++ ;
		}
		if (keysDown() & KEY_UP)
		{
			selected-- ;
		}
		if (max > 0) selected %= max ;
		if (keysDown() & KEY_START)
		{
			LOBBY_CreateRoom("Mighty\'s room",2,1,1) ;
		}
		if (keysDown() & KEY_A)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x0001,(unsigned char *)"Key [A] pressed.",17) ;
			sent++ ;
		}
		if (keysDown() & KEY_B)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x0001,(unsigned char *)"Key [B] pressed.",17) ;
			sent++ ;
		}
		if (keysDown() & KEY_X)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x0001,(unsigned char *)"Key [X] pressed.",17) ;
			sent++ ;
		}
		if (keysDown() & KEY_Y)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x0001,(unsigned char *)"Key [Y] pressed.",17) ;
			sent++ ;
		}
		if (keysHeld() & KEY_SELECT)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x8001,(unsigned char *)"...",17) ;
		}
		if (keysHeld() & KEY_R)
		{
			LOBBY_SendToUser(LOBBY_GetUserByID(selected),0x0001,(unsigned char *)"...",17) ;
			sent++ ;
		}
		/* display all users */
		int i ;
		printf("\x1b[0;0H") ;
		for (i = 0;i<max;i++)
		{
			LPLOBBY_USER user = LOBBY_GetUserByID(i) ;
			if (i==selected)
			{
				printf("->%s (%s)       \n",LOBBY_GetUserName(user),LOBBY_IsTimedOut(user)?"TIMEOUT":"OK") ;
			} else
			{
				printf("  %s (%s)       \n",LOBBY_GetUserName(user),LOBBY_IsTimedOut(user)?"TIMEOUT":"OK") ;
			}
		}
		printf("Received %d, Sent %d\n",recved,sent) ;
		printf("Last Received Text:\n") ;
		if (msg) 
			printf("%s\n",msg) ;
		swiWaitForVBlank() ;
	}
	
	

	return 0;
}
