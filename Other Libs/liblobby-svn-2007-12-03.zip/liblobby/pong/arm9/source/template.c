/*
 
  Pong example for DS to DS lobby
  by Matti "melw" Palosuo

*/

#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "MessageQueue.h"
#include "802.11.h"
#include "lobby.h"
#include <fat.h>
#include <malloc.h>
#include <string.h>

#include "numbers.h"

#define boolean int
#define true 1
#define false 0

#define LOCAL 0
#define LOBBY 1
#define SERVER 0
#define CLIENT 1

#define DEBUG_MIN 8
#define DEBUG_MAX 20

#define PONG_GAMECODE 69
#define PONG_VERSION 2

#define NUM_SPRITES 32
#define NUM_PLAYERS 2
#define SPRITE_BALL 0
#define SPRITE_BATS 1
#define SPRITE_NUMBERS 3
#define SPRITE_BORDER 7

#define X_RES 256
#define Y_RES 192
#define X_CEN 128
#define Y_CEN 96

#define MAX_BAT_SPEED 20
#define MIN_BALL_SPEED 32
#define MAX_BALL_SPEED 56
#define BAT_WIDTH 8
#define BAT_HEIGHT 32
#define BALL_WIDTH 8
#define BALL_HEIGHT 8

#define GAME_STATE_MENU 0
#define GAME_STATE_INGAME 1
#define GAME_STATE_LOBBY 2

#define MENU_MAIN_INDEX 0
#define MENU_LOBBY_INDEX 1

static char* MENU_TEXTS[] = { 
	"local game",
	"lobby game",
	"host game",
	"join game"
};

/* start a new game (server -> client) */
#define MESSAGE_GAME_START 1
// [0] identifier (MESSAGE_GAME_START)
// [1] ballDirection (2 bytes)
// [3] ballX (3 bytes)
// [6] ballY (3 bytes)
// [9] ballSpeed

/* join into a game (client -> server) */
#define MESSAGE_GAME_JOIN 2
// [0] identifier (MESSAGE_GAME_JOIN)
// no data

/* update ball position and scores after a collision (server -> client) */
#define MESSAGE_GAME_UPDATE_BALL 3
// [0] identifier (MESSAGE_GAME_UPDATE_BALL)
// [1] ballDirection (2 bytes)
// [3] ballX (3 bytes)
// [6] ballY (3 bytes)
// [9] ballSpeed
// [10] playerScore[SERVER]
// [11] playerScore[CLIENT]

/* update bat position when starting or ending bat movement (server <-> client) */
#define MESSAGE_GAME_UPDATE_BAT 4
// [0] identifier (MESSAGE_GAME_UPDATE_BAT)
// [1] batMoved i.e. are we starting or ending a movement
// [2] batY (2 bytes)
// [4] batSpeed
// [5] batDirection

/* end a game */	
#define MESSAGE_GAME_END 5
// TODO

#define MAX_DATA 128

unsigned char sendBuffer[MAX_DATA];

SpriteEntry sprites[NUM_SPRITES];

int batX[NUM_PLAYERS];
int batY[NUM_PLAYERS];
int batSpeed[NUM_PLAYERS];
boolean batMoved[NUM_PLAYERS];
int batDirection[NUM_PLAYERS];
int playerScore[NUM_PLAYERS];
int ballX,ballY,ballSpeed,ballDirection;
int gameState;
int currentMenu, currentMenuIndex;
boolean isServer, isClient;
int debugCounter = DEBUG_MIN;

boolean lobbyInited = false;
int gameMode = LOCAL;
LPLOBBY_USER server = NULL;
LPLOBBY_USER client = NULL;
LPLOBBY_ROOM ownRoom = NULL;

void startGame(int mode);

void updateOAM(void)
{
	DC_FlushRange(sprites,128*sizeof(SpriteEntry));
	dmaCopy(sprites, OAM, 128 * sizeof(SpriteEntry));
}

void moveSprite(int index, u16 x, u16 y)
{
	sprites[index].attribute[1] &= 0xFE00;
	sprites[index].attribute[1] |= (x & 0x01FF);
	sprites[index].attribute[0] &= 0xFF00;
	sprites[index].attribute[0] |= (y & 0x00FF);
}

void updateSpriteTile(int index, int tile)
{
	sprites[index].attribute[2] = ATTR2_ALPHA(1) | (4+tile*16);
}

void initSprites(void)
{
	int i,x,y;
	
	for(i=0;i<NUM_SPRITES;i++)
	{
		sprites[i].attribute[0] = ATTR0_DISABLED;
		sprites[i].attribute[1] = 0;
		sprites[i].attribute[2] = 0;
		sprites[i].attribute[3] = 0;
	}

	// "ball" - i.e. square :)
	sprites[SPRITE_BALL].attribute[0] = ATTR0_BMP;
	sprites[SPRITE_BALL].attribute[1] = ATTR1_SIZE_8;
	sprites[SPRITE_BALL].attribute[2] = ATTR2_ALPHA(1)| 0;

	// pads
	for(i=0;i<NUM_PLAYERS;i++)
	{
		sprites[SPRITE_BATS+i].attribute[0] = ATTR0_BMP | ATTR0_TALL;
		sprites[SPRITE_BATS+i].attribute[1] = ATTR1_SIZE_16;
		sprites[SPRITE_BATS+i].attribute[2] = ATTR2_ALPHA(1)| 0;
	}
	
	// numbers
	for(i=0;i<4;i++)
	{
		sprites[SPRITE_NUMBERS+i].attribute[0] = ATTR0_BMP | 10;
		sprites[SPRITE_NUMBERS+i].attribute[1] = ATTR1_SIZE_32 | (X_CEN-42+i*18+(i>1?18:0));
		sprites[SPRITE_NUMBERS+i].attribute[2] = ATTR2_ALPHA(1) | 4;
	}

	// border
	for(i=0;i<8;i++)
	{
		sprites[SPRITE_BORDER+i].attribute[0] = ATTR0_BMP | (i*24);
		sprites[SPRITE_BORDER+i].attribute[1] = ATTR1_SIZE_32 | (X_CEN-2);
		sprites[SPRITE_BORDER+i].attribute[2] = ATTR2_ALPHA(1) | 160;
	}

	for(i=0;i<256;i++) // pads & ball fully white
		SPRITE_GFX[i]=RGB15(31,31,31)|(1<<15);

	for(i=0;i<10;i++) // numbers from array (using 4x4 pixels)
	{
		for(y=0;y<4*NUMBERS_HEIGHT;y++)
		{
			for(x=0;x<4*NUMBERS_WIDTH;x++)
			{
				int val = (y>>2)*NUMBERS_WIDTH+(x>>2);
				SPRITE_GFX[256+i*32*32+x+(y*32)] = RGB15(numbers[i][val]*31, numbers[i][val]*31, numbers[i][val]*31) | (1<<15);
			}
		}
	}
	for(y=0;y<32;y++) // dotted border, gray
	{
		for(x=0;x<4;x++)
		{
			if((y>>2)%2==0)
				SPRITE_GFX[10496+x+(y*32)] = RGB15(15, 15, 15) | (1<<15);
		}
	}
}

void receiveUserData(unsigned char *data, int length, LPLOBBY_USER from)
{
	if(debugCounter>DEBUG_MAX) debugCounter = DEBUG_MIN;

	switch(data[0])
	{
		// client -> server
		case MESSAGE_GAME_JOIN:
		{
			client = from;
			startGame(LOBBY);

			iprintf("\x1b[%d;0HMSG GAME JOIN      ", debugCounter++);
		}
		break;

		// server -> client
		case MESSAGE_GAME_START:
		{
			ballDirection = data[1]+(data[2]<<8);
			ballX = data[3]+(data[4]<<8)+(data[5]<<16);
			ballY = data[6]+(data[7]<<8)+(data[8]<<16);
			ballSpeed = data[9];
			startGame(LOBBY);

			iprintf("\x1b[%d;0HMSG GAME START      ", debugCounter++);
		}
		break;
		
		// update bat position (both client & server)
		case MESSAGE_GAME_UPDATE_BAT:
		{
			int index = SERVER;
			if(isServer) index = CLIENT;
			
			batMoved[index] = data[1];
			batY[index] = data[2]+(data[3]<<8);
			batSpeed[index] = data[4]-MAX_BAT_SPEED;
			batDirection[index] = data[5]-1;

			iprintf("\x1b[%d;0HMSG UPDATE BAT: %d, %d, %d   ", debugCounter++, batY[index], batSpeed[index], batDirection[index]);
		}
		break;
		
		// server -> client
		case MESSAGE_GAME_UPDATE_BALL:
		{
			ballDirection = data[1]+(data[2]<<8);
			ballX = data[3]+(data[4]<<8)+(data[5]<<16);
			ballY = data[6]+(data[7]<<8)+(data[8]<<16);
			ballSpeed = data[9];
			playerScore[SERVER] = data[10];
			playerScore[CLIENT] = data[11];
			updateSpriteTile(SPRITE_NUMBERS, playerScore[SERVER]/10);
			updateSpriteTile(SPRITE_NUMBERS+1, playerScore[SERVER]%10);
			updateSpriteTile(SPRITE_NUMBERS+2, playerScore[CLIENT]/10);
			updateSpriteTile(SPRITE_NUMBERS+3, playerScore[CLIENT]%10);

			iprintf("\x1b[%d;0HMSG UPDATE BALL: %d, %d, %d  ", debugCounter++, ballDirection, ballX>>11, ballY>>11);
		}
		break;
	}
}

void userCallback(LPLOBBY_USER user, unsigned long reason)
{
	switch(reason)
	{
		case USERINFO_REASON_REGOGNIZE:
			iprintf("\x1b[%d;0Huser recognized %s    ", debugCounter++, LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_TIMEOUT:
			iprintf("\x1b[%d;0Huser timeout %s       ", debugCounter++, LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_RETURN:
			iprintf("\x1b[%d;0Huser returned %s      ", debugCounter++, LOBBY_GetUserName(user));
		break;
		case USERINFO_REASON_ROOMCREATED:
			iprintf("\x1b[%d;0Huser created room %s  ", debugCounter++, LOBBY_GetUserName(user));
			server = user;
		break;
		case USERINFO_REASON_ROOMCHANGE:
			iprintf("\x1b[%d;0Huser changed room %s  ", debugCounter++, LOBBY_GetUserName(user));
/*			if(currentMenu==MENU_LOBBY_INDEX&&isServer&&LOBBY_GetUserByID(USERID_MYSELF)!=user)
			{
				client = user;
				startGame(LOBBY);
			}*/
		break;
	}
	if(debugCounter>DEBUG_MAX) debugCounter = DEBUG_MIN;
}

void initGame()
{
	gameState = GAME_STATE_MENU;
	currentMenu = MENU_MAIN_INDEX; currentMenuIndex = 0;
	isServer = isClient = false;
}

void startGame(int mode)
{
	gameState = GAME_STATE_INGAME;
	gameMode = mode;

	int i;
	
	batX[SERVER]=BAT_WIDTH;
	batY[SERVER]=(Y_CEN<<2)-BAT_HEIGHT;
	batX[CLIENT]=X_RES-(BAT_WIDTH<<1);
	batY[CLIENT]=(Y_CEN<<2)-BAT_HEIGHT;
	for(i=0;i<NUM_PLAYERS;i++)
	{
		batSpeed[i]=0;
		playerScore[i]=0;
	}
	ballX=(X_CEN-(BALL_WIDTH<<1))<<11;
	ballY=(Y_CEN-(BALL_HEIGHT<<1))<<11;
	ballSpeed=MIN_BALL_SPEED;
	ballDirection=64;
	
	if(gameMode==LOBBY&&isServer) // inform client
	{
		memset(sendBuffer, 0, MAX_DATA);
		sendBuffer[0] = MESSAGE_GAME_START;
		sendBuffer[1] = ballDirection%256; sendBuffer[2] = ballDirection>>8;
		sendBuffer[3] = ballX%256; sendBuffer[4] = (ballX>>8)%256; sendBuffer[5] = (ballX>>16);
		sendBuffer[6] = ballY%256; sendBuffer[7] = (ballY>>8)%256; sendBuffer[8] = (ballY>>16);
		sendBuffer[9] = ballSpeed;
		LOBBY_SendToUser(client, 0x0001, sendBuffer, MAX_DATA);
	}
}

void hostGame()
{
	LOBBY_CreateRoom("PONG", NUM_PLAYERS, PONG_GAMECODE, PONG_VERSION);
	isServer = true;
}

void joinGame()
{
	if(server!=NULL)
	{
		LPLOBBY_ROOM room = LOBBY_GetRoomByUser(server);
		if(LOBBY_GetRoomGameCode(room)==PONG_GAMECODE)
		{
			LOBBY_JoinRoom(room);
			memset(sendBuffer, 0, MAX_DATA);
			sendBuffer[0] = MESSAGE_GAME_JOIN;
			LOBBY_SendToUser(server, 0x0001, sendBuffer, MAX_DATA);
			isClient = true;
			iprintf("\x1b[%d;0HRoom gamecode: %d   ", debugCounter++, LOBBY_GetRoomGameCode(room));
		}
		else
		{
			iprintf("\x1b[%d;0HRoom gamecode doesn't match! %d    ", debugCounter++, LOBBY_GetRoomGameCode(room));
		}
		if(debugCounter>DEBUG_MAX) debugCounter = DEBUG_MIN;
	}
}

void updateGame()
{
	int i,tempX,tempY;
	
	for(i=0;i<NUM_PLAYERS;i++) // update bat positions
	{
		batY[i]+=batSpeed[i];
		tempY = batY[i]>>2;
		if(tempY<0) { batSpeed[i]=batY[i]=tempY=0; } // stop at upper border
		if(tempY>Y_RES-BAT_HEIGHT) { batSpeed[i]=0; tempY=Y_RES-BAT_HEIGHT; batY[i]=tempY<<2; } // stop at lower border
		moveSprite(SPRITE_BATS+i, batX[i], tempY);
	}
	
	// update ball position & check collisions
	ballX+=(SIN_bin[ballDirection]*ballSpeed)>>5;
	ballY+=(COS_bin[ballDirection]*ballSpeed)>>5;
	tempX=(ballX>>11);
	tempY=(ballY>>11);

	if(gameMode==LOCAL||isServer)
	{
		boolean ballUpdated = false;
		if(tempY<1) // hits upper wall
		{
			tempY=ballY=0;
			if(ballDirection<256) ballDirection = 256-ballDirection;
			else ballDirection = 512-(ballDirection-256);
			ballUpdated = true;
		}
		else if(tempY>Y_RES-BALL_HEIGHT-1) // hits lower wall
		{
			tempY=Y_RES-BALL_HEIGHT;
			ballY=tempY<<11;
			if(ballDirection<256) ballDirection = 256-ballDirection;
			else ballDirection = 512-(ballDirection-256);
			ballUpdated = true;
		}
		if(tempX<-BALL_WIDTH) // score for client!
		{
			ballX=(X_CEN-(BALL_WIDTH<<1))<<11;
			ballY=(Y_CEN-(BALL_HEIGHT<<1))<<11;
			ballDirection=64+((rand()%8)-4); // 0...512 starting from bottom anti clockwise
			playerScore[CLIENT]++;
			ballSpeed=MIN_BALL_SPEED+((playerScore[SERVER]+playerScore[CLIENT])>>1); // slowly make ball faster
			if(ballSpeed>=MAX_BALL_SPEED) ballSpeed = MAX_BALL_SPEED;
			updateSpriteTile(SPRITE_NUMBERS+2, playerScore[CLIENT]/10);
			updateSpriteTile(SPRITE_NUMBERS+3, playerScore[CLIENT]%10);
			ballUpdated = true;
		}
		else if(tempX>X_RES) // score for server!
		{
			ballX=(X_CEN-(BALL_WIDTH<<1))<<11;
			ballY=(Y_CEN-(BALL_HEIGHT<<1))<<11;
			ballDirection=256+64+((rand()%2)<<7)+((rand()%8)-4); // 0...512 starting from bottom anti clockwise
			playerScore[SERVER]++;
			ballSpeed=MIN_BALL_SPEED+((playerScore[SERVER]+playerScore[CLIENT])>>1); // slowly make ball faster
			if(ballSpeed>=MAX_BALL_SPEED) ballSpeed = MAX_BALL_SPEED;
			updateSpriteTile(SPRITE_NUMBERS, playerScore[SERVER]/10);
			updateSpriteTile(SPRITE_NUMBERS+1, playerScore[SERVER]%10);
			ballUpdated = true;
		}		
		if(ballDirection>256&&tempX<(BAT_WIDTH<<1)+1&&tempX>=(BAT_WIDTH<<1)-1&&tempY>=((batY[0]>>2)-BALL_HEIGHT)&&tempY<(batY[0]>>2)+BAT_HEIGHT+(BAT_HEIGHT>>1)) // ball hits server bat
		{
			ballDirection=512-ballDirection+((rand()%8)-4);
			if(++ballSpeed>=MAX_BALL_SPEED) ballSpeed=MAX_BALL_SPEED;
			ballUpdated = true;
		}
		else if(ballDirection<256&&tempX>X_RES-(BAT_WIDTH*3)-1&&tempX<=X_RES-(BAT_WIDTH*3)+1&&tempY>=((batY[1]>>2)-BALL_HEIGHT)&&tempY<(batY[1]>>2)+BAT_HEIGHT+(BAT_HEIGHT>>1)) // ball hits client bat
		{
			ballDirection=512-ballDirection+((rand()%8)-4);
			if(++ballSpeed>=MAX_BALL_SPEED) ballSpeed=MAX_BALL_SPEED;
			ballUpdated = true;
		}
		if(gameMode==LOBBY&&isServer&&ballUpdated) // inform client about ball movement
		{
			memset(sendBuffer, 0, MAX_DATA);
			sendBuffer[0] = MESSAGE_GAME_UPDATE_BALL;
			sendBuffer[1] = ballDirection%256; sendBuffer[2] = ballDirection>>8;
			sendBuffer[3] = ballX%256; sendBuffer[4] = (ballX>>8)%256; sendBuffer[5] = (ballX>>16);
			sendBuffer[6] = ballY%256; sendBuffer[7] = (ballY>>8)%256; sendBuffer[8] = (ballY>>16);
			sendBuffer[9] = ballSpeed;
			sendBuffer[10] = playerScore[SERVER]; sendBuffer[11] = playerScore[CLIENT];
			LOBBY_SendToUser(client, 0x0001, sendBuffer, MAX_DATA);
		}
	}
	moveSprite(SPRITE_BALL, tempX, tempY);
}

void VBlankIRQ(void)
{
	REG_IF = IRQ_VBLANK;
	IPC_RcvCompleteCheck();
	LOBBY_Update();
	
	if(gameMode==LOBBY&&isServer)
	{
		if(LOBBY_GetUsercountInRoom(ownRoom)==NUM_PLAYERS) // start the game
		{
			client = LOBBY_GetRoomUserBySlot(ownRoom, 1);
			startGame(LOBBY);
		}
	}
}

int main(void) 
{
	int i;
	REG_EXMEMCNT=0xe800;

	powerON(POWER_ALL);
	REG_IME = 0 ;
	REG_IE = 0 ;
	REG_IF = 0xFFFF ;
	
  vramSetMainBanks(VRAM_A_MAIN_SPRITE, VRAM_B_MAIN_SPRITE, VRAM_C_SUB_BG, VRAM_D_LCD);
  videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_SPR_1D_BMP);
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);

  SUB_BG0_CR = BG_MAP_BASE(31);
	BG_PALETTE_SUB[255] = RGB15(31,31,31);//by default font will be rendered with color 255
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);

	defaultExceptionHandler();

	irqInit();
	IPC_Init();
	IPC_SetChannelCallback(0,&LWIFI_IPC_Callback) ;
//	IPC_SetMsgCompleteCallback(&IPC_RcvCompleteCheck);

	// usual VBlank
	irqSet(IRQ_VBLANK,&VBlankIRQ);
	irqEnable(IRQ_VBLANK);

	initSprites();
	
	iprintf("\x1b[0;0HPong example v0.%d", PONG_VERSION);

	while (1) 
	{
		/* handle input */
		scanKeys();

		switch(gameState)
		{
			case GAME_STATE_MENU:
			{
				if(keysDown()&KEY_DOWN)
					if(++currentMenuIndex>1) currentMenuIndex=0;
				if(keysDown()&KEY_UP)
					if(--currentMenuIndex<0) currentMenuIndex=1;
				if(keysDown()&KEY_A)
				{
					if(currentMenu==MENU_MAIN_INDEX&&currentMenuIndex==0)
						startGame(LOCAL);
					else if(currentMenu==MENU_MAIN_INDEX&&currentMenuIndex==1)
					{
						currentMenu=MENU_LOBBY_INDEX;
						currentMenuIndex=0;
						if(!lobbyInited)
						{
							LOBBY_Init() ;
							LOBBY_SetStreamHandler(0x0001,&receiveUserData);
							LOBBY_SetUserInfoCallback(&userCallback);
							lobbyInited = true;
						}
					}
					else if(currentMenu==MENU_LOBBY_INDEX&&currentMenuIndex==0)
						hostGame();
					else
						joinGame();
				}
				if(keysDown()&KEY_B)
					if(currentMenu==MENU_LOBBY_INDEX)
						currentMenu=MENU_MAIN_INDEX;

				for(i=0;i<2;i++)
				{
					iprintf("\x1b[%d;0H%s %s %s         ", 2+i, (i==currentMenuIndex?"*":" "), MENU_TEXTS[currentMenu*2+i], 
						     (currentMenu==MENU_LOBBY_INDEX&&i==1&&server!=NULL?LOBBY_GetUserName(server):""));
				}
				
				if(isServer)
					iprintf("\x1b[5;0Hwaiting for a player to join...");
			}
			break;

			case GAME_STATE_INGAME:
			{
				for(i=0;i<NUM_PLAYERS;i++)
				{
					if(gameMode==LOCAL||(i==SERVER&&isServer)||(i==CLIENT&&isClient))
						batMoved[i] = false;
				}
				
				int batIndex = 0;
				if(gameMode==LOBBY&&isClient)
					batIndex++;
				if(keysHeld()&KEY_DOWN)
				{
					batMoved[batIndex] = true;
					batDirection[batIndex] = 1;
				}
				if(gameMode==LOCAL&&(keysHeld()&KEY_B))
				{
					batMoved[CLIENT] = true;
					batDirection[CLIENT] = 1;
				}
				if(keysHeld()&KEY_UP)
				{
					batMoved[batIndex] = true;
					batDirection[batIndex] = -1;
				}
				if(gameMode==LOCAL&&(keysHeld()&KEY_X))
				{
					batMoved[CLIENT] = true;
					batDirection[CLIENT] = -1;
				}

				for(i=0;i<NUM_PLAYERS;i++)
				{
					if(!batMoved[i]) // didn't move the bat, decelerate
					{
						if(batSpeed[i]>0) batSpeed[i]--;
						if(batSpeed[i]<0) batSpeed[i]++;
					}
					else // if(batSpeed[i]!=0)
					{
						if(batDirection[i]==1)
						{
							if(++batSpeed[i]>MAX_BAT_SPEED) 
								batSpeed[i]=MAX_BAT_SPEED;
						}
						else
						{
							if(--batSpeed[i]<-MAX_BAT_SPEED)
								batSpeed[i]=-MAX_BAT_SPEED;
						}
					}
				}

				updateGame();

				if(gameMode==LOBBY)
				{
					for(i=0;i<NUM_PLAYERS;i++)
					{
						 // send only bat update message when key is pressed or released
						if(((i==SERVER&&isServer)||(i==CLIENT&&isClient))&&
						  (keysDown()&KEY_DOWN||keysDown()&KEY_UP||keysUp()&KEY_DOWN||keysUp()&KEY_UP))
						{
							memset(sendBuffer, 0, MAX_DATA);
							sendBuffer[0] = MESSAGE_GAME_UPDATE_BAT;
							sendBuffer[1] = batMoved[i];
							sendBuffer[2] = batY[i]%256; sendBuffer[3] = batY[i]>>8;
							sendBuffer[4] = batSpeed[i]+MAX_BAT_SPEED; // keep unsigned 
							sendBuffer[5] = batDirection[i]+1; // keep unsigned
							LOBBY_SendToUser((isServer?client:server), 0x0001, sendBuffer, MAX_DATA);
						}
					}
				}

				updateOAM();
				
				iprintf("\x1b[2;0Hbat 0: %d,%d (acc: %d)    ", batX[0], batY[0], batSpeed[0]);
				iprintf("\x1b[3;0Hbat 1: %d,%d (acc: %d)    ", batX[1], batY[1], batSpeed[1]);
				iprintf("\x1b[4;0Hball: %d,%d (dir: %d)     ", ballX>>11, ballY>>11, ballDirection);
				iprintf("\x1b[5;0Hball speed: %d            ", ballSpeed);
				iprintf("\x1b[6;0Hscore %d-%d               ", playerScore[0], playerScore[1]);
			}
			break;
		}

		swiWaitForVBlank();
	}
	
	return 0;
}
