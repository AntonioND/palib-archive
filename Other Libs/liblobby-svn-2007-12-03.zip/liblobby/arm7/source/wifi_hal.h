#ifndef wifi_rf_included
#define wifi_rf_included

#ifdef __cplusplus
  extern "C" {
#endif

void		LWIFI_SetBeaconPeriod(int beacon_period) ;	
void		LWIFI_SetMode(int wifimode) ;
void		LWIFI_SetPreambleType(int preamble_type) ;
void		LWIFI_DisableTempPowerSave() ;
void		LWIFI_SetChannel(unsigned char channel) ;
void		LWIFI_Init(void) ;
void		LWIFI_SendRAW(char *buffer, int length) ;
void		LWIFI_SetBSSID(unsigned char *bssid) ;

void		LWIFI_IPC_UpdateNOIRQ(void) ;

#ifdef __cplusplus
  }
#endif

#endif
