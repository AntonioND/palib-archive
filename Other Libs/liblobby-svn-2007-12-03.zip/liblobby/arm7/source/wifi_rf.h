#ifndef wifi_rf_included
#define wifi_rf_included

#ifdef __cplusplus
  extern "C" {
#endif

#include <nds.h>

// RF registervalue defines
#define			WIFI_RF_IFVGA_REGULATOR		BIT(0)			// regulator chip IDs
#define			WIFI_RF_IFVCO_REGULATOR		BIT(1)
#define			WIFI_RF_RFVCO_REGULATOR		BIT(2)
#define			WIFI_RF_ALL_REGULATOR		WIFI_RF_IFVGA_REGULATOR | WIFI_RF_IFVCO_REGULATOR | WIFI_RF_RFVCO_REGULATOR 
#define			WIFI_RF_DIVIDER_1			3				// reference clock devider
#define			WIFI_RF_DIVIDER_2			0
#define			WIFI_RF_DIVIDER_3			1
#define			WIFI_RF_DIVIDER_44			2
#define			WIFI_RF_VOLTAGE(millivolt)	(((millivolt) / 330) & 0x000F)
#define			WIFI_RF_AUTOCALIBRATEIFPLL	BIT(11)
#define			WIFI_RF_LOCKDETECTIFPLL		BIT(10)
#define			WIFI_RF_IFPLLPRESCALE_4OF5	0
#define			WIFI_RF_IFPLLPRESCALE_8OF9	BIT(9)
#define			WIFI_RF_HYBERNATE			BIT(3)

// RF I/O
void			WIFI_RF_Write						(unsigned long data) ;

// these are only possible in old 'phat' DS
#ifdef RF2958
void			WIFI_RF_WriteRegister				(unsigned short address, unsigned long value) ;
unsigned long	WIFI_RF_ReadRegister				(unsigned short address) ;

// RF control
void			WIFI_RF_Hybernate					(int status) ;
void			WIFI_RF_SetReferenceDevider			(char devider) ;
void			WIFI_RF_EnableRegulator				(char regMask) ;
void			WIFI_RF_DisableRegulator			(char regMask) ;
void			WIFI_RF_SetVCOCoarseTuningVoltage	(unsigned short millivolt) ;
void			WIFI_RF_SetIFPLLAutoCalibrate		(int status) ;
void			WIFI_RF_SetIFPLLLockDetect			(int status) ;
void			WIFI_RF_SetIFPLLPrescale			(unsigned long mode) ;
#endif

#ifdef __cplusplus
  }
#endif

#endif
