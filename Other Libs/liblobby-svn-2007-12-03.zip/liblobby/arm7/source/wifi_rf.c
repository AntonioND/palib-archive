#include "wifi_rf.h"
#include "wifi_hal_registernames.h"

void WIFI_RF_Write(unsigned long data)
{
	WIFI_REGISTER(WIFI_RFSIO_CR) = 0x18 ;		
	while (WIFI_REGISTER(WIFI_RFSIO_STATUS) & 1) ;
	WIFI_REGISTER(WIFI_RFSIO_DATA1) = (data & 0xFFFF) ;
	WIFI_REGISTER(WIFI_RFSIO_DATA2) = (data >> 16) ;
	while (WIFI_REGISTER(WIFI_RFSIO_STATUS) & 1) ;
}

#ifdef RF2958

void WIFI_RF_WriteRegister(unsigned short address, unsigned long value) 
{
   value = (value & 0x0003FFFF) | (address << 18) ;
   WIFI_RF_Write(value) ;
} 

unsigned long WIFI_RF_ReadRegister(unsigned short address)
{
	unsigned long data = 0 ;
	WIFI_REGISTER(WIFI_RFSIO_CR) = 0xFF98 ;		
	while (WIFI_REGISTER(WIFI_RFSIO_STATUS) & 1) ;
	WIFI_REGISTER(WIFI_RFSIO_DATA1) = 0x0000 ;								// content of reg, will be filled by IO and reread later
	WIFI_REGISTER(WIFI_RFSIO_DATA2) = ((address * 4) | 0x0080) & ~3 ;		// flag read, set address
	while (WIFI_REGISTER(WIFI_RFSIO_STATUS) & 1) ;
	data |= WIFI_REGISTER(WIFI_RFSIO_DATA2) << 16 ;
	data  = WIFI_REGISTER(WIFI_RFSIO_DATA1) ;
	while (WIFI_REGISTER(WIFI_RFSIO_STATUS) & 1) ;
	WIFI_REGISTER(WIFI_RFSIO_CR) = 0x18 ;		
	return data ;
}

void WIFI_RF_Init_PREPARED_NOT_USED_YET(void)
{
	WIFI_RF_Hybernate(0) ;
	WIFI_RF_SetReferenceDevider(WIFI_RF_DIVIDER_1) ;
	WIFI_RF_EnableRegulator(WIFI_RF_ALL_REGULATOR) ;
	WIFI_RF_SetVCOCoarseTuningVoltage(1000) ;			 /* 1000mV, 1V */
	WIFI_RF_SetIFPLLAutoCalibrate(1) ;
	WIFI_RF_SetIFPLLLockDetect(1) ;

}

void WIFI_RF_Hybernate(int status)
{
	if (status)
		WIFI_RF_WriteRegister(0,WIFI_RF_ReadRegister(0) | WIFI_RF_HYBERNATE) ;
	else
		WIFI_RF_WriteRegister(0,WIFI_RF_ReadRegister(0) & ~WIFI_RF_HYBERNATE) ;
}

void WIFI_RF_SetReferenceDevider(char devider)
{
	WIFI_RF_WriteRegister(0,(WIFI_RF_ReadRegister(0) & ~0xC000) | ((devider & 3) << 14)) ;
}

void WIFI_RF_EnableRegulator(char regMask)
{
	WIFI_RF_WriteRegister(0,WIFI_RF_ReadRegister(0) | (regMask & 7)) ;
}

void WIFI_RF_DisableRegulator(char regMask)
{
	WIFI_RF_WriteRegister(0,WIFI_RF_ReadRegister(0) & ~(regMask & 7)) ;
}

/* expects voltage in millivolt */
/* range: from 0 to 3599 */
void WIFI_RF_SetVCOCoarseTuningVoltage(unsigned short millivolt)
{
	if (millivolt > 3599) return ;
	WIFI_RF_WriteRegister(4,(WIFI_RF_ReadRegister(4) & ~0x000F) | WIFI_RF_VOLTAGE(millivolt)) ;
}

void WIFI_RF_SetIFPLLAutoCalibrate(int status)
{
	if (status)
		WIFI_RF_WriteRegister(4,WIFI_RF_ReadRegister(4) | WIFI_RF_AUTOCALIBRATEIFPLL) ;
	else
		WIFI_RF_WriteRegister(4,WIFI_RF_ReadRegister(4) & ~WIFI_RF_AUTOCALIBRATEIFPLL) ;
}

void WIFI_RF_SetIFPLLLockDetect(int status)
{
	if (status)
		WIFI_RF_WriteRegister(4,WIFI_RF_ReadRegister(4) | WIFI_RF_LOCKDETECTIFPLL) ;
	else
		WIFI_RF_WriteRegister(4,WIFI_RF_ReadRegister(4) & ~WIFI_RF_LOCKDETECTIFPLL) ;
}

void WIFI_RF_SetIFPLLPrescale(unsigned long mode)
{
	WIFI_RF_WriteRegister(4,(WIFI_RF_ReadRegister(4) & ~WIFI_RF_IFPLLPRESCALE_8OF9) | (mode & WIFI_RF_IFPLLPRESCALE_8OF9)) ;
}
#endif