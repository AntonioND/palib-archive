#include <nds.h>
#include <MessageQueue.h>
#include "safe_malloc.h"

#include "wifi_hal_registernames.h"
#include "wifi_rf.h"

void LWifiIRQ(void) ;


// other wifi related registers
#define WIFI_WAITCR			(*((volatile unsigned long *)0x04000206))

// different constants
#define POWER_WIFI			0x0002
#define FW_MAC				0x0036

void LWIFI_IPC_ChannelCallback(unsigned char *buffer, unsigned long length) ;

unsigned char LWIFI_BB_Read(unsigned short addr)
{
	int timeout = 10000 ;
	while ((WIFI_REGISTER(WIFI_BBSIO_STATUS) & 1) && (--timeout)) ;
	if (!timeout) 
	{
		return 0 ;
	}
	WIFI_REGISTER(WIFI_BBSIO_CR) = addr | 0x6000 ;
	while (WIFI_REGISTER(WIFI_BBSIO_STATUS) & 1) ;
	return WIFI_REGISTER(WIFI_BBSIO_READ) ;
}

void LWIFI_BB_Write(unsigned short addr, unsigned char data)
{
	int timeout = 10000;
	while ((WIFI_REGISTER(WIFI_BBSIO_STATUS) & 1) && (--timeout)) ;
	if (!timeout) 
	{
		return ;
	}
	WIFI_REGISTER(WIFI_BBSIO_WRITE) = data ;
	WIFI_REGISTER(WIFI_BBSIO_CR) = addr | 0x5000 ;
	timeout = 10000;
	while ((WIFI_REGISTER(WIFI_BBSIO_STATUS) & 1) && (--timeout)) ;
	return ;
}

#define		SPI_CR		(*((u16 volatile *) 0x040001C0))
#define		SPI_DATA	(*((u16 volatile *) 0x040001C2))
  
void LWIFI_Read_Flash(int address, char * destination, int length) {
	int i;
	while(SPI_CR&0x80);
	SPI_CR=0x8900;
	SPI_DATA=3;
	while(SPI_CR&0x80);
	SPI_DATA=(address>>16)&255;
	while(SPI_CR&0x80);
	SPI_DATA=(address>>8)&255;
	while(SPI_CR&0x80);
	SPI_DATA=(address)&255;
	while(SPI_CR&0x80);
	for(i=0;i<length;i++) {
		SPI_DATA=0;
		while(SPI_CR&0x80);
		destination[i]=SPI_DATA;
	}
	SPI_CR=0;
}
 
int LWIFI_ReadFlashByte(int address) {
	if(address<0 || address>511) return 0;
	char data ;
	LWIFI_Read_Flash(address,&data,1) ;
	return data ;
}
 
int LWIFI_ReadFlashBytes(int address, int numbytes) {
	int dataout=0;
	LWIFI_Read_Flash(address,(char *)&dataout,numbytes) ;
	return dataout;
}

int LWIFI_ReadFlashHWord(int address) {
	if(address<0 || address>510) return 0;
	return LWIFI_ReadFlashBytes(address,2);
}

void LWIFI_SetWepMode(int wepmode) {
	if(wepmode<0 || wepmode>7) return;
	if(wepmode==0) {
		WIFI_REGISTER(WIFI_RXWEPCNT)=0x0000;
	} else {
		WIFI_REGISTER(WIFI_RXWEPCNT)=0x8000;
	}
	if(wepmode==0) wepmode=1;
	WIFI_REGISTER(WIFI_MODE_WEP) = (WIFI_REGISTER(WIFI_MODE_WEP) & 0xFFC7) | (wepmode<<3);
}
	
void LWIFI_SetBeaconPeriod(int beacon_period) {
	if(beacon_period<0x10 || beacon_period>0x3E7) return;
	WIFI_REGISTER(WIFI_BEACONPERIOD) = beacon_period;
}
	
 void LWIFI_SetMode(int wifimode) {
	if(wifimode>3 || wifimode<0) return;
	WIFI_REGISTER(WIFI_MODE_WEP) = (WIFI_REGISTER(WIFI_MODE_WEP) & 0xfff8) | wifimode;
}

void LWIFI_SetPreambleType(int preamble_type) {
	if (preamble_type>1 || preamble_type<0) return;
	WIFI_REGISTER(WIFI_TXPREAMBLE) = (WIFI_REGISTER(WIFI_TXPREAMBLE) & 0xFFBF) | (preamble_type<<6);
}

void LWIFI_DisableTempPowerSave() {
	WIFI_REGISTER(WIFI_PSCNT) &= ~2;
	WIFI_REGISTER(0x8048) = 0;
}

u16 LWIFI_RF_SEQUENCE[32] = {
	0x0146, 0x0002,
	0x0148, 0x0017,
	0x014A, 0x0026,
	0x014C, 0x1818,
	0x0120, 0x0048,
	0x0122, 0x4840,
	0x0154, 0x0058,
	0x0144, 0x0042,
	0x0130, 0x0140,
	0x0132, 0x8064,
	0x0140, 0xE0E0,
	0x0142, 0x2443,
	0x0038, 0x000E,
	0x0124, 0x0032,
	0x0128, 0x01F4,
	0x0150, 0x0101
} ;

void LWIFI_RF_Init(void)
{
	int i ;
	for (i=0;i<sizeof(LWIFI_RF_SEQUENCE) / sizeof(u16);i+=2)
	{
		WIFI_REGISTER(LWIFI_RF_SEQUENCE[i]) = LWIFI_RF_SEQUENCE[i+1] ;
	}
	
	unsigned char RFIO_SETTINGS[3] ;
	readFirmware(0x40,&RFIO_SETTINGS[0],3) ;
	
	int numentries = RFIO_SETTINGS[2] ;
	int numbits = RFIO_SETTINGS[1] ;
	int numbytes = (numbits + 7) / 8 ;
	int format = RFIO_SETTINGS[0] ;
	
	unsigned char *rfBuffer = (unsigned char *)safe_malloc(numentries * numbytes) ;
	readFirmware(0xCE,rfBuffer,numentries * numbytes) ;
	WIFI_REGISTER(WIFI_RFSIO_CR) = ((numbits << 1) & 0x0100) | (numbits & 0x7F) ;
	if (format == 3) 
	{
		for(i=0;i<numentries;i++) 
		{ 
			WIFI_RF_Write(0x50000 | (i<<8) | rfBuffer[i]) ;
		} ;
	} else {
		for(i=0;i<numentries;i++) 
		{
			WIFI_RF_Write(*(unsigned short *)(rfBuffer + i*numbytes)) ;
		}
	}	
	safe_free(rfBuffer) ;
}

void LWIFI_SetChannel(int channel) {
	int i,n;
	if(channel<1 || channel>13) return;
	channel-=1;
	
	switch(LWIFI_ReadFlashByte(0x40)) {
		case 2:
		case 5:
			WIFI_RF_Write(LWIFI_ReadFlashBytes(0xf2+channel*6,3));
			WIFI_RF_Write(LWIFI_ReadFlashBytes(0xf5+channel*6,3));
	
			swiDelay( 12583 ); // 1500 us delay
	
			LWIFI_BB_Write(0x1E, LWIFI_ReadFlashByte(0x146+channel));
			break;
		case 3:
			n=LWIFI_ReadFlashByte(0x42);
			n+=0xCF;
			for(i=0;i<=LWIFI_ReadFlashByte(0x43);i++) {
				LWIFI_BB_Write(LWIFI_ReadFlashByte(n),LWIFI_ReadFlashByte(n+channel+1));
				n+=15;
			}
			for(i=0;i<LWIFI_ReadFlashByte(0x43);i++) {
				WIFI_RF_Write( (LWIFI_ReadFlashByte(n)<<8) | LWIFI_ReadFlashByte(n+channel+1) | 0x050000 );
				n+=15;
			}
			break;
		default:
			break;
	}
}

void LWIFI_Stop(void)
{
	unsigned long savedIME = REG_IME ;
	REG_IME = 0 ;
	WIFI_REGISTER(WIFI_IE)				= 0 ;
	WIFI_REGISTER(WIFI_MODE_RST)		= 0 ;
	WIFI_REGISTER(WIFI_USCOMPARE_CR)	= 0 ;
	WIFI_REGISTER(WIFI_USCOUNTER_CR)	= 0 ;
	WIFI_REGISTER(8)					= 0 ;
	WIFI_REGISTER(0x0A)					= 0 ;
	WIFI_REGISTER(WIFI_TXRESET)			= 0xFFFF ;
	WIFI_REGISTER(0xB4)					= 0xFFFF ;
	
	REG_IME = savedIME ;
}

void LWIFI_Start(void)
{
	unsigned long savedIME = REG_IME ;
	REG_IME = 0 ;
	
	LWIFI_Stop() ;
	
	WIFI_REGISTER(0x32)					= 0x8000 ;
	WIFI_REGISTER(0x134)				= 0xFFFF ;
	WIFI_REGISTER(WIFI_AIDS+2)			= 0 ;
	WIFI_REGISTER(WIFI_AIDS)			= 0 ;
	WIFI_REGISTER(WIFI_USCOUNTER_CR)	= 1 ;
	WIFI_REGISTER(WIFI_PSCNT)			= 0 ;
	// RX start
	WIFI_REGISTER(WIFI_RXCNT)			= WIFI_RX_ENABLE ;
	WIFI_REGISTER(WIFI_RXRANGE_BEGIN)	= 0x4C00;
	WIFI_REGISTER(WIFI_WRITECSRLATCH)	= (WIFI_REGISTER(WIFI_RXRANGE_BEGIN) & 0x3FFF) >> 1;
	WIFI_REGISTER(WIFI_RXRANGE_END)		= 0x5F60;
	WIFI_REGISTER(WIFI_RXREADCSR)		= (WIFI_REGISTER(WIFI_RXRANGE_BEGIN) & 0x3FFF) >> 1;
	WIFI_REGISTER(WIFI_FIFOEND)			= WIFI_REGISTER(WIFI_RXRANGE_END) - 2 ;
	WIFI_REGISTER(WIFI_RXCNT)			= WIFI_RX_ENABLE | WIFI_RXRANGE_LATCH ;	
	// TX Start
	WIFI_REGISTER(WIFI_TXCNT)			= WIFI_SLOT(0) | WIFI_SLOT(1) |WIFI_SLOT(2) ;
	
	
	WIFI_REGISTER(WIFI_RXCNT)			= WIFI_RX_ENABLE ;
	WIFI_REGISTER(WIFI_IF)				= 0xFFFF ;
	WIFI_REGISTER(WIFI_IE)				= WIFI_IRQ_RXCOMPLETE | WIFI_IRQ_TXCOMPLETE | WIFI_IRQ_TXSTART | WIFI_IRQ_TXERROR ;
	WIFI_REGISTER(0x1AE)				= 0 ;
	WIFI_REGISTER(0x1AA)				= 0 ;

	WIFI_REGISTER(WIFI_BSSID + 0)		= 0xF00D ;
	WIFI_REGISTER(WIFI_BSSID + 2)		= 0xFFFF ;
	WIFI_REGISTER(WIFI_BSSID + 4)		= 0xFFFF ;

	WIFI_REGISTER(WIFI_RXFILTER)		= 0xFFFF ;		

	WIFI_REGISTER(WIFI_TXMODIFY)		= WIFI_USESW_DURATION | WIFI_USESW_SEQUENCE | WIFI_USESW_FCS;
	WIFI_REGISTER(0x120)				= 0xFFFF ;			

	WIFI_REGISTER(WIFI_BEACONPERIOD)	= 0x7FFF ; // no / least amount of beacons
	
	WIFI_REGISTER(0x008)				= 0 ;
	WIFI_REGISTER(0x00A)				= 0 ;
	WIFI_REGISTER(0x004)				= 1 ;
	WIFI_REGISTER(WIFI_USCOUNTER_CR)	= 1 ;
	WIFI_REGISTER(WIFI_USCOMPARE_CR)	= 1 ;
	
	WIFI_REGISTER(0x048)				= 0 ;
	LWIFI_DisableTempPowerSave() ;
	WIFI_REGISTER(WIFI_POWERSTATE)		|= 2 ;
	WIFI_REGISTER(WIFI_TXRESET)			= 0xFFFF ;	
		
	int i=0xFA0;
	while(i!=0 && !(WIFI_REGISTER(0x19C) & 0x80)) i--;
	
	REG_IME = savedIME ;
}

int LWIFI_MAC_Reglist[] = { WIFI_MODE_RST, WIFI_MODE_WEP, 0x0A, WIFI_IE,   WIFI_IF, 0x254,   0xB4, WIFI_BEACONTRANS, WIFI_AIDS+2, WIFI_AIDS, WIFI_USCOUNTER_CR, WIFI_USCOMPARE_CR, 0xEE,   0xEC, 0x1A2, 0x1A0,  0x110, 0xBC, 0xD4, 0xD8,   0xDA, 0x76 };
int LWIFI_MAC_Vallist[] = {    0,                      0,    0,       0,    0xffff,     0, 0xffff,                0,           0,         0,                 0,                 0,    1, 0x3F03,     1,     0, 0x0800,    1,    3,    4, 0x0602,    0 };

void LWIFI_MacInit() {
	int i;
	for(i=0;i<22;i++) {
		WIFI_REGISTER(LWIFI_MAC_Reglist[i]) = LWIFI_MAC_Vallist[i];
	}
}



int LWIFI_RF_Reglist[] = { 0x146, 0x148, 0x14A, 0x14C, 0x120, 0x122, 0x154, 0x144, 0x130, 0x132, 0x140, 0x142, 0x38, 0x124, 0x128, 0x150 };

void LWifi_RFInit() {
	int i,j;
	int channel_extrabits;
	int numchannels;
	int channel_extrabytes;

	irqSet(IRQ_WIFI,&LWifiIRQ) ;
	irqEnable(IRQ_WIFI) ;

	for(i=0;i<16;i++) {
		WIFI_REGISTER(LWIFI_RF_Reglist[i])=LWIFI_ReadFlashHWord(0x44+i*2);
	}
	numchannels=LWIFI_ReadFlashByte(0x42);
	channel_extrabits=LWIFI_ReadFlashByte(0x41);
	channel_extrabytes=(channel_extrabits+7)/8;
	WIFI_REGISTER(0x184)=((channel_extrabits>>7)<<8) | (channel_extrabits&0x7F);
	j=0xCE;
	if(LWIFI_ReadFlashByte(0x40)==3) {
		for(i=0;i<numchannels;i++) {
			WIFI_RF_Write(LWIFI_ReadFlashByte(j++)|(i<<8)|0x50000);
		}
	} else {
		for(i=0;i<numchannels;i++) {
			WIFI_RF_Write(LWIFI_ReadFlashBytes(j,channel_extrabytes));
			j+=channel_extrabytes;
		}
	}
}
  
void LWIFI_Init(void)
{
//	IPC_SetChannelCallback(0,&LWIFI_IPC_ChannelCallback) ;

	(*(volatile unsigned short *)0x04000304) |= 2 ;
	WIFI_WAITCR = 0x30 ;
	swiWaitForVBlank() ;
	
	WIFI_REGISTER(4) = 0xFFFF ;
	LWIFI_Stop() ;
	int i ;
	for (i=WIFI_MEMORY;i<WIFI_MEMORYEND;i+=2)
	{
		WIFI_REGISTER(i) = 0 ;
	}
	
	char mac_address[6] ;
	readFirmware(FW_MAC,&mac_address[0],6) ;
	char *hint = (char *)safe_malloc(10) ;
	*(unsigned long *)hint = IPCTAG_MAC ;	
	for (i=0;i<3;i++)
	{
		((unsigned short*)(hint + 4))[i] = ((unsigned short *)mac_address)[i] ;
	}

	IPC_SendMessage(hint,10) ;
	safe_free(hint) ;
	
	WIFI_REGISTER(WIFI_IE) = 0 ;
	
	// Power usec counter (no powersaving)
	WIFI_REGISTER(WIFI_POWER_US) = 0 ;
	swiDelay( 67109 );
	// Power BBSIO (no powersaving BBSIO)
	WIFI_REGISTER(WIFI_BBSIO_POWER) = 0 ;
	
	LWIFI_MacInit() ;
	
	unsigned char tmp = LWIFI_BB_Read(1) ;
	LWIFI_BB_Write(WIFI_BB_CNT,tmp & ~WIFI_BB_ENABLE) ;
	LWIFI_BB_Write(WIFI_BB_CNT,tmp | WIFI_BB_ENABLE) ;
	swiDelay( 335544 );
	LWifi_RFInit() ;
	
	unsigned char *BBData = (unsigned char *)safe_malloc(0x69) ;
	readFirmware(0x64,BBData,0x69) ;
	WIFI_REGISTER(WIFI_BBSIO_MODE) = 0x0100 ;

	for(i=0;i<0x69;i++) 
	{
		LWIFI_BB_Write( i, BBData[i] );
	}
	safe_free(BBData) ;	
	
	unsigned short *m = (unsigned short *)&mac_address ;

	WIFI_REGISTER(WIFI_MAC_ADDR+0) = m[0] ;
	WIFI_REGISTER(WIFI_MAC_ADDR+2) = m[1] ;
	WIFI_REGISTER(WIFI_MAC_ADDR+4) = m[2] ;
	
	WIFI_REGISTER(WIFI_RETRYLIMIT) = 7 ;
	
	LWIFI_SetMode(3) ;
	LWIFI_SetWepMode(0) ;
	LWIFI_SetChannel(6) ;
	LWIFI_DisableTempPowerSave() ;
	
	LWIFI_BB_Write(WIFI_BB_EDTHRESHOLD,0x1F) ;
	LWIFI_BB_Write(WIFI_BB_CCAOP,WIFI_BB_USECS) ;
	
	LWIFI_Start() ;
	
	WIFI_REGISTER(WIFI_TXCNT) = WIFI_SLOT(0) | WIFI_SLOT(1) | WIFI_SLOT(2) ;		// flush sends
}

u16 inline LWifi_MACRead(u32 MAC_Base, u32 MAC_Offset) 
{
	MAC_Base += MAC_Offset;
	if(MAC_Base>=(WIFI_REGISTER(0x52)&0x1FFE)) MAC_Base -= ((WIFI_REGISTER(0x52)&0x1FFE)-(WIFI_REGISTER(0x50)&0x1FFE));
	return WIFI_REGISTER(0x4000+MAC_Base);
}
  
void LWIFI_HandleRXComplete(void)
{
	int base,packetlen,full_packetlen ;
	// get the data out of buffer!
	while(WIFI_REGISTER(0x54)!=WIFI_REGISTER(0x5A)) {
		base = WIFI_REGISTER(0x5A)<<1;
				
		packetlen = LWifi_MACRead(base,8);
		
		full_packetlen = 12 + ((packetlen + 3) & (~3)) ;

		if (packetlen > 0)
		{
			char *data = (char *)safe_malloc(10 + 12+packetlen) ;
			*(unsigned long *)data = IPCTAG_DATA ; 
			int i ;
			for (i=0;i<12+packetlen;i+=2)
			{
				*(unsigned short *)(data + i + 10) = LWifi_MACRead(base, i);
			}
			((unsigned short *)(data + 4))[0] = WIFI_REGISTER(0x54) ;
			((unsigned short *)(data + 4))[1] = WIFI_REGISTER(0x5A) ;
			((unsigned short *)(data + 4))[2] = full_packetlen ;
			IPC_SendMessage(data,10 + packetlen + 12) ;
			safe_free(data) ;
		}
		
		base += full_packetlen ;
		if(base>=(WIFI_REGISTER(0x52)&0x1FFE)) base -= ((WIFI_REGISTER(0x52)&0x1FFE)-(WIFI_REGISTER(0x50)&0x1FFE));
		WIFI_REGISTER(0x5A)=base>>1;
	}	
}

volatile int sendActive = 0 ;

void LWifiIRQ(void)
{
	REG_IF = IRQ_WIFI ;
	int i ;
	// make sure we are clearing every needed bit!
	// if we fail to, REG_IF.bit24 will not be triggered again!
	while (WIFI_REGISTER(WIFI_IF) & WIFI_REGISTER(WIFI_IE))
	{
		for (i = 0;i<16;i++)
		{
			if ((WIFI_REGISTER(WIFI_IF) & BIT(i)) && (WIFI_REGISTER(WIFI_IE) & BIT(i)))
			{
				switch (i)
				{
					case 0:
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;					
						LWIFI_HandleRXComplete() ;
						break ;
					case 1:		// TX Complete
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					case 3:		// TX Error
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					case 4:
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						LWIFI_Init() ;
						break ;
					case 6:
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;					
						break ;
					case 7:		// TX Start
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					case 11:		// TX Start
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					case 14:		// beacon timer
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					case 15:		// pre beacon timer
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
					default:
						WIFI_REGISTER(WIFI_IF) = BIT(i) ;
						break ;
				}
			} else
			{
			}
		}
	}
}

#define BIGENDIAN(n)		((((unsigned long)(n) >> 24) & 0xFF) | (((unsigned long)(n) >> 8) & 0xFF00) | (((unsigned long)(n) << 8) & 0xFF0000) | (((unsigned long)(n) << 24) & 0xFF000000))



#define CRC32POLY 0x04C11DB7 /* CRC-32 Polynom */
#define CRC32POLYREV 0xEDB88320 /* CRC-32 Polynom, umgekehrte Bitfolge */
   
int datastream[]={1,0,0,0,1,1,0,0};
int databits=8;
   
unsigned int crc32; /* Shiftregister */
unsigned int crc32_rev ; /* Shiftregister */

void calc_crc32(int bit)
{   
	int hbit;       
	hbit=(crc32 & 0x80000000) ? 1 : 0;
	if (hbit != bit)
		crc32=(crc32<<1) ^ CRC32POLY;
	else
		crc32=crc32<<1;
}

void calc_crc32_rev(int bit)
{   
	int lbit;
	lbit=crc32_rev & 1;
	if (lbit != bit)
		crc32_rev=(crc32_rev>>1) ^ CRC32POLYREV;
	else
		crc32_rev=crc32_rev>>1;
}

void LWIFI_FillTXMEM(unsigned short location, char *buffer, int length)
{
	int i ;
	crc32 = 0 ;
	crc32_rev = ~0 ;
	for (i=0;i<length;i++)
	{
		int q ;
		for (q=0;q<8;q++)
		{
			calc_crc32_rev((buffer[i] & (1<<q))!=0) ;
			calc_crc32((buffer[i] & (1<<q))!=0) ;
		}
	}
	crc32_rev = ~crc32_rev ;

	buffer[length+0] = ((crc32_rev >>  0) & 0xFF) ;
	buffer[length+1] = ((crc32_rev >>  8) & 0xFF) ;
	buffer[length+2] = ((crc32_rev >> 16) & 0xFF) ;
	buffer[length+3] = ((crc32_rev >> 24) & 0xFF) ;

	for (i=0;i<8;i+=2)
		WIFI_REGISTER(WIFI_MEMORY + i + location) = 0x0000 ;
	WIFI_REGISTER(WIFI_MEMORY +  8 + location) = WIFI_TX2MBIT ;
	WIFI_REGISTER(WIFI_MEMORY + 10 + location) = length + 4 ;
	// copy payload
	for (i = 0; i < length + 4 ; i+=2)
	{
		WIFI_REGISTER(WIFI_MEMORY + 12 + i + location) = ((unsigned short *)buffer)[i/2] ;
	}
	// place for CRC
	//for (;i<length + 4;i+=2)			
	//{
	//	WIFI_REGISTER(WIFI_MEMORY + 12 + i + location) = 0x0000 ;
	//}
}

int LWIFI_TXSlotBusy(unsigned char num)
{
//	return sendActive ;
	// if there is any transfer pending (RX-pin on RF not set), assume we are busy
//	if ((WIFI_REGISTER(0x19C) & BIT(7))==0) return 1 ;
	// otherwise check if the slot is marked as enabled for send
	return (WIFI_REGISTER(WIFI_TXSLOT(num)) & WIFI_TXSLOTENABLE != 0) ;
}

void LWIFI_SendRAW(char *buffer, int length)
{
	int i = 0;
	int timeout= 100 ;
	while (timeout--)
	{
		i = 0 ;
		for (i=2;i>=0;i--)
		{
			if (!LWIFI_TXSlotBusy(i)) // WIFI_REGISTER(WIFI_TXSLOT(i)) & WIFI_TXSLOTENABLE))
			{
				LWIFI_FillTXMEM(i*0x400,buffer,length) ;
				// enable slot, start sending of slot
				WIFI_REGISTER(WIFI_TXSLOT(i)) = WIFI_TXSLOTENABLE | (i*0x200) ;
				WIFI_REGISTER(WIFI_TXCNT) = WIFI_SLOT(i) ;
				return ;
			}
		}
		swiDelay(100) ;
	}
	return ;
}

void LWIFI_SetBSSID(unsigned char *bssid)
{
	WIFI_REGISTER(WIFI_BSSID + 0) = ((unsigned short *)bssid)[0] ;
	WIFI_REGISTER(WIFI_BSSID + 2) = ((unsigned short *)bssid)[1] ;
	WIFI_REGISTER(WIFI_BSSID + 4) = ((unsigned short *)bssid)[2] ;
}

void LWIFI_IPC_ChannelCallback(unsigned char *buffer, unsigned long length)
{
	if (*(unsigned long *)buffer == IPCTAG_DATA) // replacement for strncmp(WIFI_IPC_buffer,"DTA",3)==0)
	{
		LWIFI_SendRAW(buffer+4,length-4) ;
	} else
	if (*(unsigned long *)buffer == IPCTAG_CHANNEL)
	{
		LWIFI_SetChannel(buffer[4]) ;
	} else
	if (*(unsigned long *)buffer == IPCTAG_BSSSET)
	{
		LWIFI_SetBSSID((unsigned char *)&buffer[4]) ;
	} else 
	if (*(unsigned long *)buffer == IPCTAG_ECHO)
	{
		IPC_SendMessage(buffer,length) ;
	} else
	{
		// this IPC was not needed for us
		// provide it for anyone who wants
		IPC_PassCustomMessage((unsigned char *)buffer,(int)length) ;
	}
}

void LWIFI_IPC_UpdateNOIRQ(void)
{
	//int timeout = 100000 ;
	//while (IPC_CheckMessage() && timeout--) ;
	//return ;

	char *LWIFI_IPC_buffer = (char *)safe_malloc(2000) ;
	int length = 2000 ;
	while (IPC_GetMessage(LWIFI_IPC_buffer,(unsigned long *)&length))
	{
		if (*(unsigned long *)LWIFI_IPC_buffer == IPCTAG_DATA) // replacement for strncmp(WIFI_IPC_buffer,"DTA",3)==0)
		{
			LWIFI_SendRAW(LWIFI_IPC_buffer+4,length-4) ;
		} else
		if (*(unsigned long *)LWIFI_IPC_buffer == IPCTAG_CHANNEL)
		{
			LWIFI_SetChannel(LWIFI_IPC_buffer[4]) ;
		} else
		if (*(unsigned long *)LWIFI_IPC_buffer == IPCTAG_BSSSET)
		{
			LWIFI_SetBSSID((unsigned char *)&LWIFI_IPC_buffer[4]) ;
		} else 
		if (*(unsigned long *)LWIFI_IPC_buffer == IPCTAG_ECHO)
		{
			IPC_SendMessage(LWIFI_IPC_buffer,length) ;
		} else
		{
			// this IPC was not needed for us
			// provide it for anyone who wants
			IPC_PassCustomMessage((unsigned char *)LWIFI_IPC_buffer,(int)length) ;
		}
		length = 2000 ;
	}
	safe_free(LWIFI_IPC_buffer) ;
}
