
#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>

#include "MessageQueue.h"
#include "802.11.h"
#include "lobby.h"
#include <fat.h>
#include <malloc.h>
#include <string.h>
#include <safe_malloc.h>
#include "file.h"

#define EXAMPLE_GAMECODE			1
#define EXAMPLE_VERSION				0
#define EXAMPLE_STREAM				2

int frame = 0 ;

void LOBBY_Shutdown();

void VBlankIRQ(void)
{
	REG_IF = IRQ_VBLANK ;
	IPC_RcvCompleteCheck() ;
	LOBBY_Update() ;
}


char 				hostedFileName[256] ;
unsigned long		hostedFileLength = 0 ;

unsigned short memRead16(unsigned char *addr) ;

unsigned long memRead32(unsigned char *addr)
{
	if (((unsigned long)addr & 2)==0)
	{
		// aligned 16 bit read
		return *(unsigned long *)addr ;
	} else
	{
		return memRead16(addr) | ((unsigned long)memRead16(addr+2) << 16) ;
	}
}

unsigned short memRead16(unsigned char *addr)
{
	if (((unsigned long)addr & 1)==0)
	{
		// aligned 16 bit read
		return *(unsigned short *)addr ;
	} else
	{
		return addr[0] | ((unsigned short)addr[1] << 8) ;
	}
}

void HostStreamCallback(unsigned char *data, int length, LPLOBBY_USER from)
{
	switch (memRead32(data))
	{
		case 0:
			// info request
			{
				printf("%s: Fileinfo\n",LOBBY_GetUserName(from)) ;
				unsigned char *reply = (unsigned char *)safe_malloc(4+4+strlen(hostedFileName)+1) ;
				((unsigned long *)reply)[0] = 1 ;
				((unsigned long *)reply)[1] = hostedFileLength ;
				strcpy((char *)reply+8,hostedFileName) ;
				LOBBY_SendToUser(from,EXAMPLE_STREAM,reply,4+4+strlen(hostedFileName)+1) ;
				safe_free(reply) ;
			}
			break ;
		case 2:
			// part request
			{
				unsigned long pos = memRead32(data+4) ;
				unsigned char *reply = (unsigned char *)safe_malloc(4+8+0x200) ;
				FILE *file = fopen(hostedFileName,"rb") ;
				fseek(file,pos,SEEK_SET) ;
				fread(reply+12,0x200,1,file) ;
				fclose(file) ;
				((unsigned long *)reply)[0] = 3 ;
				((unsigned long *)reply)[1] = pos ;
				((unsigned long *)reply)[2] = 0x200 ;
				LOBBY_SendToUser(from,EXAMPLE_STREAM,reply,4+8+0x200) ;
				safe_free(reply) ;
				printf("\x1b[15;0H") ;
				printf("%s: Data at %d\n",LOBBY_GetUserName(from),(int)pos) ;
				struct mallinfo mi = mallinfo() ;
				printf("%d Bytes allocated\n",mi.arena) ;
			}
			break ;
		default:
			printf("%d\n",(int)memRead32(data)) ;
			break ;
	}
}

char *fileName = 0 ;
volatile unsigned long fileLength = 0 ;
volatile long filePos = 0 ;
FILE *file ;

void ClientStreamCallback(unsigned char *data, int length, LPLOBBY_USER from)
{
	switch (memRead32(data))
	{
		case 1:
			// info reply
			{
				fileLength = memRead32(data+4);
				fileName = strdup((char *)data+8) ;
			}
			break ;
		case 3:
			// part reply
			{
				if (!file) return ;
				unsigned long pos = memRead32(data+4) ;
				unsigned long length = memRead32(data+8) ;
//				printf("%d Bytes from %d\n",length,pos) ;
				fseek(file,pos,SEEK_SET) ;
				fwrite(data+12,length,1,file) ;
				filePos = pos ;
			}
			break ;
	}
}

void DownloadFile(void)
{
	consoleClear() ;
	fileName = 0 ;
	fileLength = 0 ;
	LOBBY_SetStreamHandler(EXAMPLE_STREAM,&ClientStreamCallback) ;
	// Step 1: find host
	printf("Looking for host\n") ;
	LPLOBBY_ROOM host = 0;
	while (!host)
	{
		int i = 0 ;
		LPLOBBY_USER tmp ;
		while ((tmp = LOBBY_GetUserByID(i)) && !host)
		{
			LPLOBBY_ROOM thatRoom = LOBBY_GetRoomByUser(tmp) ;
			if (LOBBY_GetRoomGameCode(thatRoom)==EXAMPLE_GAMECODE)
			{
				host = thatRoom ;
			}
			i++ ;
		}
	}
	// Step 2: get file info
	printf("Getting file info\n") ;
	unsigned long request = 0 ;
	LOBBY_SendToRoom(host,EXAMPLE_STREAM,(unsigned char *)&request,4) ;
	while (!fileName || !fileLength)
	{
		swiWaitForVBlank() ;
	}
	printf("Found \'%s\'\n",fileName) ;
	printf("(%d Bytes)\n",(int)fileLength) ;
	// Step 3: create the file
	file = fopen(fileName,"wb+") ;
	filePos = -1 ;
	// Step 4: 
	int i ;
	for (i=0;i<fileLength;i+=0x200)
	{
		unsigned long request[2] = { 2, 0 } ;
		request[1] = i ;
		LOBBY_SendToRoom(host,EXAMPLE_STREAM,(unsigned char *)&request[0],8) ;
		
		// wait for answer to request
		while (i>filePos) 
		{
			scanKeys() ;
			if (keysDown() & KEY_START)
			{
				LOBBY_Shutdown() ;
				while(1) ;
			}
		} ;
		printf("\x1b[15;0H") ;
		printf("%d Bytes completed\n",(int)filePos+0x200) ;
		struct mallinfo mi = mallinfo() ;
		printf("%d Bytes allocated\n",mi.arena) ;

	}
	fclose(file) ;
	file = 0 ;
}

void userInfoCB(LPLOBBY_USER user, unsigned long reason)
{
	if (!user) return ;
	switch (reason)
	{
		case USERINFO_REASON_REGOGNIZE:
			printf("%s recognized.\n",LOBBY_GetUserName(user)) ;
			break ;
		case USERINFO_REASON_RETURN:
			printf("%s returned.\n",LOBBY_GetUserName(user)) ;
			break ;
		case USERINFO_REASON_TIMEOUT:
			printf("%s timed out.\n",LOBBY_GetUserName(user)) ;
			break ;
		case USERINFO_REASON_ROOMCREATED:
			printf("%s created room.\n",LOBBY_GetUserName(user)) ;
			break ;
		case USERINFO_REASON_ROOMCHANGE:
			printf("%s changed room.\n",LOBBY_GetUserName(user)) ;
			break ;
	}
}

int main(void) 
{
	REG_EXMEMCNT=0xe800;

	powerON(POWER_ALL);
	REG_IME = 0 ;
	REG_IE = 0 ;
	REG_IF = 0xFFFF ;

	videoSetMode(0);	//not using the main screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
	vramSetBankC(VRAM_C_SUB_BG);

	SUB_BG0_CR = BG_MAP_BASE(31);

	BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

	//consoleInit() is a lot more flexible but this gets you up and running quick
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
	

	defaultExceptionHandler() ;

	irqInit() ;

	// Startup IPC engine
	IPC_Init() ;
	IPC_SetChannelCallback(0,&LWIFI_IPC_Callback) ;
//	IPC_SetMsgCompleteCallback(&IPC_RcvCompleteCheck) ;

	// usual VBlank
	irqSet(IRQ_VBLANK,&VBlankIRQ) ;
	irqEnable(IRQ_VBLANK) ;

	fatInitDefault() ;



	consoleClear() ;
	printf("Filesharing example\n") ;
	printf("(c) 2007,\n") ;
	printf("    Tim \'MightyMax\' Seidel\n") ;
	printf("============================\n") ;
	printf("\n\n") ;
	printf("[A] to download file\n") ;
	printf("[B] to host file\n") ;
	
	int task = 0 ;
	do
	{
		scanKeys() ;
		if (keysDown() & KEY_A)
		{
			task = 1 ;
		}
		if (keysDown() & KEY_B)
		{
			task = 2 ;
		}
	} while (!task) ;

	LOBBY_Init() ;
	LOBBY_SetUserInfoCallback(&userInfoCB) ;

	switch (task)
	{
		case 1:		// download
			DownloadFile() ;
			break ;
		case 2:		// host
			{
				FILE *file = loadFile();
				strcpy(hostedFileName, loadFileName);
				fseek(file,0,SEEK_END) ;
				hostedFileLength = ftell(file) ;
				fclose(file) ;
				LOBBY_CreateRoom("",8,EXAMPLE_GAMECODE,EXAMPLE_VERSION) ;
				LOBBY_SetStreamHandler(EXAMPLE_STREAM,&HostStreamCallback) ;
				consoleClear() ;
				printf("Providing file \'%s\'\n",hostedFileName) ;
				printf("(%d Bytes)\n",(int)hostedFileLength) ;
				while (1) swiWaitForVBlank() ;
			}
			break ;
	}

	return 0;
}
