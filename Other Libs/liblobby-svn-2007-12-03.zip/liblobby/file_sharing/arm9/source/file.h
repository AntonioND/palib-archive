FILE* loadFile();

extern char loadFileName[256];
