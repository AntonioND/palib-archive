
#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>

#include "MessageQueue.h"
#include "802.11.h"
#include "lobby.h"
#include <fat.h>
#include <malloc.h>
#include <string.h>


volatile int frame = 0 ;

void VBlankIRQ(void)
{
	REG_IF = IRQ_VBLANK ;
/*	IPC_RcvCompleteCheck() ;
	LOBBY_Update() ;
*/
	frame++ ;
}

char *msg = 0 ;

int recved = 0, sent = 0 ;

void receiveText(unsigned char *data, int length, LPLOBBY_USER from)
{
	if (msg) free(msg) ;
	msg = (char *)safe_malloc(length) ; // strdup((char *)data) ;
	strcpy(msg,data) ;
	recved ++ ;
}


volatile int msecs = 0 ;
volatile int ipc_num = 0 ;

void ipc_callback_counting(unsigned char *data, int length) 
{
	ipc_num++ ;
}

void timerIRQ(void)
{
	REG_IF |= IRQ_TIMER0 ;
	TIMER_DATA(0) = (unsigned short)(short)-33513 ;
	TIMER_CR(0) = TIMER_DIV_1 | TIMER_ENABLE | TIMER_IRQ_REQ ;
	msecs++ ;
}

int main(void) 
{
	REG_EXMEMCNT=0xe800;

	powerON(POWER_ALL);
	REG_IME = 0 ;
	REG_IE = 0 ;
	REG_IF = 0xFFFF ;

	videoSetMode(0);	//not using the main screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
	vramSetBankC(VRAM_C_SUB_BG);

	SUB_BG0_CR = BG_MAP_BASE(31);

	BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

	//consoleInit() is a lot more flexible but this gets you up and running quick
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
	

	defaultExceptionHandler() ;

	irqInit() ;

	consoleClear() ;
	printf("Starting .") ;
	// Startup IPC engine
	IPC_Init() ;
	printf("..") ;
	IPC_SetChannelCallback(0,&LWIFI_IPC_Callback) ;
//	IPC_SetMsgCompleteCallback(&IPC_RcvCompleteCheck) ;
	printf("done.\n") ;

	// usual VBlank
	irqSet(IRQ_VBLANK,&VBlankIRQ) ;
	irqEnable(IRQ_VBLANK) ;
	irqSet(IRQ_TIMER0,&timerIRQ) ;
	irqEnable(IRQ_TIMER0) ;
	TIMER_DATA(0) = (unsigned short)(short)-33513 ;
	TIMER_CR(0) = TIMER_DIV_1 | TIMER_ENABLE | TIMER_IRQ_REQ ;

	
	int selected = 0 ;

	consoleClear() ;
	printf("IPC Performance Test\n") ;
	printf("-----------------------\n") ;
	printf("Press [A] to start\n") ;
	printf("=======================\n") ;
	scanKeys() ;
	while (!(keysDown() & KEY_A)) 
	{
		scanKeys() ;
	}

	consoleClear() ;
	printf("IPC Performance Test\n") ;
	printf("-----------------------\n") ;
	int i ;
	printf("Test A: Send 500 frames\n") ;
	printf("        Active filling\n") ;
	printf("=======================\n") ;
	for (i=3;i<11;i++)
	{
		int size = 1 << i ;
		unsigned char *buffer = (unsigned char *)safe_malloc(size) ;
		strcpy(buffer,"Junk") ;
		int start = msecs ;
		int q ;
		for (q=0;q<500;q++)
		{
			IPC_SendMessage(buffer,size) ;
			IPC_WaitForAllSent() ;
		}
		int end = msecs ;
		printf("%5d Bytes: %1.3fs %3.1fkB/s\n",size,((end-start) / 1000.0f),((500*size) / ((end-start) / 1000.0f)) / 1024) ;
		safe_free(buffer) ;
	}	
	printf("=======================\n") ;
	printf("Press [A] to continue\n") ;
	scanKeys() ;
	while (!(keysDown() & KEY_A)) scanKeys() ;

	consoleClear() ;
	printf("IPC Performance Test\n") ;
	printf("-----------------------\n") ;
	printf("Test B: Send 500 frames\n") ;
	printf("        Passive filling\n") ;
	printf("=======================\n") ;
	for (i=3;i<11;i++)
	{
		int size = 1 << i ;
		unsigned char *buffer = (unsigned char *)safe_malloc(size) ;
		strcpy(buffer,"Junk") ;
		int start = msecs ;
		int q ;
		for (q=0;q<500;q++)
		{
			IPC_SendMessage(buffer,size) ;
			while (!IPC_IsSendQueueEmpty()) ;
		}
		int end = msecs ;
		printf("%5d Bytes: %1.3fs %3.1fkB/s\n",size,((end-start) / 1000.0f),((500*size) / ((end-start) / 1000.0f)) / 1024) ;
		safe_free(buffer) ;
	}	
	printf("=======================\n") ;
	printf("Press [A] to continue\n") ;
	scanKeys() ;
	while (!(keysDown() & KEY_A)) scanKeys() ;

	consoleClear() ;
	printf("IPC Performance Test\n") ;
	printf("-----------------------\n") ;
	printf("Test C: Echo 500 frames\n") ;
	printf("        Active filling\n") ;
	printf("=======================\n") ;
	IPC_SetCustomCallback(&ipc_callback_counting) ;
	for (i=3;i<11;i++)
	{
		int size = 1 << i ;
		unsigned char *buffer = (unsigned char *)safe_malloc(size) ;
		*(unsigned long *)buffer = IPCTAG_ECHO ;
		int start = msecs ;
		int q ;
		ipc_num==0 ;
		for (q=0;q<500;q++)
		{
			IPC_SendMessage(buffer,size) ;
			while (ipc_num<=q)
			{
				IPC_FillFIFO() ;
				IPC_DrainFIFO() ;
				IPC_RcvCompleteCheck() ;
			}
		}
		int end = msecs ;
		printf("%5d Bytes: %1.3fs %3.1fkB/s\n",size,((end-start) / 1000.0f),((500*size) / ((end-start) / 1000.0f)) / 1024) ;
		safe_free(buffer) ;
	}	
	printf("=======================\n") ;
	printf("Press [A] to continue\n") ;
	scanKeys() ;
	while (!(keysDown() & KEY_A)) scanKeys() ;
	consoleClear() ;
	printf("IPC Performance Test\n") ;
	printf("-----------------------\n") ;
	printf("Test D: Echo 500 frames\n") ;
	printf("        Passive filling\n") ;
	printf("=======================\n") ;
	IPC_SetCustomCallback(&ipc_callback_counting) ;
	for (i=3;i<11;i++)
	{
		int size = 1 << i ;
		unsigned char *buffer = (unsigned char *)safe_malloc(size) ;
		*(unsigned long *)buffer = IPCTAG_ECHO ;
		int start = msecs ;
		int q ;
		ipc_num==0 ;
		for (q=0;q<500;q++)
		{
			IPC_SendMessage(buffer,size) ;
		}
		while (ipc_num<=100)
		{
			IPC_RcvCompleteCheck() ;
		}
		int end = msecs ;
		printf("%5d Bytes: %1.3fs %3.1fkB/s\n",size,((end-start) / 1000.0f),((500*size) / ((end-start) / 1000.0f)) / 1024) ;
		safe_free(buffer) ;
	}	
	printf("=======================\n") ;

	return 0;
}
