#ifndef SMI_STARTUP_VIAIPC_INCLUDED
#define SMI_STARTUP_VIAIPC_INCLUDED

void StartUpIPC(void) ;

#endif
