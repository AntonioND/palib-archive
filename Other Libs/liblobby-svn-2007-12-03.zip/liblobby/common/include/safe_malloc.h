#ifndef safe_malloc_included
#define safe_malloc_included

#ifdef __cplusplus
  extern "C" {
#endif

#ifdef WIN32
	#define safe_malloc	malloc
	#define safe_free free 
#else
	void *safe_malloc(unsigned long size) ;
	void safe_free(void *ptr) ;
#endif

#ifdef __cplusplus
  }
#endif

#endif
