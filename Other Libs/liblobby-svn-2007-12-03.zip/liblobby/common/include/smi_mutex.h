#ifndef SMI_MUTEX_INCLUDED
#define SMI_MUTEX_INCLUDED

enum SMI_MUTEX_RETURNVAL
{
	SMI_MUTEX_TIMEDOUT,								// The mutex has not been acquired because it was locked by someone else longer then the specified timeout
	SMI_MUTEX_SUCCESS,								// The mutex operation succeeded
	SMI_MUTEX_ALLREADYACQUIRED,						// The mutex was allready acquired (warning)
	SMI_MUTEX_NOTTHEOWNER							// The mutex operation failed because we are not the owner of the mutex
} ;

struct SMI_MUTEX
{
	unsigned long 				lock ;
	unsigned long				owner ;
} ;

#define SMI_MUTEX_INFINITE	((unsigned long)-1)		// represents a timeout that can not be reached in finite time

// the actual smi based mutex
typedef struct SMI_MUTEX SMI_MUTEX, *LPSMI_MUTEX ;

// creates an mutex at the specified location. If initiallyOwned is set the mutex will be created as locked by the caller
void CreateSMIMutex(LPSMI_MUTEX mutex,bool initiallyOwned) ;

// tries to acquire the mutex. timeout specifies how long will be tried to wait for an locked mutex to become available
unsigned long WaitForSMIMutex(LPSMI_MUTEX mutex, unsigned long timeout) ;

// releases a locked mutex, if it is owned by the caller, returns error otherwise
unsigned long ReleaseSMIMutex(LPSMI_MUTEX mutex) ;

#endif
