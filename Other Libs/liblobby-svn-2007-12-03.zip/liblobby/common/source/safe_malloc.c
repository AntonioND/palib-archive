#include <malloc.h>
#include <nds.h>

void *safe_malloc(unsigned long size)
{
	int savedIME = REG_IME ;
	REG_IME = 0 ;
	void  *tmp = malloc(size) ;
	REG_IME = savedIME ;
	return tmp ;
}

void safe_free(void *ptr)
{
	int savedIME = REG_IME ;
	REG_IME = 0 ;
	free(ptr) ;
	REG_IME = savedIME ;
}
