/*

	Functions for shared memory based mutexes
	
*/

#include <nds.h>						// To access the IME for telling if we are in a "IRQ like state"
#include "smi_mutex.h"


enum SMI_MUTEX_OWNER
{
	SMI_MUTEX_OWNER_ARM7,				// ARM7 is owner while IRQs are enabled
	SMI_MUTEX_OWNER_ARM7_NOI,			// ARM7 is owner while IRQs are disabled
	SMI_MUTEX_OWNER_ARM9,				// ARM9 is owner while IRQs are enabled
	SMI_MUTEX_OWNER_ARM9_NOI,			// ARM9 is owner while IRQs are disabled
	SMI_MUTEX_OWNER_NONE
} ;

enum SMI_MUTEX_STATUS
{
	SMI_MUTEX_LOCKED,					// mutex data can be accessed
	SMI_MUTEX_UNLOCKED					// mutex data is locked to the owner
} ;

#ifdef ARM9
	#define SMI_MUTEX_ME	(REG_IME?SMI_MUTEX_OWNER_ARM9:SMI_MUTEX_OWNER_ARM9_NOI)
#else
	#define SMI_MUTEX_ME	(REG_IME?SMI_MUTEX_OWNER_ARM7:SMI_MUTEX_OWNER_ARM7_NOI)
#endif

// InterlockedSwao is an ARM32 assembler function (smi_ipc_s.s)
extern unsigned long InterlockedSwap(unsigned long *ptr,unsigned long newVal) ;

void CreateSMIMutex(LPSMI_MUTEX mutex,bool initiallyOwned)
{
	// first lock does not need to be atomic
	// we are initing it, not using it here
	mutex->lock = SMI_MUTEX_LOCKED ;
	if (initiallyOwned)
	{
		mutex->owner = SMI_MUTEX_ME ;
	} else
	{
		// the owner has to be reset _before_ unlocking, to ensure that we can securely check for self ownership
		mutex->owner = SMI_MUTEX_OWNER_NONE ;
		mutex->lock = SMI_MUTEX_UNLOCKED ;
	}
}

unsigned long WaitForSMIMutex(LPSMI_MUTEX mutex, unsigned long timeout)
{
	if (!mutex)
	{
		while(1) ;
	}
	unsigned long waitingNow = 0 ;
	if (mutex->owner == SMI_MUTEX_ME)
	{
		// since the owner is set only when lock is set and in the case of SMI_MUTEX_ME we
		// can be sure that noone changed this flag in the meantime
		return SMI_MUTEX_ALLREADYACQUIRED ;
	}
	while (InterlockedSwap((unsigned long *)&mutex->lock,SMI_MUTEX_LOCKED) != SMI_MUTEX_LOCKED)
	{
		if ((waitingNow >= timeout) && (timeout != SMI_MUTEX_INFINITE))
		{
			// we waited long 'nuff
			return SMI_MUTEX_TIMEDOUT ;
		}
		waitingNow ++ ;
		// do waiting ... busy waiting right now
	}
	// we got an own lock -> remember that it was me
	mutex->owner = SMI_MUTEX_ME ;
	return SMI_MUTEX_SUCCESS ;
}

unsigned long ReleaseSMIMutex(LPSMI_MUTEX mutex)
{
	// since the owner is set only when lock is set and in the case of SMI_MUTEX_ME we
	// can be sure that noone changed this flag in the meantime
	mutex->owner = SMI_MUTEX_OWNER_NONE ;
	// the owner has to be reset _before_ unlocking, to ensure that we can securely check for self ownership
	mutex->lock = SMI_MUTEX_UNLOCKED ;
	return SMI_MUTEX_SUCCESS ;
}
