#include <nds.h>				// using REG_IME
#include "MessageQueue.h"
#include "smi_startup_viaipc.h"
#include "safe_malloc.h"

typedef struct IPC_MESSAGEBUFFER
{
	unsigned char				* data ;
	unsigned long				length ;
	long						position ;
	struct IPC_MESSAGEBUFFER *	next ;
} IPC_MESSAGEBUFFER, *LPIPC_MESSAGEBUFFER ;

volatile LPIPC_MESSAGEBUFFER IPC_SendBuffers = 0 ;
volatile LPIPC_MESSAGEBUFFER IPC_RecvBuffers = 0 ;

IPC_MSGCOMPLETECALLBACK_PROC	msgCompleteCallback = 0 ;

void IPC_SetMsgCompleteCallback(IPC_MSGCOMPLETECALLBACK_PROC callback) 
{
	msgCompleteCallback = callback ;
}

typedef struct IPC_CHANNELCALLBACKS
{
	IPC_CHANNELCALLBACK				callback ;
	unsigned long					channel ;
	struct IPC_CHANNELCALLBACKS *	next ;
} IPC_CHANNELCALLBACKS, *LPIPC_CHANNELCALLBACKS ;

LPIPC_CHANNELCALLBACKS IPC_ChannelCallbacks = 0 ;

void IPC_SetChannelCallback(unsigned long channel, IPC_CHANNELCALLBACK cb)
{
	LPIPC_CHANNELCALLBACKS tmp = IPC_ChannelCallbacks ;
	while (tmp)
	{
		if (tmp->channel == channel)
		{
			tmp->callback = cb ;
			return ;
		}
		tmp = tmp->next ;
	}
	LPIPC_CHANNELCALLBACKS n = (LPIPC_CHANNELCALLBACKS)safe_malloc(sizeof(IPC_CHANNELCALLBACKS)) ;
	n->channel = channel ;
	n->callback = cb ;
	n->next = IPC_ChannelCallbacks ;
	IPC_ChannelCallbacks = n ;
}

volatile bool IPC_mallocErr = 0 ;
volatile int IPC_mallocErrSize = 0 ;

int IPC_LockSystem(int newLock)
{
	#ifdef WIN32
	#else
		int old = REG_IME ;
		REG_IME = newLock ;
		return old ;
	#endif
}

void IPC_FillFIFO(void)
{
	int lock = IPC_LockSystem(0) ;
	// get to the last buffer
	LPIPC_MESSAGEBUFFER tmp = IPC_SendBuffers, last = 0 ;
	// is there data?
	if (!tmp) 
	{
		IPC_LockSystem(lock) ;
		return ;
	}
	while (tmp->next)
	{
		last = tmp ;
		tmp = tmp->next ;
	}
	while (!(REG_IPC_FIFO_CR & IPC_FIFO_SEND_FULL))
	{
		if (REG_IPC_FIFO_CR & IPC_FIFO_ERROR)
		{
			REG_IPC_FIFO_CR &= ~IPC_FIFO_ERROR ;
			REG_IPC_FIFO_CR |= IPC_FIFO_ENABLE ;
		}
		if (tmp->position == -1)
		{
			REG_IPC_FIFO_TX = tmp->length ;
			tmp->position = 0 ;
		} else
		{
			REG_IPC_FIFO_TX = ((unsigned long *)tmp->data)[tmp->position / 4] ;
			tmp->position += 4 ;
			if (tmp->position >= tmp->length) 
			{
				// the packet was completed, remove it from queue
				if (last == 0)
				{
					IPC_SendBuffers = 0 ;
				} else
				{
					last->next = 0 ;
				}
				// free all
				safe_free(tmp->data) ;
				safe_free(tmp) ;
				IPC_LockSystem(lock) ;
				REG_IPC_SYNC |= IPC_SYNC_IRQ_REQUEST ;
				return ;
			}
		}
	}
	REG_IPC_SYNC |= IPC_SYNC_IRQ_REQUEST ;
	IPC_LockSystem(lock) ;
}

void IPC_DrainFIFO(void)
{
	int lock = IPC_LockSystem(0) ;
	while (!(REG_IPC_FIFO_CR & IPC_FIFO_RECV_EMPTY))
	{
		if (REG_IPC_FIFO_CR & IPC_FIFO_ERROR)
		{
			REG_IPC_FIFO_CR &= ~IPC_FIFO_ERROR ;
			REG_IPC_FIFO_CR |= IPC_FIFO_ENABLE ;
		}
		unsigned long newLong = REG_IPC_FIFO_RX ;
		// is there allready received?
		if (IPC_RecvBuffers)
		{
			// if so, does it need more data?
			if (IPC_RecvBuffers->position >= IPC_RecvBuffers->length)
			{
				// that packet was full, append a new
				LPIPC_MESSAGEBUFFER n = (LPIPC_MESSAGEBUFFER)safe_malloc(sizeof(IPC_MESSAGEBUFFER)) ;
				n->position = 0 ;
				n->data = (unsigned char *)safe_malloc((newLong+3) & ~3) ;
				n->length = newLong ;
				n->next = IPC_RecvBuffers ;
				IPC_RecvBuffers = n ;
			} else
			{
				((unsigned long *)IPC_RecvBuffers->data)[IPC_RecvBuffers->position / 4] = newLong ;
				IPC_RecvBuffers->position += 4 ;
				if (IPC_RecvBuffers->position >= IPC_RecvBuffers->length)
				{
					LPIPC_CHANNELCALLBACKS tmp = IPC_ChannelCallbacks ;
					while (tmp)
					{
						if (tmp->channel== *((unsigned long *)IPC_RecvBuffers->data))
						{
							LPIPC_MESSAGEBUFFER cur = IPC_RecvBuffers ;
							IPC_RecvBuffers = IPC_RecvBuffers->next ;
							IPC_LockSystem(lock) ;
							tmp->callback(cur->data+4,cur->length-4) ;
							safe_free(cur->data) ;
							safe_free(cur) ;
							return ;
						}
						tmp = tmp->next ;
					}
					// there was no channel handler, do it the old way
					IPC_LockSystem(lock) ;
					if (msgCompleteCallback)
						msgCompleteCallback() ;
					return ;
				}
			}
		} else
		{
			// create a new packet
			LPIPC_MESSAGEBUFFER n = (LPIPC_MESSAGEBUFFER)safe_malloc(sizeof(IPC_MESSAGEBUFFER)) ;
			n->position = 0 ;
			n->data = (unsigned char *)safe_malloc((newLong+3) & ~3) ;
			n->length = newLong ;
			n->next = 0 ;
			IPC_RecvBuffers = n ;
		}
	}
	REG_IPC_SYNC |= IPC_SYNC_IRQ_REQUEST ;
	IPC_LockSystem(lock) ;
}

void IPC_WaitForAllSent(void)
{
	while (!IPC_IsSendQueueEmpty())
	{
		IPC_FillFIFO() ;
		IPC_DrainFIFO() ;
	}
}

int IPC_IsSendQueueEmpty(void)
{
	return (IPC_SendBuffers==0) ;
}

void IPC_IrqAll(void)
{
	// mark irq as handled
	REG_IF = IRQ_FIFO_EMPTY | IRQ_FIFO_NOT_EMPTY | IRQ_IPC_SYNC ;
	// get & put available data
	IPC_FillFIFO() ;		// send first, as this reduces our own memory footprint (i.e. if there is a continous receive)
	IPC_DrainFIFO() ;
}

void IPC_SendMessage(char *data,unsigned long length)
{
	IPC_SendMessageForChannel(0,data,length) ;
}

void IPC_SendMessageForChannel(unsigned long channel,char *data,unsigned long length)
{
	unsigned long savedIME = REG_IME ;
	REG_IME = 0 ;
	// we append from front and take from last
	LPIPC_MESSAGEBUFFER n = (LPIPC_MESSAGEBUFFER)safe_malloc(sizeof(IPC_MESSAGEBUFFER)) ;
	if (!n) 
	{
		REG_IME = savedIME ;
		return ;
	}
	length += 4 ;
	n->data = (unsigned char *)safe_malloc(length) ;
	if (!n->data)
	{
		safe_free(n) ;
		REG_IME = savedIME ;
		return ;
	}
	int i ;
	for (i=0;i<length-4;i++)
		n->data[i+4] = data[i] ;
	// replacement for: memcpy(n->data,data,length) ;
	n->length = length ;
	*((unsigned long *)n->data) = channel ;
	n->position = -1 ;
	int lock = IPC_LockSystem(0) ;
	n->next = IPC_SendBuffers ;
	IPC_SendBuffers = n ;
	IPC_LockSystem(lock) ;
	#ifdef ARM7
		while (IPC_SendBuffers)
			IPC_FillFIFO() ;
		return ;
	#endif
	IPC_FillFIFO() ;
	IPC_DrainFIFO() ;
	REG_IME = savedIME ;
}

bool IPC_CheckMessage(void)
{
	int lock = IPC_LockSystem(0) ;
	// drain everything that is left in fifo
	IPC_FillFIFO() ;
	IPC_DrainFIFO() ;
	// check whether there is data to return
	if (!IPC_RecvBuffers)
	{
		IPC_LockSystem(lock) ;
		return false ;
	}
	IPC_LockSystem(lock) ;
	return true ;
}

bool IPC_GetMessage(char *data,unsigned long *length)
{
	int lock = IPC_LockSystem(0) ;
	// drain everything that is left in fifo
	IPC_FillFIFO() ;
	IPC_DrainFIFO() ;
	// check whether there is data to return
	if (!IPC_RecvBuffers)
	{
		IPC_LockSystem(lock) ;
		return false ;
	}
	LPIPC_MESSAGEBUFFER tmp = IPC_RecvBuffers, last = 0 ;
	while (tmp->next)
	{
		last = tmp ;
		tmp = tmp->next ;
	}
	// is the buffer we got complete?
	if (tmp->position < tmp->length)
	{
		IPC_LockSystem(lock) ;
		return false ;
	}
	// remove buffer from queue!
	if (last == 0)
	{
		IPC_RecvBuffers = 0 ;
	} else
	{
		last->next = 0 ;
	}
	int i ;
	// make sure there is enough space, otherwise we might overwrite vital data
	if (tmp->length - 4 > *length) tmp->length = *length ;
	for (i=0;i<tmp->length-4;i++)
		data[i] = tmp->data[i+4] ;
	// replacement for: memcpy(data,tmp->data,tmp->length) ;
	*length = tmp->length-4 ;
	safe_free(tmp->data) ;
	safe_free(tmp) ;

	// since we have free'd
	// we probably can resolve the malloc error
	IPC_LockSystem(lock) ;
	return true ;
}

int IPC_AllreadySending(unsigned char *data, int length)
{
	int lock = IPC_LockSystem(0) ;
	LPIPC_MESSAGEBUFFER tmp = IPC_SendBuffers ;
	while (tmp)
	{
		if (tmp->length == length)
		{
			int i = 0 ;
			int equal = 1 ;
			while ((i < length) && equal)
			{
				if (data[i] != tmp->data[i])
				{
					equal = 0 ;
				}
				i++ ;
			}
			if (equal)
			{
				IPC_LockSystem(lock) ;
				return 1 ;
			}
		}
		tmp = tmp->next ;
	}
	IPC_LockSystem(lock) ;
	return 0 ;
}

int IPC_Init(void)
{
	#ifdef ARM9
		unsigned long length = 100 ;
		char *buffer = (char *)safe_malloc(100) ; 
		irqSet(IRQ_FIFO_EMPTY,&IPC_IrqAll) ;
		irqSet(IRQ_FIFO_NOT_EMPTY,&IPC_IrqAll) ;
		irqSet(IRQ_IPC_SYNC,&IPC_IrqAll) ;
		StartUpIPC() ;

		irqDisable(IRQ_IPC_SYNC) ;
		irqDisable(IRQ_FIFO_EMPTY) ;
		irqDisable(IRQ_FIFO_NOT_EMPTY) ;
		REG_IPC_SYNC |= IPC_SYNC_IRQ_ENABLE ;


		while (!IPC_GetMessage(buffer,&length))
		{
			length = 100 ;
			swiDelay(1000) ;
		}
		if (*(unsigned long *)buffer!=IPCTAG_INIT) // replacement for strcmp(..."Init") ;
		{
			return 0 ;
		}
		irqEnable(IRQ_IPC_SYNC) ;
		irqEnable(IRQ_FIFO_EMPTY) ;
		irqEnable(IRQ_FIFO_NOT_EMPTY) ;
	#else
		irqSet(IRQ_FIFO_EMPTY,&IPC_IrqAll) ;
		irqSet(IRQ_FIFO_NOT_EMPTY,&IPC_IrqAll) ;

		StartUpIPC() ;	

		irqSet(IRQ_FIFO_EMPTY,&IPC_IrqAll) ;
		irqSet(IRQ_FIFO_NOT_EMPTY,&IPC_IrqAll) ;
		irqSet(IRQ_IPC_SYNC,&IPC_IrqAll) ;
		irqEnable(IRQ_FIFO_EMPTY) ;
		irqEnable(IRQ_FIFO_NOT_EMPTY) ;
		irqEnable(IRQ_IPC_SYNC) ;

		REG_IPC_SYNC |= IPC_SYNC_IRQ_ENABLE ;

		unsigned long *init = (unsigned long *)safe_malloc(4) ;
		*init = IPCTAG_INIT ;
		IPC_SendMessage((char *)init,4) ;
		safe_free(init) ;
		IPC_WaitForAllSent() ;
		// the arm7 will do polling only (reducing memory usage, as every packet is directly used and free'd again)
		irqDisable(IRQ_FIFO_EMPTY) ;
		irqDisable(IRQ_FIFO_NOT_EMPTY) ;
		irqDisable(IRQ_IPC_SYNC) ;

	#endif
	return 1 ;
}

IPC_CUSTOMCALLBACK_PROC customIPCCallback = 0 ;

void IPC_SetCustomCallback(IPC_CUSTOMCALLBACK_PROC callback) 
{
	customIPCCallback = callback ;
}

void IPC_PassCustomMessage(unsigned char *data, int length) 
{
	if (customIPCCallback)
		customIPCCallback(data, length) ;
}
