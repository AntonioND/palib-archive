/* 

*/

#include <nds.h>

void Sync(void)
{	
	#ifdef ARM7
		// the arm7 will do replies to sync request
		bool syncCompleted = false ;
		char lastSyncVal = 0 ;
		while (!syncCompleted)
		{
			char newSyncVal = IPC_GetSync() ;
			if (newSyncVal == lastSyncVal + 1)
			{
				IPC_SendSync(newSyncVal) ;
				lastSyncVal = newSyncVal ;
			} else if (newSyncVal != lastSyncVal)
			{
				// reset sync 
				lastSyncVal = 0 ;
				IPC_SendSync(0) ;
			}
			if (newSyncVal == 0xF)
			{
				syncCompleted = true ;
			}
		}
		IPC_SendSync(0) ;				
	#else
		bool syncCompleted = false ;
		char lastSyncVal = 1 ;
		IPC_SendSync(lastSyncVal) ;
		while (!syncCompleted)
		{
			char newSyncVal = IPC_GetSync() ;
			if (newSyncVal == lastSyncVal)
			{
				// we got a sub reply ... continue
				lastSyncVal++ ;
				if (lastSyncVal == 0x10)
				{
					// we are done!
					syncCompleted = true ;
				} else
				{
					IPC_SendSync(lastSyncVal) ;
				}
			} else if (newSyncVal == lastSyncVal-1)
			{
				// still waiting for a reply
			} else
			{
				if ((lastSyncVal == 0x0F) && (newSyncVal == 0))
				{
					// we are done!
					syncCompleted = true ;
				}
				// reply was errornous, retry from start
				char lastSyncVal = 1 ;
				IPC_SendSync(lastSyncVal) ;				
			}
		}
		IPC_SendSync(0) ;				

	#endif
}

void StartUpIPC(void)
{
	// enable IPC IRQs
	REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_RECV_IRQ | IPC_FIFO_SEND_CLEAR ;
	REG_IPC_SYNC = IPC_SYNC_IRQ_ENABLE ;
	irqEnable(IRQ_IPC_SYNC) ;
	irqEnable(IRQ_FIFO_NOT_EMPTY) ;
	// and after we are done here, sync with the other side for the first time
	Sync() ;
}
